# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import os
import re
import shutil
import threading
import time

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import json

ptwEnabled = json.loads(xbmc.executeJSONRPC(
    f'{{"jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails","params":{{"addonid": "{"script.module.ptw"}","properties":["enabled"]}}}}'))[
    'result']['addon']['enabled']
resolverEnabled = json.loads(xbmc.executeJSONRPC(
    f'{{"jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails","params":{{"addonid": "{"script.module.resolveurl"}","properties":["enabled"]}}}}'))[
    'result']['addon']['enabled']

if ptwEnabled:
    from ptw.libraries import control
    from ptw.libraries import log_utils
    from ptw.libraries import cache

    control.execute(
        "RunPlugin(plugin://%s)" % control.get_plugin_url({"action": "service"})
    )

    def cyclic_call(interval, func, *args, **kwargs):
        def calling():
            while True:
                time.sleep(interval)
                func(*args, **kwargs)

        thread = threading.Thread(target=calling)
        thread.start()
        return thread

    def settingsFileRewrite():
        addon_version = control.addon("plugin.video.fanfilm").getAddonInfo("version")
        settings_addon_version = control.setting("addon.version")
        reset_keys = control.setting("reset.keys")

        if reset_keys == "true" and addon_version != settings_addon_version:
            with open(control.settingsFile, "r") as file:
                content = file.read()
            pattern = re.compile(r"(.*TVDb.*|.*fanart.*|.*tm.*)", re.MULTILINE)
            settings = re.findall(pattern, content)
            for setting in settings:
                content = content.replace(setting, "")
            with open(control.settingsFile, "w") as file:
                file.write(content)


    def syncTraktLibrary():
        control.execute(
            "RunPlugin(plugin://%s)"
            % "plugin.video.fanfilm/?action=tvshowsToLibrarySilent&url=traktcollection"
        )
        control.execute(
            "RunPlugin(plugin://%s)"
            % "plugin.video.fanfilm/?action=moviesToLibrarySilent&url=traktcollection"
        )
        log_utils.log(
            "### TRAKT LIBRARY UPDATE - NEXT ON  "
            + control.setting("schedTraktTime")
            + " HOURS ################",
            log_utils.LOGINFO,
        )

    def cacheCleanTimer():
        control.execute(
            "RunPlugin(plugin://%s)"
            % "plugin.video.fanfilm/?action=clearCacheAllSilent"
        )
        log_utils.log(
            "### CACHE CLEAN - NEXT ON  "
            + control.setting("schedCleanCache")
            + " HOURS ################",
            log_utils.LOGINFO,
        )

    try:
        settingsFileRewrite()
        MediaVersion = control.addon("script.fanfilm.media").getAddonInfo("version")
        AddonVersion = control.addon("plugin.video.fanfilm").getAddonInfo("version")
        PTWVersion = control.addon("script.module.ptw").getAddonInfo("version")
        control.setSetting("addon.version", AddonVersion)
        control.setSetting("ptw.version", PTWVersion)
        log_utils.log(
            "######################### FANFILM ############################",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "####### CURRENT FANFILM VERSIONS REPORT ######################",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "### FANFILM PLUGIN VERSION: %s ###" % str(AddonVersion), log_utils.LOGINFO
        )
        log_utils.log(
            "### FANFILM MEDIA VERSION: %s ###" % str(MediaVersion), log_utils.LOGINFO
        )
        log_utils.log(
            "### PTW VERSION: %s ###" % str(PTWVersion), log_utils.LOGINFO
        )
        log_utils.log(
            "###############################################################",
            log_utils.LOGINFO,
        )
    except:
        log_utils.log(
            "######################### FANFILM ############################",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "####### CURRENT FANFILM VERSIONS REPORT ######################",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "### ERROR GETTING FANFILM VERSIONS - NO HELP WILL BE GIVEN AS THIS IS NOT AN OFFICIAL FANFILM INSTALL. ###",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "###############################################################",
            log_utils.LOGINFO,
        )

    if control.setting("autoTraktOnStart") == "true":
        syncTraktLibrary()

    if int(control.setting("schedTraktTime")) > 0:
        log_utils.log(
            "###############################################################",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "#################### STARTING TRAKT SCHEDULING ################",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "#################### SCHEDULED TIME FRAME "
            + control.setting("schedTraktTime")
            + " HOURS ################",
            log_utils.LOGINFO,
        )
        timeout = 3600 * int(control.setting("schedTraktTime"))
        cyclic_call(timeout, syncTraktLibrary)

    if control.setting("autoCleanCacheAll") == "true":
        cache.cache_clear_all()
        log_utils.log(
            "######################### FANFILM ############################",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "######## Wyczyszczono pamięć podręczną #######################",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "###############################################################",
            log_utils.LOGINFO,
        )

    if int(control.setting("schedCleanCache")) > 0:
        log_utils.log(
            "###############################################################",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "#################### STARTING CLEAN SCHEDULING ################",
            log_utils.LOGINFO,
        )
        log_utils.log(
            "#################### SCHEDULED TIME FRAME "
            + control.setting("schedCleanCache")
            + " HOURS ################",
            log_utils.LOGINFO,
        )
        timeout = 3600 * int(control.setting("schedCleanCache"))
        cyclic_call(timeout, cacheCleanTimer)

    try:
        from ptw.libraries import downloader

        downloader.clear_db()
    except:
        pass

else:
    import checker
    ResolveUrlChecker().setResolveUrl(enabled=True)
    PtwModuleChecker().setPtwModule(enabled=True)

# -*- coding: utf-8 -*-


"""
    FanFilm Project
"""

import json
import requests
import re
from urllib.parse import parse_qs, urljoin, urlencode, quote_plus, quote

from ptw.libraries import cleantitle
from ptw.libraries import client
from ptw.libraries import source_utils, log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["filmowo.club"]
        self.base_link = "https://filmowo.club/"
        self.search_link = "https://filmowo.club/search/{}"
        self.resolve_link = "https://filmowo.club/ajax/embed"
        self.session = requests.Session()


    def search(self, title, localtitle, year, search_type):
        try:
            url = self.do_search(
                cleantitle.query(title), title, localtitle, year, search_type
            )
            if not url:
                url = self.do_search(
                    cleantitle.query(localtitle), title, localtitle, year, search_type
                )
            return url
        except:
            return

    def do_search(self, search_string, title, localtitle, year, search_type):

        titles = [cleantitle.normalize(cleantitle.getsearch(title)),
                  cleantitle.normalize(cleantitle.getsearch(localtitle))]
        self.type = search_type
        for title in titles:

            try:
                r = self.session.get(self.search_link.format(quote(title)))
                r = client.parseDOM(r.text, "div", attrs={"class": "list-movie"})
                for row in r:
                    link = client.parseDOM(row, "a", ret="href")[0]
                    if not search_type in link:
                        continue
                    r1 = self.session.get(link)
                    if search_type == '/movie/':
                        attrs = client.parseDOM(r1.text, 'div', attrs={'class':'video-attr'})
                    else:
                        attrs = client.parseDOM(r1.text, 'div', attrs={'class':'featured-attr'})
                    found_year = [client.parseDOM(attr, 'div', attrs={'class':'text'})[0] for attr in attrs
                                  if 'Rok wydania' in client.parseDOM(attr, 'div', attrs={'class':'attr'})[0]]
                    if year == found_year[0]:
                        return link



            except:
                continue

    def movie(self, imdb, title, localtitle, aliases, year):

        return self.search(title, localtitle, year, "/movie/")

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return self.search(tvshowtitle, localtvshowtitle, year, "/serie/")

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):

        try:
            if url is None:
                return
            url = f'{url}-{season}-season-{episode}-episode'

            return url

        except:
            log_utils.log("filmowo - Exception", 'sources')
            return

    def get_lang_by_type(self, lang_type):

        if isinstance(lang_type, list):
            lang_type = lang_type[0]

        if "Lektor" in lang_type:
            return "pl", "Lektor"
        if "Dubbing" in lang_type:
            return "pl", "Dubbing"
        if "Napisy" in lang_type:
            return "pl", "Napisy"
        if "PL" in lang_type:
            return "pl", None
        if "unknown" in lang_type:
            return 'pl', None
        return "en", None


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None:
                return sources

            host_dict = hostprDict + hostDict

            r = self.session.get(url, timeout=10).text.replace("\r", "").replace("\n", "")

            if self.type == '/movie/':

                s = re.search('Początek źródeł(.+?)Koniec źródeł', r).group(0)
                emb = client.parseDOM(s, 'button', ret='data-embed')
                lang_list = client.parseDOM(s, 'span', attrs={"class": "name"})
            else:
                emb = re.findall('href="#" data-embed="(.+?)" ', r)
                lang_list = ['unknown'for e in emb]

            for e in emb:
                data = {'id': e}
                lang, info = self.get_lang_by_type(lang_list[emb.index(e)])
                rl = self.session.post(self.resolve_link, data=data)
                link = client.parseDOM(rl.text, 'iframe', ret='src')[0]
                valid, host = source_utils.is_host_valid(link, host_dict)

                if valid:
                    sources.append(
                        {
                            "source": host,
                            "quality": "1080p",
                            "language": lang,
                            "url": link,
                            "info": info,
                            "direct": False,
                            "debridonly": False,
                        }
                    )

            return sources
        except Exception as e:
            print("filmowo - Exception ")
            print(e)
            return sources

    def resolve(self, url):

        return url

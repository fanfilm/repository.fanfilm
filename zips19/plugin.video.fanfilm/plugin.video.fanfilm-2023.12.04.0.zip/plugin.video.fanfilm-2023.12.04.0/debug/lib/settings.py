"""
Simple settings simulate.
"""

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Union, Any


class Settings(dict):
    """
    Settings dict with parse stuff.
    """

    def __missing__(self, key: str) -> Any:
        try:
            return self.default
        except AttributeError:
            raise KeyError(key) from None

    def __call__(self, key: str) -> Any:
        return self[key]

    def convert_value(self, value: str) -> Any:
        if not value:
            return None
        if value == 'true':
            return True
        if value == 'false':
            return False
        if value.isdigit():
            return int(value)
        try:
            return float(value)
        except ValueError:
            pass
        return value

    def parse(self, path: Union[Path, str], *, guess_types: bool = False) -> None:
        tree: ET = ET.parse(path)
        root: ET.Element = tree.getroot()
        if root.tag != 'settings':
            raise ValueError('No <settings/> in XML')
        elem: ET.Element
        for elem in root:
            if elem.tag == 'setting' and 'id' in elem.attrib:
                key: str = elem.attrib['id']
                value: Any = elem.text
                if guess_types:
                    value = self.convert_value(value)
                self[key] = value

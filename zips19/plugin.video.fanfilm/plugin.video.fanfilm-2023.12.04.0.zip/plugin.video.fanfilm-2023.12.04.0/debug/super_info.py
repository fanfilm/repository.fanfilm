
import sys
from pathlib import Path
from unittest.mock import MagicMock
from lib.ptw.media import Media, MediaAttr
from requests import Session
from pprint import pprint
from argparse import ArgumentParser, Namespace
from typing import Optional, Any


TOP: Path = Path(__file__).parent.parent

sys.path.insert(0, str(TOP / 'resources' / 'lib'))
sys.path.insert(1, str(TOP / 'debug' / 'lib'))


# Fake module
ptw = MagicMock(name='PTW')
ptw.dupa = 'blada'

sys.modules['ptw.libraries'] = ptw.libraries
sys.modules['ptw.libraries.media'] = ptw.libraries.media
sys.modules['ptw.libraries.control'] = ptw.libraries.control

from lib.ptw.control import setting           # noqa: E402

ptw.libraries.control.setting = setting
ptw.libraries.media.Media = Media
ptw.libraries.media.MediaAttr = MediaAttr

from indexers.super_info import SuperInfo  # noqa: E402


def run(args: Namespace) -> None:
    def parse_var(var: str) -> tuple[str, Any]:
        k, s, v = var.partition('=')
        if s:
            return k, v
        return 'tmdb', var

    # print(args)
    if args.settings:
        for path in args.settings:
            setting.parse(path)
    if args.set:
        var: str
        for var in args.set:
            key, _, val = var.partition('=')
            setting[key] = val
    if args.print_settings:
        pprint(setting)
    media = Media(parse_var(var) for var in args.var)
    print(media)
    si = SuperInfo(media, session=Session(), lang=args.lang)
    pprint(si.get_info())


def main(argv: Optional[list[str]] = None) -> None:
    p = ArgumentParser()
    p.add_argument('--settings', '-S', metavar='PATH', action='append', help='path to addon user settings.xml')
    p.add_argument('--set', '-s', metavar='NAME=VALUE', action='append', help='override setting')
    p.add_argument('--language', '--lang', '-l', dest='lang', default='pl', help='language')
    p.add_argument('--content', '-c', choices=('movie', 'tvshow'), default='movie', help='video content type')
    p.add_argument('var', metavar='NAME=VALUE', nargs='+', help='search var (eg. "tmdb=594767")')
    p.add_argument('--print-settings', action='store_true', help='print pares settigns')
    args = p.parse_args(argv)
    run(args)


if __name__ == '__main__':
    main()

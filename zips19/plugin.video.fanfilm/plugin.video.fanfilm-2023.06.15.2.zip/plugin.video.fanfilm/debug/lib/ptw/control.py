
from unittest.mock import MagicMock
from ..settings import Settings


def addonPoster() -> str:
    return 'ADDON/POSTER'


def addonBanner() -> str:
    return 'ADDON/BANNER'


def addonFanart() -> str:
    return 'ADDON/FANART'


setting = Settings()
setting.default = None


item = MagicMock()

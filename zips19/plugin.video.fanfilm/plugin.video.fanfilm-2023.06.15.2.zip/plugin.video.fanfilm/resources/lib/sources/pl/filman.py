# -*- coding: utf-8 -*-
"""
    FanFilm Add-on
    Copyright (C) 2018 :)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from ptw.libraries import source_utils
from ptw.libraries import cleantitle
from ptw.debug import log_exception

import requests

class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["filman.cc"]

        self.base_link = "https://app.vodi.cc"
        self.search_link = "/api/search/"
        self.season_by_serie = '/api/season/by/serie/'
        self.secure_key = "4F5A9C3D9A86FA54EACEDDD635185"
        self.ipc = "d506abfd-9fe2-4b71-b979-feff21bcad13" # item purchase code
        self.anime = False
        self.year = 0

    def movie(self, imdb, title, localtitle, aliases, year):
        return self.search(title, localtitle, year, True)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return (tvshowtitle, localtvshowtitle), year

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        anime = source_utils.is_anime("show", "tvdb", tvdb)
        self.year = int(url[1])
        self.anime = anime
        if anime:
            epNo = source_utils.absoluteNumber(tvdb, episode, season)
        else:
            epNo = "s" + season.zfill(2) + "e" + episode.zfill(2)
        return self.search_ep(url[0][0], url[0][1], self.year, epNo)

    def contains_word(self, str_to_check, word):
        if str(word).lower() in str(str_to_check).lower():
            return True
        return False

    def contains_all_words(self, str_to_check, words):
        for word in words:
            if not self.contains_word(str_to_check, word):
                return False
        return True

    def search(self, title, localtitle, year, is_movie_search):
        link = f'{self.base_link}{self.search_link}{cleantitle.normalize(title)}/{self.secure_key}/{self.ipc}'
        return { 'title': title, 'url': link, 'year': year, 'quality': None, 'is_ep': False }

    def search_ep(self, title, localtitle, year, epNo):
        search = requests.get(f'{self.base_link}{self.search_link}{cleantitle.normalize(title)}/{self.secure_key}/{self.ipc}').json()
        for item in search.get('posters'):
            name = cleantitle.normalize(title)
            words = cleantitle.normalize(item['title'])
            if name in words and int(year) == int(item['year']):
                query = f'{self.base_link}{self.season_by_serie}{item["id"]}/{self.secure_key}/{self.ipc}'
                results = requests.get(query).json()
                
                season = int(epNo.split('s')[1].split('e')[0].strip('0')) - 1
                episode = int(epNo.split('s')[1].split('e')[1].strip('0')) - 1
                if not results[season]:
                    continue
                else:
                    for idx, ep in enumerate(results[season].get('episodes')):
                        if idx == episode:
                            for srcs in ep['sources']:
                                return { 'title': title, 'url': srcs['url'], 'year': year, 'quality': srcs['quality'], 'is_ep': True }

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            data = []
            if url['url'] == None:
                return sources
            if url['is_ep']:
                data.append({
                    'quality': 'Niska' if not url['quality'] else url['quality'],
                    'lang': 'pl',
                    'link': url['url']
                })
            else:
                query = url['url']
                result = requests.get(query).json()
            
                for item in result.get('posters'):
                    nazwa = url['title']
                    name = cleantitle.normalize(nazwa)
                    words = cleantitle.normalize(item['title'])
                    if name in words and int(url['year']) == int(item['year']):
                        for u in item['sources']:
                            link = u['url']
                            nazwa = url['title']
                            name = cleantitle.normalize(nazwa)
                            words = name.split(" ")
                            data.append({
                                'quality': item['sublabel'],
                                'lang': self.get_lang_by_type(item['label'])[0],
                                'link': link
                            })
            for d in data:
                if "Wysoka" in d['quality'] or "720" in d['quality'] or "1080" in d['quality']:
                    sources.append(
                        {
                            "source": 'Filman',
                            "quality": "HD",
                            "language": d['lang'],
                            "url": d['link'],
                            "direct": True,
                            "debridonly": False,
                        }
                    )
                elif "rednia" in d['quality']:
                    sources.append(
                        {
                            "source": 'Filman',
                            "quality": "SD",
                            "language": d['lang'],
                            "url": d['link'],
                            "direct": True,
                            "debridonly": False,
                        }
                    )
                elif "Niska" in d['quality']:
                    sources.append(
                        {
                            "source": 'Filman',
                            "quality": "SD",
                            "language": d['lang'],
                            "url": d['link'],
                            "direct": True,
                            "debridonly": False,
                        }
                    )
                else:
                    sources.append(
                        {
                            "source": 'Filman',
                            "quality": "SD",
                            "language": d['lang'],
                            "url": d['link'],
                            "direct": True,
                            "debridonly": False,
                        }
                    )
            return sources
        except Exception as e:
            log_exception()
            return sources

    def get_lang_by_type(self, lang_type):
        if "dubbing" in lang_type.lower():
            if "kino" in lang_type.lower():
                return "pl", "Dubbing Kino"
            return "pl", "Dubbing"
        elif "napisy pl" in lang_type.lower():
            return "pl", "Napisy"
        elif "napisy" in lang_type.lower():
            return "pl", "Napisy"
        elif "lektor pl" in lang_type.lower():
            return "pl", "Lektor"
        elif "lektor" in lang_type.lower():
            return "pl", "Lektor"
        elif "POLSKI" in lang_type.lower():
            return "pl", None
        elif "pl" in lang_type.lower():
            return "pl", None
        return "en", None

    def resolve(self, url):
        link = str(url).replace('\/', '/')
        return str(link)

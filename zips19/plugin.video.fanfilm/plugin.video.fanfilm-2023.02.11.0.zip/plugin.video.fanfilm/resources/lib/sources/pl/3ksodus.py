# -*- coding: utf-8 -*-
"""
    FanFilm Add-on
    Copyright (C) 2018 :)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import re
from ast import literal_eval
from urllib.parse import quote, urljoin

from ptw.libraries import source_utils
from ptw.libraries import cleantitle
from ptw.libraries import client
from ptw.debug import log_exception


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["3ksodus"]
        self.base_link = "https://3ksodus.cc/"
        self.search_link = f"search?value={{}}"


    def search(self, title, localtitle, year, is_movie_search):
        try:
            titles = []
            titles.append(cleantitle.normalize(cleantitle.getsearch(title)))
            titles.append(cleantitle.normalize(cleantitle.getsearch(localtitle)))

            for title in titles:
                try:
                    url = urljoin(self.base_link, self.search_link)
                    url = url.format(quote(title))
                    result = client.request(url).replace('\r', '').replace('\n', '')
                    if is_movie_search:
                        result = re.findall('links_array = \[\](.*?)movies.push\(movie\);', result)
                    else:
                        result = re.findall('links_array = \[\](.*?)movies.push\(serie\);', result)
                except:
                    continue

                for item in result:
                    try:
                        if is_movie_search:
                            parse_titles = re.findall('\"title\": \'(.*?)\'', item)[0].split(' / ')
                            parse_titles = [cleantitle.normalize(cleantitle.getsearch(t)) for t in parse_titles]
                            if not title in parse_titles:
                                continue
                            if re.search(f'\"year\": JSON.parse\(\'\"{year}\"\'\)', item):
                                res = re.findall("obj_link\['link'] = \'(.*?)\'.*?obj_link\['version'] = \'(.*?)\'", item)
                                links = repr(res)
                                return links
                            else:
                                continue
                        else:
                            parse_titles = re.findall('serie = \{.*?\"title\": \'(.*?)\'', item)[0].split(' / ')
                            parse_titles = [cleantitle.normalize(cleantitle.getsearch(t)) for t in parse_titles]
                            if not title in parse_titles:
                                continue
                            #szukanie wg roku
#                            if re.search(f'\"year\": JSON.parse\(\'\"{year}\"\'\)', item):
                            #bloki episodów  - możliwe dodanie po tytule
                            ep_blocks = re.findall('obj_link = \{} (.*?) episodes_list.push\(episode\)', item)
                            links = repr(ep_blocks)
                            return links
#                            else:
#                                continue
                    except:
                        continue
        except Exception as e:
            log_exception()
            return

    def movie(self, imdb, title, localtitle, aliases, year):
        res = self.search(title, localtitle, year, True)
        return res

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        res = self.search(tvshowtitle, localtvshowtitle, year, False)
        return res

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):

        pattern = f's{int(season):02d}e{int(episode):02d}'
        episodes = literal_eval(url)
        for episod in episodes:
            if re.search(f"\"title\": '\[{pattern}\] ", episod):
                ep = re.findall("obj_link\['link'] = \'(.*?)\'.*?obj_link\['version'] = \'(.*?)\'", episod)
                ep = repr(ep)
                return ep
            else:
                continue

    def sources(self, url, hostDict, hostprDict):

        sources = []
        try:
            if url == None:
                return sources
            results = literal_eval(url)

            for item in results:
                try:
                    link = item[0]
                    valid, host = source_utils.is_host_valid(link, hostDict)
                    sources.append(
                        {
                            "source": host,
                            "quality": "SD",
                            "language": "pl",
                            "url": link,
                            "info": item[1],
                            "direct": False,
                            "debridonly": False,
                        }
                    )
                except:
                    continue
            return sources
        except:
            log_exception()
            return sources


    def resolve(self, url):
        return url

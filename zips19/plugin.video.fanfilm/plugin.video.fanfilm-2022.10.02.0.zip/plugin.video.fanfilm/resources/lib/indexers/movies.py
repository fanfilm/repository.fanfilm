# -*- coding: utf-8 -*-

"""
    Fanfilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import datetime
import json
import os
import re
import sys
import urllib
import requests

try:
    import urllib.parse as urllib
except:
    pass
from resources.lib.indexers import navigator
from ptw.libraries import cache
from ptw.libraries import cleangenre
from ptw.libraries import cleantitle
from ptw.libraries import client
from ptw.libraries import control
from ptw.libraries import metacache
from ptw.libraries import playcount
from ptw.libraries import trakt
from ptw.libraries import utils
from ptw.libraries import views
from ptw.libraries import apis
from ptw.libraries import log_utils
from ptw.libraries.utils import convert

params = (
    dict(urllib.parse_qsl(sys.argv[2].replace("?", "")))
    if len(sys.argv) > 1
    else dict()
)
action = params.get("action")

class movies:
    def __init__(self):
### BASE ###
        self.list = []
        self.session = requests.Session()
        self.imdb_link = "http://www.imdb.com"
        self.trakt_link = "https://api.trakt.tv"
        self.tmdb_link = "https://api.themoviedb.org/"
### SETTINGS ###TODO dodatkowe ustawienia
        self.moviessort = control.setting("movies.sort")
        if self.moviessort == "0":
            self.moviessort = "popularity.desc"
        elif self.moviessort == "1":
            self.moviessort = "primary_release_date.desc"
        self.user = str(control.setting("fanart.tv.user")) + str( 
            control.setting("tm.user")
        )
        self.trakt_user = control.setting("trakt.user").strip()
        self.imdb_user = control.setting("imdb.user").replace("ur", "")
        self.lang = control.apiLanguage()["tmdb"]
        self.tm_user = control.setting("tm.user") or apis.tmdb_API
        self.tmdbuser = control.setting("tmdb.username") or "me"
        self.tmdb_sessionid = control.setting("tmdb.sessionid") or ""

    ## DATY ##
        self.datetime = datetime.datetime.utcnow() - datetime.timedelta(hours=5)
        self.systime = (self.datetime).strftime("%Y%m%d%H%M%S%f")
        self.year_date = (self.datetime - datetime.timedelta(days=365)).strftime(
            "%Y-%m-%d"
        )
        self.today_date = (self.datetime).strftime("%Y-%m-%d")
        self.hidecinema = control.setting("hidecinema")
        self.hidecinema_rollback = int(control.setting("hidecinema.rollback"))
        self.hidecinema_rollback2 = self.hidecinema_rollback * 30
        self.hidecinema_date = (
                datetime.date.today() - datetime.timedelta(days=self.hidecinema_rollback2)
        ).strftime("%Y-%m")
        self.cinemanow_date = (datetime.date.today() - datetime.timedelta(60))
        if self.hidecinema == "true": 
             self.today_date = self.hidecinema_date

### LINKI API DO TMDB ###
        self.metasearch = (self.tm_user, self.lang, self.today_date) #TODO dodatkowe ustawienia
        self.tmdb_movie_search = 'https://api.themoviedb.org/3/search/movie?api_key=%s&language=%s&sort_by=popularity.desc&query=%%s&page=1' % (
            self.tm_user, self.lang
        )
        self.tmdb_discover = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=%s&primary_release_date.lte=%s&vote_count.gte=100&include_adult=false&include_video=false&%%s&page=1' % (
            self.tm_user, self.lang, self.moviessort, self.today_date
        )
        self.tmdb_discover_years = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=popularity.desc&primary_release_date.gte=%%s&primary_release_date.lte=%%s&vote_count.gte=100&include_adult=false&include_video=false&page=1' % (
            self.tm_user, self.lang
        )
        self.tmdb_trending_link = 'https://api.themoviedb.org/3/trending/movie/week?api_key=%s&language=%s&primary_release_date.lte=%s&vote_count.gte=100&include_adult=false&include_video=false&page=1' % self.metasearch
        self.tmdb_popular_link = 'https://api.themoviedb.org/3/movie/popular?api_key=%s&language=%s&primary_release_date.lte=%s&include_adult=false&include_video=false&page=1' % self.metasearch
        self.tmdb_new_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=primary_release_date.desc&primary_release_date.lte=%s&vote_count.gte=100&include_adult=false&include_video=false&%%s&page=1' % (
            self.tm_user, self.lang, self.today_date
        )
        self.tmdb_views_link = 'https://api.themoviedb.org/3/trending/movie/week?api_key=%s&language=%ssort_by=vote_count.desc&primary_release_date.lte=%s&vote_count.gte=1000&include_adult=false&include_video=false&page=1' % self.metasearch
        self.tmdb_similar = 'https://api.themoviedb.org/3/movie/%%s/similar?api_key=%s&language=%s&sort_by=%s&primary_release_date.lte=%s&vote_count.gte=100&include_adult=false&include_video=false&page=1' % (
            self.tm_user, self.lang, self.moviessort, self.today_date
        )
        self.tmdb_vod_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=primary_release_date.desc&primary_release_date.lte=%s&vote_count.gte=100&include_adult=false&include_video=false&with_watch_providers=8|119|2|245|76|250|384|350|701|505|337&page=1' % self.metasearch
        self.tmbd_cinema_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=primary_release_date.desc&release_date.gte=%s&release_date.lte=%s&with_release_type=3&vote_count.gte=100&include_adult=false&include_video=false&page=1' % (
            self.tm_user, self.lang, self.cinemanow_date, self.today_date
        )
        self.tmdb_personid_link = 'https://api.themoviedb.org/3/search/person?api_key=%s&language=%s&query=%%s&page=1&include_adult=false' % (
            self.tm_user, self.lang
        )
        self.tmdb_person_link = 'https://api.themoviedb.org/3/person/%%s/movie_credits?api_key=%s&language=%s&page=1&include_adult=false' % (
            self.tm_user, self.lang
        )
### TMDB USER ###
        self.tmdb_user_lists = 'https://api.themoviedb.org/3/account/%s/lists?api_key=%s&language=%s&session_id=%s&page=1' % (
            self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid
        )
       
        self.tmdb_lists_link = (
                'https://api.themoviedb.org/3/list/%%s?api_key=%s&language=%s&page=1&include_adult=false' % (
            self.tm_user, self.lang)
        )
        self.tmdbuserwatchlist_link = 'https://api.themoviedb.org/3/account/%s/watchlist/movies?api_key=%s&language=%s&session_id=%s&page=1&sort_by=created_at.desc&page=1' % (
            self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid
        )
        self.tmdbuserfavourite_link = 'https://api.themoviedb.org/3/account/%s/favorite/movies?api_key=%s&language=%s&session_id=%s&page=1&sort_by=created_at.desc&page=1' % (
            self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid
        )

### SUPERINFO ###
        self.tmdb_arts = 'https://api.themoviedb.org/3/movie/%s/images?api_key=%s' % (
            '%s', self.tm_user)
        self.tmdb_providers = 'https://api.themoviedb.org/3/movie/%s/watch/providers?api_key=%s' % ('%s', self.tm_user)
        self.tmdb_by_imdb = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % (
        '%s', self.tm_user)
        self.tmdb_api_link = 'https://api.themoviedb.org/3/movie/%s?api_key=%s&language=%s&append_to_response=credits,external_ids' % (
        '%s', self.tm_user, self.lang)
        self.tm_img_link = "https://image.tmdb.org/t/p/w%s%s"
        self.fanart_tv_user = control.setting("fanart.tv.user") or apis.fanarttv_client_key
        self.fanart_tv_API_key = control.setting("fanart.tv.dev") or apis.fanarttv_API_key
        self.fanart_tv_headers = {"api-key": self.fanart_tv_API_key,
                                  "client-key": self.fanart_tv_user}
        self.fanart_tv_art_link = "http://webservice.fanart.tv/v3/movies/%s"
        self.fanart_tv_level_link = "https://webservice.fanart.tv/v3/level" #?
        self.tm_art_link = (
                "https://api.themoviedb.org/3/movie/%s/images?api_key=%s&language=en-US&include_image_language=en,%s,null"
                % ("%s", self.tm_user, self.lang)
        )

## TRAKT - POJEDYNCZE LINKI ##
        self.traktlists_link = "http://api.trakt.tv/users/me/lists"
        self.traktlikedlists_link = (
            "http://api.trakt.tv/users/likes/lists?limit=1000000"
        )
        self.traktlist_link = "http://api.trakt.tv/users/%s/lists/%s/items"
        self.traktcollection_link = "http://api.trakt.tv/users/me/collection/movies"
        self.traktwatchlist_link = "http://api.trakt.tv/users/me/watchlist/movies"
        self.traktfeatured_link = "http://api.trakt.tv/recommendations/movies?limit=40"
        self.trakthistory_link = (
            "http://api.trakt.tv/users/me/history/movies?limit=40&page=1"
        )
## IMDB - POJEDYNCZE LINKI ##
        self.boxoffice_link = 'https://api.trakt.tv/movies/boxoffice'
        self.imdblists_link = (
        "https://www.imdb.com/user/ur%s/lists?tab=all&sort=mdfd&order=desc&filter=titles"
        % self.imdb_user
        )
        self.imdb_awards = 'https://www.imdb.com/search/title?groups=%s&sort=year,desc&count=40&start=1'
        self.imdblist_link = "https://www.imdb.com/list/%s/?view=detail&sort=alpha,asc&title_type=movie,short,tvMovie,tvSpecial,video&count=40&start=1"
        self.imdblist2_link = "https://www.imdb.com/list/ls%s/?view=detail&sort=date_added,desc&title_type=movie,short,tvMovie,tvSpecial,video&count=40&start=1"
        self.imdbwatchlist_link = (
                "https://www.imdb.com/user/ur%s/watchlist?sort=alpha,asc&count=40&start=1" % self.imdb_user
        )
        self.imdbwatchlist2_link = (
                "https://www.imdb.com/user/ur%s/watchlist?sort=date_added,desc&count=40&start=1"
                % self.imdb_user
        )
        self.imdbUserLists_link = (
                "https://www.imdb.com/list/ls%s/?view=detail&sort=alpha,asc&title_type=movie,tvMovie&count=40&start=1"
        )

### Katalogi filmów ###

## Języki ##\
    def languages(self):
        languages = [
            ("Arabski", "ar"),
            ("Bośniacki", "bs"),
            ("Bułgarski", "bg"),
            ("Chiński", "zh"),
            ("Chorwacki", "hr"),
            ("Czeski", "cs"),
            ("Duński", "nl"),
            ("Angielski", "en"),
            ("Fiński", "fi"),
            ("Francuski", "fr"),
            ("Niemiecki", "de"),
            ("Grecki", "el"),
            ("Hebrajski", "he"),
            ("Hindi ", "hi"),
            ("Węgierski", "hu"),
            ("Islandzki", "is"),
            ("Włoski", "it"),
            ("Japoński", "ja"),
            ("Koreański", "ko"),
            ("Macedoński", "mk"),
            ("Norweski", "no"),
            ("Perski", "fa"),
            ("Polski", "pl"),
            ("Portugalski", "pt"),
            ("Punjabi", "pa"),
            ("Rumuński", "ro"),
            ("Rosyjski", "ru"),
            ("Serbski", "sr"),
            ("Słowacki", "sl"),
            ("Hiszpański", "es"),
            ("Szwedzki", "sv"),
            ("Turecki", "tr"),
            ("Ukraiński", "uk"),
        ]

        for i in languages:
            self.list.append(
                {
                    "name": i[0],
                    "url": self.tmdb_discover % ('with_original_language='+i[1]),
                    "image": 'languages.png',
                    "action": "movies",
                }
            )
        self.addDirectory(self.list)
        return self.list

## Certyfikaty ##
    def certifications(self):
        certificates = ["G", "PG", "PG-13", "R", "NC-17"]

        for i in certificates:
            self.list.append(
                {
                    "name": str(i),
                    "url": self.tmdb_discover % ('certification_country=US&certification='+str(i)),
                    "image": "certificates.png",
                    "action": "movies",
                }
            )
        self.addDirectory(self.list)
        return self.list

## Lata ##
    def years(self):
        year = self.datetime.strftime("%Y")
        navigator.navigator().addDirectoryItem(32630, "movieYearsTop", "years.png", "DefaultMovies.png")
        for i in range(int(year) - 0, 1900, -1):
            self.list.append(
                {
                    "name": str(i),
                    "url": self.tmdb_discover % ('year='+str(i)),
                    "image": "years.png",
                    "action": "movies",
                }
            )
        self.addDirectory(self.list)
        return self.list

## Lata TOP ##
    def years_top(self):
        year = (self.datetime.strftime('%Y'))
        dec = int(year[:3]) * 10
        for i in range(dec, 1890, -10): self.list.append({'name': str(i) + '-' + str(i+9), 'url': self.tmdb_discover_years % (str(i), str(i+9)), 'image': 'years.png', 'action': 'movies'})
        self.addDirectory(self.list)
        return self.list
## Gatunki ##
    def genres(self):
        genres = [
            ("28", "Akcja", "action.jpg"),
            ("12", "Przygodowy", "adventure.jpg"),
            ("16", "Animacja", "animation.jpg"),
            ("35", "Komedia", "comedy.jpg"),
            ("80", "Kryminał", "crime.jpg"),
            ("99", "Dokumentalny", "documentary.jpg"),
            ("18", "Dramat", "drama.jpg"),
            ("10751", "Familijny", "family.jpg"),
            ("14", "Fantasy", "fantasy.jpg"),
            ("36", "Historyczny", "history.jpg"),
            ("27", "Horror", "horror.jpg"),
            ("10402", "Muzyczny", "music.jpg"),
            ("9648", "Tajemnica", "mystery.jpg"),
            ("10749", "Romans", "romance.jpg"),
            ("878", "Sci-Fi", "scifi.jpg"),
            ("53", "Thriller", "thriller.jpg"),
            ("10752", "Wojenny", "war.jpg"),
            ("37", "Western", "western.jpg")
        ]
        for i in genres:
            self.list.append(
                {
                    "name": i[1],
                    "url": self.tmdb_discover % ('with_genres='+i[0]),
                    "image": i[2],
                    "action": "movies",
                }
            )
        self.addDirectory(self.list)
        return self.list

## Nagrody ##
    def awards(self):
        awards = [
            ("oscar_winner", "Oscary - najlepszy film", "oscar-winners.png"),
            ("oscar_nominee", "Oscary - najlepszy film - nominowane", "oscar-winners.png"),
            ("oscar_best_picture_winner", "Oscary - najlepszy reżyser", "oscar-winners.png"),
            ("oscar_best_picture_nominees", "Oscary - najlepszy reżyser - nominowane", "oscar-winners.png"),
            ("oscar_best_director_winner", "Oscary - wszystkie kategorie", "oscar-winners.png"),
            ("oscar_best_director_nominees", "Oscary - wszystkie kategorie - nominowane", "oscar-winners.png"),
            ("razzie_winner", "Złote Maliny", "razzie_winners.png"),
            ("razzie_nominee", "Złote Maliny - nominowane", "razzie_winners.png"),
        ]
        for i in awards:
            self.list.append(
                {
                    "name": i[1],
                    "url": self.imdb_awards % (i[0]),
                    "image": i[2],
                    "action": "movies",
                }
            )
        self.addDirectory(self.list)
        return self.list

## Osoby - wyszukiwanie##
    def persons(self, url):
        tmdb_results = requests.get(url).json()
        page = tmdb_results.get('page', 0)
        total = tmdb_results.get('total_pages', 0)
        if page < total and 'page=' in url:
            next = re.sub(r'page=\d+', f'page={page+1}', url)
        else:
            next = ''
        for item in tmdb_results['results']: 
            if item.get('known_for_department') == "Acting":
                if item.get('profile_path'):
                    photo = str("http://www.themoviedb.org/t/p/w300_and_h450_bestv2" + item.get('profile_path', ''))
                else:
                    photo = "people.png"
                self.list.append(
                    {
                        "name": item.get('name'),
                        "url": self.tmdb_person_link % str(item.get('id')),
                        "image": photo,
                        "action": "movies",
                    }
                )

        self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
        self.addDirectory(self.list)
        return self.list
        

## Podobne filmy ##
    def similar(self, tmdb):
        movies.get(self, self.tmdb_similar % tmdb)

### SEARCH ###
    def search(self):

        navigator.navigator().addDirectoryItem(
            32603, "movieSearchnew", "search.png", "DefaultMovies.png"
        )

        from sqlite3 import dbapi2 as database

        dbcon = database.connect(control.searchFile)
        dbcur = dbcon.cursor()

        try:
            dbcur.executescript(
                "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
            )
        except:
            pass

        dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
        lst = []

        delete_option = False
        for (id, term) in dbcur.fetchall():
            if term not in str(lst):
                delete_option = True
                navigator.navigator().addDirectoryItem(
                    term,
                    "movieSearchterm&name=%s" % term,
                    "search.png",
                    "DefaultMovies.png",
                )
                lst += [(term)]
        dbcur.close()

        if delete_option:
            navigator.navigator().addDirectoryItem(
                32605, "clearCacheSearch", "tools.png", "DefaultAddonProgram.png"
            )

        navigator.navigator().endDirectory()

    def search_new(self):
        control.idle()
        t = control.lang(32010)
        k = control.keyboard("", t)
        k.doModal()
        q = k.getText() if k.isConfirmed() else None

        if q == None or q == "":
            return

        q = cleantitle.normalize(q)  # for polish characters
        control.busy()

        from sqlite3 import dbapi2 as database

        dbcon = database.connect(control.searchFile)
        dbcur = dbcon.cursor()
        dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, q))
        dbcon.commit()
        dbcur.close()
        movies.get(self, self.tmdb_movie_search % urllib.quote_plus(q))
        control.idle()

    def search_term(self, name):
        control.busy()
        movies.get(self, self.tmdb_movie_search % urllib.quote_plus(name))
        control.idle()

### SEARCH PERSONS ### TODO - historia
    def person(self):
        try:
            control.idle()

            t = control.lang(32010)
            k = control.keyboard("", t)
            k.doModal()
            q = k.getText() if k.isConfirmed() else None

            if q == None or q == "":
                return

            q = cleantitle.normalize(q)  # for polish characters
            control.busy()
            # url = self.persons_link + urllib.quote_plus(q)
            # url = '%s?action=moviePersons&url=%s' % (sys.argv[0], urllib.quote_plus(url))
            movies.persons(self, self.tmdb_personid_link % urllib.quote_plus(q))
            control.idle()
        except Exception as e:
            print(e)
            return

### SCRAPERY API/STRON ###

### TMDB ###
    def tmdb_list(self, url):
        tmdb_results = requests.get(url).json()
        page = tmdb_results.get('page', 0)
        total = tmdb_results.get('total_pages', 0)
        if page < total and 'page=' in url:
            next = re.sub(r'page=\d+', f'page={page+1}', url)
        else:
            next = ''
        if 'results' in tmdb_results:
            items = tmdb_results['results']
        elif 'items' in tmdb_results:
            items = tmdb_results['items']
        elif 'parts' in tmdb_results:
            items = tmdb_results['parts']
        elif 'cast' in tmdb_results:
            items = tmdb_results['cast']
        for item in items:
            #if item.get('original_language') != 'ru':
            if item.get('media_type') != 'tv':
                self.list.append(
                    {
                        "title": item.get('title', ''),
                        "originaltitle": item.get('original_title', ''),
                        "year": item.get('release_date', '')[0:4],
                        "tmdb": str(item.get('id', '')),
                        'plot': item.get('overview', ''),
                        'votes': item.get('vote_count', ''),
                        'rating': item.get('vote_average', ''),
                        "tvdb": "0",
                        "imdb": "0",
                        "poster": "0",
                        "next": next
                    })
        return self.list
        
### TRAKT ###
    def trakt_list(self, url, user):
        try:
            q = dict(urllib.parse_qsl(urllib.urlsplit(url).query))
            # tmdb_results = self.find_Movie_ID(q['query'])
            q.update({"extended": "full"})
            q = (urllib.urlencode(q)).replace("%2C", ",")
            u = url.replace("?" + urllib.urlparse(url).query, "") + "?" + q
            # u2 = f'https://api.trakt.tv/search/tmdb/%s?type=movie'

            result = trakt.getTraktAsJson(u)
            result = convert(result)
            items = []
            for i in result:
                try:
                    items.append(i["movie"])
                except:
                    pass
            if len(items) == 0:
                items = result
        except Exception as e:
            return

        try:
            q = dict(urllib.parse_qsl(urllib.urlsplit(url).query))
            if not int(q["limit"]) == len(items):
                raise Exception()
            q.update({"page": str(int(q["page"]) + 1)})
            q = (urllib.urlencode(q)).replace("%2C", ",")
            next = url.replace("?" + urllib.urlparse(url).query, "") + "?" + q
        except:
            next = ""

        for item in items:
            try:
                title = item["title"]
                title = client.replaceHTMLCodes(title)

                year = item["year"]
                year = re.sub("[^0-9]", "", str(year))
                year_now = self.datetime.strftime("%Y")

                if int(year) > int(year_now):
                    raise Exception()

                imdb = item["ids"]["imdb"]
                if imdb == None or imdb == "":
                    raise Exception()
                imdb = "tt" + re.sub("[^0-9]", "", str(imdb))
                tmdb = str(item.get("ids", {}).get("tmdb", 0))

                try:
                    premiered = item["released"]
                except:
                    premiered = "0"
                try:
                    premiered = re.compile("(\d{4}-\d{2}-\d{2})").findall(premiered)[0]
                except:
                    premiered = "0"

                try:
                    genre = item["genres"]
                except:
                    genre = "0"
                genre = [i.title() for i in genre]
                if genre == []:
                    genre = "0"
                genre = " / ".join(genre)

                try:
                    duration = str(item["runtime"])
                except:
                    duration = "0"
                if duration == None:
                    duration = "0"

                try:
                    rating = str(item["rating"])
                except:
                    rating = "0"
                if rating == None or rating == "0.0":
                    rating = "0"

                try:
                    votes = str(item["votes"])
                except:
                    votes = "0"
                try:
                    votes = str(format(int(votes), ",d"))
                except:
                    pass
                if votes == None:
                    votes = "0"

                try:
                    mpaa = item["certification"]
                except:
                    mpaa = "0"
                if mpaa == None:
                    mpaa = "0"

                try:
                    plot = item["overview"]
                except:
                    plot = "0"
                if plot == None:
                    plot = "0"
                plot = client.replaceHTMLCodes(plot)

                try:
                    tagline = item["tagline"]
                except:
                    tagline = "0"
                if tagline == None:
                    tagline = "0"
                tagline = client.replaceHTMLCodes(tagline)

                self.list.append(
                    {
                        "title": title,
                        "originaltitle": title,
                        "year": year,
                        "premiered": premiered,
                        "genre": genre,
                        "duration": duration,
                        "rating": rating,
                        "votes": votes,
                        "mpaa": mpaa,
                        "plot": plot,
                        "tagline": tagline,
                        "imdb": imdb,
                        "tmdb": tmdb,
                        "tvdb": "0",
                        "poster": "0",
                        "next": next,
                    }
                )
            except:
                pass

        return self.list

### IMDB ###
    def imdb_list(self, url):
        try:
            for i in re.findall("date\[(\d+)\]", url):
                url = url.replace(
                    "date[%s]" % i,
                    (self.datetime - datetime.timedelta(days=int(i))).strftime(
                        "%Y-%m-%d"
                    ),
                )

            def imdb_watchlist_id(url):
                return client.parseDOM(
                    client.request(url),
                    "meta",
                    ret="content",
                    attrs={"property": "pageId"},
                )[0]

            if url == self.imdbwatchlist_link:
                url = cache.get(imdb_watchlist_id, 8640, url)
                url = self.imdblist_link % url

            elif url == self.imdbwatchlist2_link:
                url = cache.get(imdb_watchlist_id, 8640, url)
                url = self.imdblist2_link % url
            result = client.request(url)
            #result = result.replace("\n", " ")
            items = client.parseDOM(result, "div", attrs={"class": "lister-item .+?"})
            items += client.parseDOM(result, "div", attrs={"class": "list_item.+?"})
        except:
            return

        try:
            next = client.parseDOM(
                result, "a", ret="href", attrs={"class": ".+?ister-page-nex.+?"}
            )

            if len(next) == 0:
                next = client.parseDOM(result, "div", attrs={"class": "pagination"})[0]
                next = zip(
                    client.parseDOM(next, "a", ret="href"), client.parseDOM(next, "a")
                )
                next = [i[0] for i in next if "Next" in i[1]]

            next = url.replace(
                urllib.urlparse(url).query, urllib.urlparse(next[0]).query
            )
            next = client.replaceHTMLCodes(next)
        #            next = next.encode("utf-8")
        except:
            next = ""

        for item in items:
            try:
                title = client.parseDOM(item, "a")[1]
                title = client.replaceHTMLCodes(title)
                #                title = title.encode("utf-8").decode()

                year = client.parseDOM(
                    item, "span", attrs={"class": "lister-item-year.+?"}
                )
                year += client.parseDOM(item, "span", attrs={"class": "year_type"})
                try:
                    if type(year) == list:
                        year = year[0]
                    year = re.compile("(\d{4})").findall(year)[0]
                except:
                    year = "0"
                #                year = year.encode("utf-8")

                if int(year) > int((self.datetime).strftime("%Y")):
                    raise Exception()

                imdb = client.parseDOM(item, "a", ret="href")[0]
                imdb = re.findall("(tt\d*)", imdb)[0]
                #                imdb = imdb.encode("utf-8")
                try:
                    poster = client.parseDOM(item, "img", ret="loadlate")[0]
                except:
                    poster = "0"
                if "/nopicture/" in poster:
                    poster = "0"
                poster = re.sub(
                    "(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.", "_SX500.", poster
                )
                poster = client.replaceHTMLCodes(poster)
                #                poster = poster.encode("utf-8")

                try:
                    genre = client.parseDOM(item, "span", attrs={"class": "genre"})[0]
                except:
                    genre = "0"
                genre = " / ".join([i.strip() for i in genre.split(",")])
                if genre == "":
                    genre = "0"
                genre = client.replaceHTMLCodes(genre)
                #                genre = genre.encode("utf-8")

                try:
                    duration = re.findall("(\d+?) min(?:s|)", item)[-1]
                except:
                    duration = "0"
                #                duration = duration.encode("utf-8")

                rating = "0"
                try:
                    rating = client.parseDOM(
                        item, "span", attrs={"class": "rating-rating"}
                    )[0]
                except:
                    pass
                try:
                    rating = client.parseDOM(rating, "span", attrs={"class": "value"})[
                        0
                    ]
                except:
                    rating = "0"
                try:
                    rating = client.parseDOM(
                        item, "div", ret="data-value", attrs={"class": ".*?imdb-rating"}
                    )[0]
                except:
                    pass
                if rating == "" or rating == "-":
                    rating = "0"
                rating = client.replaceHTMLCodes(rating)
                #                rating = rating.encode("utf-8")

                try:
                    votes = client.parseDOM(
                        item, "div", ret="title", attrs={"class": ".*?rating-list"}
                    )[0]
                except:
                    votes = "0"
                try:
                    votes = re.findall("\((.+?) vote(?:s|)\)", votes)[0]
                except:
                    votes = "0"
                if votes == "":
                    votes = "0"
                votes = client.replaceHTMLCodes(votes)
                #                votes = votes.encode("utf-8")

                try:
                    mpaa = client.parseDOM(
                        item, "span", attrs={"class": "certificate"}
                    )[0]
                except:
                    mpaa = "0"
                if mpaa == "" or mpaa == "NOT_RATED":
                    mpaa = "0"
                mpaa = mpaa.replace("_", "-")
                mpaa = client.replaceHTMLCodes(mpaa)
                #                mpaa = mpaa.encode("utf-8")

                try:
                    director = re.findall("Director(?:s|):(.+?)(?:\||</div>)", item)[0]
                except:
                    director = "0"
                director = client.parseDOM(director, "a")
                director = " / ".join(director)
                if director == "":
                    director = "0"
                director = client.replaceHTMLCodes(director)
                #                director = director.encode("utf-8")

                try:
                    cast = re.findall("Stars(?:s|):(.+?)(?:\||</div>)", item)[0]
                except:
                    cast = "0"
                cast = client.replaceHTMLCodes(cast)
                #                cast = cast.encode("utf-8")
                cast = client.parseDOM(cast, "a")
                if cast == []:
                    cast = "0"

                plot = "0"
                try:
                    plot = client.parseDOM(item, "p", attrs={"class": "text-muted"})[0]
                except:
                    pass
                try:
                    plot = client.parseDOM(
                        item, "div", attrs={"class": "item_description"}
                    )[0]
                except:
                    pass
                plot = plot.rsplit("<span>", 1)[0].strip()
                plot = re.sub("<.+?>|</.+?>", "", plot)
                if plot == "":
                    plot = "0"
                plot = client.replaceHTMLCodes(plot)
                #                plot = plot.encode("utf-8")

                self.list.append(
                    {
                        "title": title,
                        "originaltitle": title,
                        "year": year,
                        "genre": genre,
                        "duration": duration,
                        "rating": rating,
                        "votes": votes,
                        "mpaa": mpaa,
                        "director": director,
                        "cast": cast,
                        "plot": plot,
                        "tagline": "0",
                        "imdb": imdb,
                        "tmdb": "0",
                        "tvdb": "0",
                        "poster": poster,
                        "next": next,
                    }
                )
            except Exception as e:
                print(e)
                pass
        return self.list

### MOJE FILMY - LISTY FILMÓW ###
## Listy Użytkownika (TRAKT + IMDB + TMDB)
    def userlists(self):
        try:
            userlists = []
            if trakt.getTraktCredentialsInfo() == False:
                raise Exception()
            activity = trakt.getActivity()
        except:
            pass
        try:
            self.list = []
            if self.imdb_user == "":
                raise Exception()
            userlists += cache.get(self.imdb_user_list, 24, self.imdblists_link)
        except:
            pass
        try:
            self.list = []
            if self.tmdb_sessionid == "":
                raise Exception()
            userlists += cache.get(self.tmdblist, 24, self.tmdb_user_lists)
        except:
            pass
        try:
            self.list = []
            if trakt.getTraktCredentialsInfo() == False:
                raise Exception()
            try:
                if activity > cache.timeout(
                        self.trakt_user_list, self.traktlikedlists_link, self.trakt_user
                ):
                    raise Exception()
                userlists += cache.get(
                    self.trakt_user_list,
                    24,
                    self.traktlikedlists_link,
                    self.trakt_user,
                )
            except:
                userlists += cache.get(
                    self.trakt_user_list, 24, self.traktlikedlists_link, self.trakt_user
                )
        except:
            pass
    
        self.list = userlists
        for i in range(0, len(self.list)):
            self.list[i].update({"action": "movies"})
        self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
        self.addDirectory(self.list, queue=True)
        return self.list



### TRAKT ###
    def trakt_user_list(self, url, user):
        try:
            items = trakt.getTraktAsJson(url)
        except:
            pass

        for item in items:
            try:
                try:
                    name = item["list"]["name"]
                except:
                    name = item["name"]
                name = client.replaceHTMLCodes(name)

                try:
                    url = (
                        trakt.slug(item["list"]["user"]["username"]),
                        item["list"]["ids"]["slug"],
                    )
                except:
                    url = ("me", item["ids"]["slug"])
                url = self.traktlist_link % url
                #                url = url.encode("utf-8")

                self.list.append({"name": name, "url": url, "context": url, "image": "trakt.png",})
            except:
                pass

        self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
        return self.list

## TMDB##
    def tmdblist(self, url):
        #url = self.tmdb_user_lists
        tmdb_results = requests.get(url).json()
        page = tmdb_results.get('page', 0)
        total = tmdb_results.get('total_pages', 0)
        if page < total and 'page=' in url:
            next = re.sub(r'page=\d+', f'page={page+1}', url)
        else:
            next = ''
        if 'results' in tmdb_results:
            items = tmdb_results['results']
        elif 'items' in tmdb_results:
            items = tmdb_results['items']
        elif 'parts' in tmdb_results:
            items = tmdb_results['parts']
        elif 'cast' in tmdb_results:
            items = tmdb_results['cast']
        for item in items:
            #if item.get('original_language') != 'ru':
            self.list.append(
                {
                    "name": item.get('name'),
                    "url": self.tmdb_lists_link % str(item.get('id')),
                    "context": self.tmdb_lists_link % str(item.get('id')),
                    "image": "tmdb.png",
                }
            )
#        self.addDirectory(self.list)
        return self.list

### IMDB ###
    def imdb_user_list(self, url):
        try:
            result = client.request(url)
            items = client.parseDOM(
                result, "li", attrs={"class": "ipl-zebra-list__item user-list"}
            )
        except:
            pass

        for item in items:
            try:
                name = client.parseDOM(item, "a")[0]
                name = client.replaceHTMLCodes(name)
                #                name = name.encode("utf-8")

                url = client.parseDOM(item, "a", ret="href")[0]
                url = url.split("/list/", 1)[-1].strip("/")
                url = self.imdblist_link % url
                url = client.replaceHTMLCodes(url)
                #                url = url.encode("utf-8")

                self.list.append({"name": name, "url": url, "context": url, "image": "imdb.png",})
            except:
                pass

        self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
        return self.list

### GET ###
    def get(self, url, idx=True, create_directory=True):
        try:
            try:
                url = getattr(self, url + "_link")
            except:
                pass
            try:
                u = urllib.urlparse(url).netloc.lower()
            except:
                pass

            if u in self.trakt_link and "/users/" in url:
                try:
                    if url == self.trakthistory_link:
                        raise Exception()
                    if not "/users/me/" in url:
                        raise Exception()
                    if trakt.getActivity() > cache.timeout(
                            self.trakt_list, url, self.trakt_user
                    ):
                        raise Exception()
                    self.list = cache.get(self.trakt_list, 720, url, self.trakt_user)
                except:
                    self.list = cache.get(self.trakt_list, 0, url, self.trakt_user)

                if "/users/me/" in url and "/collection/" in url:
                    self.list = sorted(
                        self.list, key=lambda k: utils.title_key(k["title"])
                    )

                if idx == True:
                    self.worker()

            elif u in self.tmdb_link:
                self.list = cache.get(self.tmdb_list, 1, url)
                if idx == True:
                    self.worker()

            elif u in self.trakt_link:
                self.list = cache.get(self.trakt_list, 24, url, self.trakt_user)
                if idx == True:
                    self.worker()

            elif u in self.imdb_link and ("/user/" in url or "/list/" in url):
                self.list = cache.get(self.imdb_list, 0, url)
                if idx == True:
                    self.worker()

            elif u in self.imdb_link:
                self.list = cache.get(self.imdb_list, 24, url)
                if idx == True:
                    self.worker()

            if idx == True and create_directory == True:
                self.movieDirectory(self.list)
            return self.list
        except Exception as e:
            print(e)
            return

### WORKER ###
    def worker(self, level=1):
        self.meta = []
        total = len(self.list)

        for i in range(0, total):
            self.list[i].update({"metacache": False})

        self.list = metacache.fetch(self.list, self.lang, self.user)
        import threading

        for r in range(0, total, 40):
            threads = []
            for i in range(r, r + 40):
                if i <= total:
                    threads.append(threading.Thread(target=self.super_info, args=(i,)))

            [i.start() for i in threads]
            [i.join() for i in threads]

            if self.meta:
                metacache.insert(self.meta)

        self.list = [i for i in self.list]

### IMAGES ###
    def get_best_image(self, images, lang_key, vote_key=None, size_key=None, *, original_language=None):
        """Get best image from `images` by `*_key` keys, matching to languages."""

        # Brak danych.
        if not images:
            return

        # Lista pasujących języków, wraz z `None`, bo czasem w JSON jest: "iso_639_1":null.
        my_language_order = [self.lang, 'en', original_language, '00', '', None]
        # Słownik z kolejnością pasujących języków:
        langs = {lang: i for i, lang in enumerate(my_language_order)}

        # Lista obrazków trafiająca w języki, posortowana po *_key.
        # List jest odwrócona (reversed) gdyż liczymy, że dalsze pozycja mają lepszą jakość.
        best = sorted((x for x in reversed(images) if x[lang_key] in langs),
                      key=lambda x: (langs[x[lang_key]], vote_key and -x[vote_key], size_key and -x[size_key]))

        # Obrazek pasujący, lub jakikolwiek.
        if best:
            return best[0]
        return images[0]

### SUPER_INFO ###
    def super_info(self, i):
        try:
            if self.list[i]['metacache'] == True: return
            imdb = self.list[i]['imdb'] if 'imdb' in self.list[i] else '0'
            tmdb = self.list[i]['tmdb'] if 'tmdb' in self.list[i] else '0'
            list_title = self.list[i]['title']
            if tmdb == '0' and not imdb == '0':
                try:
                    url = self.tmdb_by_imdb % imdb
                    result = self.session.get(url, timeout=16).json()
                    id = result['movie_results'][0]
                    tmdb = id['id']
                    if not tmdb:
                        tmdb = '0'
                    else:
                        tmdb = str(tmdb)
                except:
                    pass
            id = tmdb if not tmdb == '0' else imdb
            if id == '0': raise Exception()

            en_url = self.tmdb_api_link % (id)  # + ',images'
            f_url = en_url + ',translations'  # ,images&include_image_language=en,%s,null' % self.lang
            url = en_url if self.lang == 'en' else f_url
            # log_utils.log('tmdb_url: ' + url)

            r = self.session.get(url, timeout=10)
            r.raise_for_status()
            r.encoding = 'utf-8'
            item = r.json()
            # log_utils.log('tmdb_item: ' + repr(item))

            if imdb == '0':
                try:
                    imdb = item['external_ids']['imdb_id']
                    if not imdb: imdb = '0'
                except:
                    imdb = '0'

            original_language = item.get('original_language', '')

            if self.lang == 'en':
                en_trans_item = None
            else:
                try:
                    translations = item['translations']['translations']
                    en_trans_item = [x['data'] for x in translations if x['iso_639_1'] == 'en'][0]
                except:
                    en_trans_item = {}

            name = item.get('title', '')

            original_name = item.get('original_title', '')
            en_trans_name = en_trans_item.get('title', '') if not self.lang == 'en' else None
 #           log_utils.log('self_lang: %s | original_language: %s | list_title: %s | name: %s | original_name: %s | en_trans_name: %s' % (self.lang, original_language, list_title, name, original_name, en_trans_name), 1)
            if self.lang == 'en':
                originaltitle = title = name
            elif self.lang == original_language:
                originaltitle = original_name
                title = list_title
            else:
                originaltitle = en_trans_name or original_name
                if (name == original_name and en_trans_name != ""):
                    title = en_trans_name
                else: 
                    title = name
            try:
                plot = None
                tagline = None
                title = title
                tagline = tagline
                
            except:
                pass      
            if not originaltitle: originaltitle = list_title
            if not title: title = list_title
            if not plot: plot = item.get('overview') or self.list[i]['plot']

            if not tagline: tagline = item.get('tagline') or '0'
            if not self.lang == 'en':
                if plot == '0' or plot == '':
                    en_plot = en_trans_item.get('overview', '')
                    if en_plot: plot = en_plot

                if tagline == '0':
                    en_tagline = en_trans_item.get('tagline', '')
                    if en_tagline: tagline = en_tagline

            premiered = item.get('release_date') or '0'

            try:
                _year = re.findall('(\d{4})', premiered)[0]
            except:
                _year = ''
            if not _year: _year = '0'
            year = item.get('year', _year)

            status = item.get('status') or '0'

            try:
                studio = item['production_companies'][0]['name']
            except:
                studio = ''
            if not studio: studio = '0'

            try:
                genre = item['genres']
                genre = [d['name'] for d in genre]
                genre = ' / '.join(genre)
            except:
                genre = ''
            if not genre: genre = '0'

            try:
                country = item['production_countries']
                country = [c['name'] for c in country]
                country = ' / '.join(country)
            except:
                country = ''
            if not country: country = '0'

            try:
                duration = str(item['runtime'])
            except:
                duration = ''
            if not duration: duration = '0'

            castwiththumb = []
            try:
                c = item['credits']['cast'][:30]
                for person in c:
                    _icon = person['profile_path']
                    icon = self.tm_img_link % ('185', _icon) if _icon else ''
                    castwiththumb.append({'name': person['name'], 'role': person['character'], 'thumbnail': icon})
            except:
                pass
            if not castwiththumb: castwiththumb = '0'

            try:
                crew = item['credits']['crew']
                director = ', '.join([d['name'] for d in [x for x in crew if x['job'] == 'Director']])
                writer = ', '.join(
                    [w['name'] for w in [y for y in crew if y['job'] in ['Writer', 'Screenplay', 'Author', 'Novel']]])
            except:
                director = writer = '0'

            my_language_order = ['pl', 'en', '00', ""]
            language_order = {key: i for i, key in enumerate(my_language_order)}
            posters_language = {}
            fanarts_language = {}
            banner_language = {}
            clearlogo_language = {}
            clearart_language = {}
            landscape_language = {}
            discart_language = {}
            poster1 = self.list[i].get("poster", "0")
            poster2 = None
            _fanart2 = None
            poster2_url = self.tmdb_arts % tmdb
            r2 = self.session.get(poster2_url, timeout=10)
            r2.raise_for_status()
            r2.encoding = 'utf-8'
            art = r2.json()
            _poster2 = self.get_best_image(art['posters'], 'iso_639_1', 'vote_count', original_language=original_language)
            if isinstance(_poster2, dict):
                posters_language.update({"tmdb": _poster2["iso_639_1"]})
                _poster2 = _poster2['file_path']
            if _poster2: poster2 = "https://image.tmdb.org/t/p/w500" + _poster2
            if isinstance(_fanart2, dict):
                _fanart2 = self.get_best_image(art['backdrops'], 'iso_639_1', 'vote_count', original_language=original_language)
                fanarts_language.update({"tmdb": _fanart2["iso_639_1"]})
                _fanart2 = _fanart2['file_path']
            if _fanart2: fanart2 = "https://image.tmdb.org/t/p/w1280" + _fanart2
            fanart_path = item.get('backdrop_path')
            if fanart_path:
                fanart1 = self.tm_img_link % ('1280', fanart_path)
            else:
                fanart1 = '0'

            poster3 = fanart3 = None
            banner = clearlogo = clearart = landscape = discart = '0'

            #if "tmdb" in posters_language.keys() and posters_language["tmdb"] == "pl":
            #    poster = poster2
            #elif "fanart" in posters_language.keys() and posters_language["fanart"] == "pl":
            #    poster = poster3
            #else:
            poster = poster2 or poster1 or poster3
            fanart = fanart1 or fanart2 or fanart3
            

            # log_utils.log('title: ' + title + ' - poster: ' + repr(poster))
            providers = ''
            try:
                r3 = self.session.get(self.tmdb_providers % tmdb, timeout=10)
                r3.raise_for_status()
                r3.encoding = 'utf-8'
                provider = r3.json()

                providerspage = provider['results'][self.lang.upper()]['link']
                providers_list = [i['provider_name'] for i in provider['results'][self.lang.upper()]['flatrate']]
                providers = {'link': providerspage, 'provider_list': providers_list}
            except:
                pass

            item = {'title': title, 'originaltitle': originaltitle, 'label': title, 'year': year, 'imdb': imdb,
                    'tmdb': tmdb, 'poster': poster, 'banner': banner, 'fanart': fanart,
                    'clearlogo': clearlogo, 'clearart': clearart, 'landscape': landscape, 'discart': discart,
                    'premiered': premiered, 'genre': genre, 'duration': duration,
                    'director': director, 'writer': writer, 'castwiththumb': castwiththumb, 'plot': plot,
                    'tagline': tagline, 'status': status, 'studio': studio, 'country': country,
                    'providers': providers
                    }
            item = dict((k, v) for k, v in item.items() if not v == '0')
            self.list[i].update(item)
            meta = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': '0', 'lang': self.lang, 'user': self.user, 'item': item}
            self.meta.append(meta)
        except Exception as e:
            print(e)
            pass

### MOVIE DIR ###
    def movieDirectory(self, items):
        if items == None or len(items) == 0:
            control.idle()
            sys.exit()
        sysaddon = sys.argv[0]

        syshandle = int(sys.argv[1])

        addonPoster, addonBanner = control.addonPoster(), control.addonBanner()

        addonFanart, settingFanart = control.addonFanart(), control.setting("fanart")

        traktCredentials = trakt.getTraktCredentialsInfo()

        multi_select = []

        try:
            isOld = False
            control.item().getArt("type")
        except:
            isOld = True

        isPlayable = (
            "true"
            if not "plugin" in control.infoLabel("Container.PluginName")
            else "false"
        )

        indicators = (
            playcount.getMovieIndicators(refresh=True)
            if action == "movies"
            else playcount.getMovieIndicators()
        )

        playbackMenu = (
            control.lang(32063)
            if control.setting("hosts.mode") == "2"
            else control.lang(32064)
        )

        watchedMenu = (
            control.lang(32068)
            if trakt.getTraktIndicatorsInfo() == True
            else control.lang(32066)
        )

        unwatchedMenu = (
            control.lang(32069)
            if trakt.getTraktIndicatorsInfo() == True
            else control.lang(32067)
        )

        queueMenu = control.lang(32065)

        traktManagerMenu = control.lang(32070)

        nextMenu = control.lang(32053)

        addToLibrary = control.lang(32551)

        addMultiToLibrary = control.lang(32635)

        for i in items:
            try:
                label = "%s (%s)" % (i.get("label") or i.get("title"), i["year"])
                imdb, tmdb, title, year = (
                    i["imdb"],
                    i["tmdb"],
                    i["originaltitle"],
                    i["year"],
                )
                sysname = urllib.quote_plus("%s (%s)" % (title, year))
                systitle = urllib.quote_plus(title)
                meta = dict((k, v) for k, v in i.items() if not v == "0")
                meta.update({'imdbnumber': imdb, 'code': tmdb})
                #                meta.update({"code": imdb, "imdbnumber": imdb, "imdb_id": imdb})
                #                meta.update({"tmdb_id": tmdb})
                meta.update({"mediatype": "movie"})
                meta.update(
                    {
                        "trailer": "%s?action=trailer&name=%s"
                                   % (sysaddon, urllib.quote_plus(label))
                    }
                )
                # meta.update({'trailer': 'plugin://script.extendedinfo/?info=playtrailer&&id=%s' % imdb})
                if not "duration" in i:
                    meta.update({"duration": "120"})
                elif i["duration"] == "0":
                    meta.update({"duration": "120"})
                try:
                    meta.update({"duration": str(int(meta["duration"]) * 60)})
                except:
                    pass
                # try:
                #     meta.update({"genre": cleangenre.lang(meta["genre"], self.lang)})
                # except:
                #     pass

                poster = [
                    i[x]
                    for x in ["poster3", "poster", "poster2"]
                    if i.get(x, "0") != "0"
                ]
                poster = poster[0] if poster else addonPoster
                meta.update({"poster": poster})
                meta = convert(meta)
                sysmeta = urllib.quote_plus(json.dumps(meta))

                url = "%s?action=play&title=%s&year=%s&imdb=%s&meta=%s&t=%s" % (
                    sysaddon,
                    systitle,
                    year,
                    imdb,
                    sysmeta,
                    self.systime,
                )
                sysurl = urllib.quote_plus(url)

                path = "%s?action=play&title=%s&year=%s&imdb=%s" % (
                    sysaddon,
                    systitle,
                    year,
                    imdb,
                )

                cm = []
                cm.append(
                    (
                        "Znajdź podobne",
                        "ActivateWindow(10025,%s?action=similar&tmdb=%s)"
                        % (sysaddon, tmdb),
                    )
                )
                cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))

                try:
                    overlay = int(playcount.getMovieOverlay(indicators, imdb))
                    if overlay == 7:
                        cm.append(
                            (
                                unwatchedMenu,
                                "RunPlugin(%s?action=moviePlaycount&imdb=%s&query=6)"
                                % (sysaddon, imdb),
                            )
                        )
                        meta.update({"playcount": 1, "overlay": 7})
                    else:
                        cm.append(
                            (
                                watchedMenu,
                                "RunPlugin(%s?action=moviePlaycount&imdb=%s&query=7)"
                                % (sysaddon, imdb),
                            )
                        )
                        meta.update({"playcount": 0, "overlay": 6})
                except:
                    pass

                if traktCredentials == True:
                    cm.append(
                        (
                            traktManagerMenu,
                            "RunPlugin(%s?action=traktManager&name=%s&imdb=%s&content=movie)"
                            % (sysaddon, sysname, imdb),
                        )
                    )

                cm.append(
                    (
                        playbackMenu,
                        "RunPlugin(%s?action=alterSources&url=%s&meta=%s)"
                        % (sysaddon, sysurl, sysmeta),
                    )
                )

                if isOld == True:
                    cm.append((control.lang2(19033), "Action(Info)"))

                cm.append(
                    (
                        addToLibrary,
                        "RunPlugin(%s?action=movieToLibrary&name=%s&title=%s&year=%s&imdb=%s&tmdb=%s)"
                        % (sysaddon, sysname, systitle, year, imdb, tmdb),
                    )
                )

                cm.append(
                    (
                        addMultiToLibrary,
                        f"RunPlugin({sysaddon}?action=moviesMultiToLibrary&select=multi_select)",

                    )
                )

                item = control.item(label=label)

                art = {}
                art.update({"icon": poster, "thum": poster, "poster": poster})

                fanart = i['fanart'] if 'fanart' in i and not i['fanart'] == '0' else addonFanart

                #                if self.settingFanart == 'true':
                art.update({'fanart': fanart})
                #                else:
                #                    art.update({'fanart': addonFanart})

                if 'banner' in i and not i['banner'] == '0':
                    art.update({'banner': i['banner']})
                else:
                    art.update({'banner': addonBanner})

                if 'clearlogo' in i and not i['clearlogo'] == '0':
                    art.update({'clearlogo': i['clearlogo']})

                if 'clearart' in i and not i['clearart'] == '0':
                    art.update({'clearart': i['clearart']})

                if 'landscape' in i and not i['landscape'] == '0':
                    landscape = i['landscape']
                else:
                    landscape = fanart
                art.update({'landscape': landscape})

                if 'discart' in i and not i['discart'] == '0':
                    art.update({'discart': i['discart']})

                item.setArt(art)
                item.addContextMenuItems(cm)
                item.setProperty("IsPlayable", isPlayable)
                castwiththumb = i.get('castwiththumb')
                if castwiththumb:
                    item.setCast(castwiththumb)
                item.setInfo(type='Video', infoLabels=control.metadataClean(meta))
                item.setProperty('imdb_id', imdb)
                item.setProperty('tmdb_id', tmdb)
                try:
                    item.setUniqueIDs({'imdb': imdb, 'tmdb': tmdb})
                except:
                    pass

                video_streaminfo = {"codec": "h264"}
                item.addStreamInfo("Video", video_streaminfo)
                isFolder = False if control.setting("hosts.mode") == '0' else True

                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
            except Exception as e:
                print(e)
                pass

            multi_select.append({'title': i['originaltitle'], 'title_multi': i['title'], 'year': i["year"],
                                 'imdb': i["imdb"], 'tmdb': i["tmdb"]})

        try:
            url = items[0]["next"]
            if url == "":
                raise Exception()

            icon = control.addonNext()
            url = "%s?action=moviePage&url=%s" % (sysaddon, urllib.quote_plus(url))

            item = control.item(label=nextMenu)

            item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'banner': icon, 'fanart': addonFanart})

            control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
        except:
            pass
        if self.meta:
            cache.cache_insert('multi_select', str(multi_select))
        control.content(syshandle, "movies")
        control.directory(syshandle, cacheToDisc=True)
        views.setView("movies", {"skin.estuary": 55, "skin.confluence": 500})

### FOLDER ###
    def addDirectory(self, items, queue=False):
        if items is None or len(items) == 0:
            control.idle()
            sys.exit()

        sysaddon = sys.argv[0]

        syshandle = int(sys.argv[1])

        addonFanart, addonThumb, artPath = (
            control.addonFanart(),
            control.addonThumb(),
            control.artPath(),
        )

        queueMenu = control.lang(32065)

        playRandom = control.lang(32535)

        addToLibrary = control.lang(32551)

        for i in items:
            try:
                name = i["name"]

                plot = i.get('plot') or '[CR]'

                if i["image"].startswith("http"):
                    thumb = i["image"]
                elif not artPath == None:
                    thumb = os.path.join(artPath, i["image"])
                else:
                    thumb = addonThumb

                url = "%s?action=%s" % (sysaddon, i["action"])
                try:
                    url += "&url=%s" % urllib.quote_plus(i["url"])
                except:
                    pass

                cm = []

                cm.append(
                    (
                        playRandom,
                        "RunPlugin(%s?action=random&rtype=movie&url=%s)"
                        % (sysaddon, urllib.quote_plus(i["url"])),
                    )
                )

                if queue:
                    cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))

                try:
                    cm.append(
                        (
                            addToLibrary,
                            "RunPlugin(%s?action=moviesToLibrary&url=%s)"
                            % (sysaddon, urllib.quote_plus(i["context"])),
                        )
                    )
                except:
                    pass

                item = control.item(label=name)

                item.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': addonFanart})
                item.setInfo(type='video', infoLabels={'plot': plot})

                item.addContextMenuItems(cm)

                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
            except:
                pass

        control.content(syshandle, "addons")
        control.directory(syshandle, cacheToDisc=True)

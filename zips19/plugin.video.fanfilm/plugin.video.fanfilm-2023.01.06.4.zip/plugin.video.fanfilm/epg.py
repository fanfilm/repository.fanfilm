"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
from kover import autoinstall  # noqa: F401
import xbmc
import urllib.parse as urllib
import re
from ptw.libraries import control
title = xbmc.getInfoLabel('Listitem.Title')
titletv = re.sub(' season$', '', title)
year = xbmc.getInfoLabel('ListItem.Year')
episode = xbmc.getInfoLabel('Listitem.Episode')
if not episode:
    title = urllib.quote_plus(title)
    control.execute("ActivateWindow(Videos,plugin://plugin.video.fanfilm/?action=movieSearchEPG&name=%s&year=%s)" % (title, year))
else:
    titletv = urllib.quote_plus(titletv)
    control.execute("ActivateWindow(Videos,plugin://plugin.video.fanfilm/?action=tvSearchterm&name=%s)" % titletv)

"""
    FanFilm Add-on
    Copyright (C) 2022 :)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import re
import threading
from urllib.parse import unquote

import requests
import xbmcgui

from ptw.libraries import source_utils
from ptw.libraries import cleantitle
from ptw.libraries import client, control, cache
from ptw.libraries import log_utils
from ptw.debug import log_exception
from html import unescape
from ast import literal_eval
import time

import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class source:

    def __init__(self):
        self.exts = ("avi", "mkv", "mp4", ".ts", "mpg")  # proszę trzymać 3 znaki długości dla każdego elementu

        # self.year = None  # chyba to już nie jest potrzebne - będzie do usunięcia
        # self.anime = None  # to samoc o wyżej ?
        self.lock = threading.Lock()
        self.raw_results = []
        self.results = []
        self.trash = []
        self.titles = []
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["tb7.pl"]
        self.base_link = "https://tb7.pl/"
        # self.mylibrary = "https://tb7.pl/mojekonto/pliki"

        if control.setting("tb7.wiele_zrodel") == "true":
            self.search_link = "https://tb7.pl/mojekonto/szukaj"
            self.support_search_link = "https://tb7.pl/mojekonto/szukaj/{}"  # do paginacji wyników
        else:
            self.search_link = "https://tb7.pl/mojekonto/szukajka"
            self.support_search_link = "https://tb7.pl/mojekonto/szukajka/{}"  # do paginacji wyników

        self.session = requests.Session()
        self.user_name = control.setting("tb7.username")
        self.user_pass = control.setting("tb7.password")
        self.headers = {"Connection": "keep-alive", "Upgrade-Insecure-Requests": "1",
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.53 Safari/537.36",
                        "DNT": "1",
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
                        "Accept-Language": "pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7", }

    # te 2 poniższe funkcje chyba nie są nigdzie używane
    def contains_word(self, str_to_check, word):
        if str(word).lower() in str(str_to_check).lower():
            return True
        return False

    def contains_all_words(self, str_to_check, words):
        for word in words:
            if not self.contains_word(str_to_check, word):
                return False
        return True

    def login(self):
        try:
            cookies = cache.cache_get("tb7_cookie")["value"]
        except Exception:
            cookies = ""
        self.headers.update({"Cookie": cookies})
        result = self.session.get(self.base_link, headers=self.headers).text
        if self.user_name in result:
            return
        else:
            if self.user_name and self.user_pass:
                self.session.post("https://tb7.pl/login", verify=False, allow_redirects=False,
                                  data={"login": self.user_name, "password": self.user_pass}, )
                result = self.session.get(self.base_link).text
                if self.user_name in result:
                    cookies = self.session.cookies
                    cookies = "; ".join([str(x) + "=" + str(y) for x, y in cookies.items()])
                    cache.cache_insert("tb7_cookie", cookies)
                    self.headers.update({"Cookie": cookies})

    def get_pages_content(self, page, year, title='', episode=None):
        """Funkcja filtruje wstępnie wyniki otrzymane z serwera
           sprawdzając czy pasują któreś z elementów: tytuł, rok, numer odcinka
        """
        if page:
            # pobranie kolejnej podstrony wyników
            res = self.session.get(self.support_search_link.format(str(page)), headers=self.headers).text
            rows = client.parseDOM(res, "tr")[1:]
            # dodanie tablicy do tablicy
            self.raw_results += rows
        else:
            results_cache = cache.cache_get('tb7_raw_results')
            results_cache = literal_eval(results_cache['value'])
            rows = [results_cache[k] for k in results_cache][0]  # odczytanie danych nie znając klucza
        
        if episode:
            title = title.replace(episode, '').rstrip('_ ')
        if year:
            title = title.replace(year, '').rstrip('_ ')  # ciekawe czy jest taki tytuł co ma rok taki sam jak data produkcji
            
        dodatkowy_filtr = dodatkowy_filtr2 = False

        """
        #if not re.search(r'[ ._-]', title):  # tylko dla pojedyńczego słowa
        if False:
            # pozwala odrzucać jeśli słowo szukane jest w środku innego wyrazu,
            # np. szukam "matka" to odrzucam "dyplomatka"
            # ale przepuszcza np. "Krzyk.5.2022", dla tytułu "Krzyk", choć tu akurat może być
            dodatkowy_filtr = re.compile(fr'^\W?(\b|_|^){re.escape(title)}[789]?(?=\b|_)', flags=re.I)
        """
        if year:  # dla filmów
            title_pat = re.escape(title)
            
            # dozbrojenie o tytuły bez przekstałceń
            titles_pat = [re.escape(t) for t in self.titles]
            titles_pat = [title_pat] + titles_pat
            
            titles_pat = list(filter(None, titles_pat))  # usunięcie pustych
            titles_pat = list(dict.fromkeys(titles_pat))  # pozbycie się duplikatów
            title_pat = f'(?:{"|".join(titles_pat)})'
            
            title_pat = title_pat.replace('_', '[ ._-]')  # przekształcam odstępy między słowami
            #title_pat = title_pat.replace(r'\-', '[ ._-]')            
            title_pat = title_pat.replace(r'\&', r'(?:\&|and)')  # "Dungeons & Dragons: Złodziejski honor"
            
            year_pat = '([ ._]*[(]?(720|1080|19\d[\dO]|[2-9][\dO]{3})[)]?)'
            
            dodatkowy_filtr = re.compile(fr'(^|[-]|\d{{1,2}})\W?(\b|_|\d{{1,2}}|^){title_pat}\d?(?=\b|[ ._]){year_pat}', flags=re.I)

        if episode:
            title_pat = re.escape(title)
            
            # dozbrojenie o tytuły bez przekstałceń
            titles_pat = [re.escape(t) for t in self.titles]
            titles_pat = [title_pat] + titles_pat
            
            titles_pat = list(filter(None, titles_pat))  # usunięcie pustych
            titles_pat = list(dict.fromkeys(titles_pat))  # pozbycie się duplikatów
            title_pat = f'(?:{"|".join(titles_pat)})'
            
            title_pat = title_pat.replace('_', '[ ._-]')  # przekształcam odstępy między słowami, jeśli tytuł je ma
            
            if re.search(r'e\d{3}', episode):
                episode_pat = re.sub(r'(S\d\d)(E(\d\d\d))', r'\1[.-]?\2(?!\\d)', episode, flags=re.I)
                episode_pat = re.sub(r'(S01.*?)(E.*)', r'(\1\2|(?<!S\\d{2}[.-])(?<!S\\d{2})\2)', episode_pat, flags=re.I)  # chyba ten sam kod co poniżej
            else:
                # episode_pat = re.sub(r'(S\d\d)(E\d\d)', r'\1[.-]?\2(?!\\d)', episode, flags=re.I)
                episode_pat = re.sub(r'(S\d\d)(E(\d\d))', r'\1[.-]?e0?\3(?!\\d)', episode, flags=re.I)
                episode_pat = re.sub(r'(S01.*?)(E.*)', r'(\1\2|(?<!S\\d{2}[.-])(?<!S\\d{2})\2)', episode_pat, flags=re.I)  # na przypadek gdy nie ma innego sezonu
            episode_pat = episode_pat.replace('\\d', '[\dO]').replace('0', '[0O]')  # zauważyłem, że czasami zamiast 0 jest O
            
            resolution_pat = '([ ._](SD|HD|UHD|2k|4k|480p|540p|576p|720p|1080[pi]|1440p|2160p))'
            year_pat = '([ ._]*[(]?(720|1080|19\d[\dO]|[2-9][\dO]{3})[)]?)'  # zamiast 0 ktoś wpisał O
            # custom_pat = '([ ._][a-z]{2,})'  # za duża tolerancja i trafić może na ostatnie słowo innego tytułu np. "Titans go" dla filmu "Titans"
            custom_pat = '([ ._](pl|us|fr|de|dual|multi|polish))'  # trudnosć polega na przewidzeniu wszystkich możliwośći
            
            # resolution_pat = custom_pat = year_pat = '()'  # do debugowania, jak się nie mieści pattern w logu
            
            dodatkowy_filtr = re.compile(fr'(^|[-])\W?(\b|_|^){title_pat}[789]?(?=\b|_){resolution_pat}?{year_pat}?{resolution_pat}?{custom_pat}?[ ._-]*[([]?{episode_pat}', flags=re.I)
            dodatkowy_filtr2 = re.compile(fr'[([]?{episode_pat}\W*(\b|_){title_pat}(?=\b|_)[ ._]*-', flags=re.I)  # na przypadek gdy na początku jest numer odcinka a potem tytuł,
            # ale problemem jest ograniczenie wyszukiwania, aby nie było jak z filmem "Titans" bez "go" na końcu
        
        if control.setting("sources.title_validation_filter") == "false":
            dodatkowy_filtr = dodatkowy_filtr2 = False
        
        # with self.lock:
        def _checkYearOrEpisode(year):
            # log_utils.log(f'[tb7.py] ilość rekordów: {len(rows)}')
            episode_re = re.compile(episode_pat, flags=re.I) if episode else None
            for row in rows:
                size = client.parseDOM(row, "td")[3]
                filename0 = ''.join(client.parseDOM(row, "a") or client.parseDOM(row, "label"))
                if not filename0[-3:] in self.exts:  # rozszerzenie
                    continue
                # funkcji unquote() oraz unescape() najlepiej używać tylko do koncowego wyświetlenia
                # nie uzywać do porównań z oryginałem, ponieważ raczej nie da się odtworzyć w 100%
                # stringu pierwotnego
                filename = filename0
                filename = unquote(filename)
                filename = unescape(filename)
                if ((year and year in filename)
                        or (episode and episode_pat and episode_re.search(filename))
                        or (not year and not episode)):
                    if (not dodatkowy_filtr
                            or dodatkowy_filtr.search(filename)
                            or (dodatkowy_filtr2 and dodatkowy_filtr2.search(filename))):
                        self.results.append(row)
                        # log_utils.log(f'[tb7.py]   + przepuszczono {filename!r} {size}')
                        if filename0 in self.trash:
                            log_utils.log(f'[tb7.py]   + przywrócono {unescape(unquote(filename0))!r} {size}')
                            self.trash.remove(filename0)
                    else:
                        # może trochę zaciemniać, jak developersko analizujemy co jest kiedy odrzucane,
                        # ale w logach dla usera ładniej wygląda
                        # UWAGA: escape nie zawsze odtworzy oryginalny tekst
                        # if not any(escape(filename) in r for r in self.results):
                        if not any(filename0 in r for r in self.results):
                            if filename0 not in self.trash:
                                log_utils.log(f'[tb7.py]   - odrzucono {filename!r} {size}')
                                self.trash.append(filename0)
                                # log_utils.log(f'[tb7.py]      bo {title=!r} {dodatkowy_filtr=!r} {year=!r} {episode=!r}\n')
                        else:
                            # tylko do developerskiej analizy działania filtra
                            # log_utils.log(f'[tb7.py] *(byłoby odrzucone {filename!r} {size}, choć potem zostałoby przywrócone)\n')
                            pass  # po to, aby bezpiecznie móc zakomentować powyższą linijkę
                # log_utils.log(f'[tb7.py]  nie dodano, bo {filename=!r} {year=!r} {episode=!r} {size=}\n')

        # log_utils.log(f'[tb7.py]  Sprawdzanie ({page}) strony otrzymanych wyników [{len(rows)}]:')
        _checkYearOrEpisode(year)

        # kolejna próba, gdy nie było rezultatów
        # bo zdarzają się rozbieżnościa pomiędzy datą produkcj czy premiery w Polsce i na świecie -
        # np. film Nocne Graffiti (w bazie TMDB czy IMDb jest rok 1997 (data premiery)
        # a w bazie FilmWeb rok to 1996) więc próbuje szukać rekordów,
        # w których zawarty rok jest o 1 mniejszy niż bazowy
        if not self.results and year:
            log_utils.log('[tb7.py]  Z powodu braku dopasowań, podjęcie ponownej próby,'
                          f' tym razem dla roku {int(year)-1} (choć wyniki mogą być błędne):')
            _checkYearOrEpisode(str(int(year)-1))

        if not self.results:
            log_utils.log('[tb7.py]   Nie znaleziono żadnych pasujących rekordów.')

        # sprawdzenie, czy coś co było wcześniej odrzucone, może zostało jednak dodane do źródeł
        if self.trash:
            self.trash = list(dict.fromkeys(self.trash))
            for item in self.trash[:]:
                # if any(escape(item) in r for r in self.results):
                if any(item in r for r in self.results):
                    log_utils.log(f'[tb7.py] +Przywrócono {unescape(unquote(item))!r}')  # główny cel tego fragmentu kodu
                    self.trash.remove(item)

    def search(self, title, localtitle, year="", episode=None):
        """Funkcja wysyła do serwera zapytania:
           oryginalny tytuł filmu oraz tłumaczenie tytułu
        """
        try:
            log_text = ''
            log_text += f'tytuł: {title!r}'
            log_text += f', polski tytuł: {localtitle!r}' if localtitle != title else ''
            log_text += f', rok (premiery): {year}' if year else ''
            log_text += f', numer odcinka: {episode}' if episode else ''
            log_utils.log(f'[tb7.py]  {log_text}') 

            titles = [title, localtitle]
            self.titles = titles
            
            if re.sub(r'\bthe\b', '', title, flags=re.I).strip().lower() == localtitle.lower():  # np. film "The Batman"
                # localtitle = ''  # pozwoli zredukować ilość zapytań do serwera
                titles = [title]
                
            titles = [cleantitle.normalize(cleantitle.getsearch(t)) for t in titles]
            
            # poniższe pozwalają zredukować ilość zapytań do serwera
            titles = list(filter(None, titles))  # usunięcie pustych
            titles = list(dict.fromkeys(titles))  # pozbycie się duplikatów
            
            self.titles = titles + self.titles
            self.titles = list(filter(None, self.titles))  # usunięcie pustych
            self.titles = list(dict.fromkeys(self.titles))  # pozbycie się duplikatów            
            
            if episode and len(titles) < 2:
                titles.append(f'{cleantitle.normalize(cleantitle.getsearch(title))} {episode}')  # może pomóc znaleźć wyniki, bo wyszukiwarka tb7 zwraca mksymalnie tylko 5 podstron i jak jest bardzo dużo odcinków, to przy wyszukiwaniu tylko tytułu może odcinek, którego szukamy się nie znaleźć w wynikach
                # niezbyt pomaga, gdy szukamy e001 a mamy podane e01
            
            if episode and re.search(r'e0\d{2}', episode):  # np. e001 -> e01
                episode2 = re.sub(r'(s\d\d)(e0(\d\d))', r'\1e\3', episode)
                titles.append(f'{cleantitle.normalize(cleantitle.getsearch(title))} {episode2}')

            self.login()
            
            last_total_time = cache.cache_get('tb7_results-last_total_time')
            if last_total_time:
                last_total_time = int(last_total_time['value'])
            else:
                last_total_time = 0

            def check_if_finished():
                results_cache_fin = cache.cache_get('tb7_results_finished')
                # log_utils.log(f'[tb7.py] {results_cache_fin=!r} ')
                if results_cache_fin:
                    results_cache_val = results_cache_fin['value']
                    results_cache_date = results_cache_fin['date']
                    if results_cache_val and repr(titles) in results_cache_val:  # czy nie jest pusty i czy jest tam tytuł jako klucz
                        results_cache_val = literal_eval(results_cache_val)
                        finished = results_cache_val[repr(titles)]  # czy skończone, czy w trakcie
                        return finished
                return None

            results = []
           
            dont_request = False
            results_cache = cache.cache_get('tb7_results')
            if results_cache:
                results_cache = results_cache['value']
                if results_cache:
                    results_cache = literal_eval(results_cache)
                    if repr(titles) not in results_cache:
                        cache.cache_insert('tb7_results', '')
                        cache.cache_insert('tb7_results_finished', '')
                        cache.cache_insert('tb7_raw_results', '')
                    else:
                        results_cache_fin = cache.cache_get('tb7_results_finished')
                        # log_utils.log(f'[tb7.py] {results_cache_fin=!r} ')
                        if results_cache_fin:
                            results_cache_val = results_cache_fin['value']
                            results_cache_date = results_cache_fin['date']
                            if results_cache_val and repr(titles) in results_cache_val:  # czy nie jest pusty i czy jest tam tytuł jako klucz
                                results_cache_val = literal_eval(results_cache_val)
                                finished = results_cache_val[repr(titles)]  # czy skończone, czy w trakcie, liczba jest też czasem jakbi był wymagany do zakończenia wyszukiwania dla tych tytułów
                                # log_utils.log(f'[tb7.py] {finished=!r}')
                                now = int(time.time())
                                delta_t = now - int(results_cache_date)
                                # delta_t = 0  # dla testów tylko
                                if delta_t < (5*60):  # 5 minut
                                    dont_request = True  # bezpieczniej dać także tu
                                    if not finished:
                                        timeout = int(control.setting("scrapers.timeout.1"))
                                        check_interval = 5  # w sekundach
                                        log_utils.log(f"[tb7.py] ... czekam na zakończenie zapisu poprzedniego requesta")
                                        for i in range( int(max(10, int(timeout-10))/check_interval) ):  # czeka prawie do końca timeoutu
                                            # log_utils.log(f"[tb7.py] pętla czekająca na zakończenie zapisu z poprzedniego requesta {i=}")
                                            time.sleep(check_interval)  # odczekanie przed kolejnym sprawdzeniem
                                            f = check_if_finished()
                                            #log_utils.log(f"[tb7.py] czy skończony poprzedni request: {f=!r}")
                                            if f is None:
                                                dont_request = False  # choć nie wiem ile czasu zostało i czy nowy request zdąży się wykonać
                                                break
                                            if f:
                                                dont_request = True
                                                break
                                        # tu można by (w tej linijce) dać kod, gdy nie doczekaliśmy się skończenia poprzedniego requestu
                                        if not dont_request and ((timeout - int(time.time()) - now) < (last_total_time + 10)):
                                          return []  # bo nie zdąży się wykonać następny request
                                    else:
                                        dont_request = True

            if dont_request:
                log_utils.log(f"[tb7.py] NIE wykonuje ponownego requestu, bo od ostatniego minęło {delta_t} sek. ( < 300 )")
                pass
            
            saved_to_cache = False
            now0 = int(time.time())
            
            for orig_title in titles:
            
                # korekty specyficzne dla wyszukiwarki TB7
                title = orig_title.replace(" - ", " ")  # pomaga np. dla "mission impossible - ghost protocol"
                title = title.replace("-", "_")  # pomogło dla filmu "'E.T. the Extra-Terrestrial"
                
                # poniższe potrafią zwiększyć ilość źródeł
                title = title.replace(". ", ".")  # np. dla serialu Mr.Robot
                title = title.replace(" ", "_")  # np. "transformers_rise_of_the_beasts"
                title = title.replace(",", "")  # na przypadek "Poszukiwany, poszukiwana"
                title = title.replace("#", "")  # na przypadek "#BringBackAlice"
                
                self.titles = [title] + self.titles
                
                # if re.search(r'^\d{,2}$', title):  # odkryłem dla tytułu "65"
                if len(title) < 3:  # także dla filmu "To" ("It")
                    title += f'_{year!s}'                

                if dont_request:
                    continue
                
                """
                if orig_title != title:
                    log_utils.log(f"[tb7.py] WYSŁANIE zapytania dla tytułu: {orig_title!r} -> {title!r}")
                else:
                    log_utils.log(f"[tb7.py] WYSŁANIE zapytania dla tytułu: {title!r}")
                """
                log_utils.log(f"[tb7.py] WYSŁANIE zapytania: {title!r}")
                
                now1 = int(time.time())
                post = {"search": title, "type": "1"}  # przygotwanie danych do wysyłki (zapytania)
                pre_res = (self.session.post(self.search_link, headers=self.headers, data=post).text.replace("\r", "").replace("\n", ""))  # wysłanie zapytania typu POST
                now2 = int(time.time())
                # log_utils.log(f"[tb7.py]  Czas odpowiedzi z serwera: {now2 - now1} sek.")
                
                # sprawdzenie co jest w odpowiedzi
                page_block = re.search('class="page-list"(.+?)</div>', pre_res, re.IGNORECASE)
                if page_block is not None:
                    pages = len(re.findall("href=", page_block.group()))
                    log_utils.log(f"[tb7.py]  sprawdzanie otrzymanych wyników ({pages} podstr.)")
                    for page in range(pages):
                        # filtrowanie otrzymanych z internetu wyników
                        self.get_pages_content(page + 1, year, title, episode)
                    results = self.results
                    # dodanie do cache w razie jakby kolejna pętla nie zdążyła się wykonać a nadszedł Timeout
                    log_utils.log(f"[tb7.py]  przekazanie do cache rekordów: {len(results)}")
                    cache.cache_insert('tb7_results', repr({repr(titles): results}))  # zapisanie cząstkowych wyników
                    cache.cache_insert('tb7_results_finished', repr({repr(titles): 0}))
                    # cache.cache_insert('tb7_raw_results', repr({repr(titles): self.raw_results}))  # nie wiem czy tu, czy dopiero na końcu pętli
                    saved_to_cache = True
                else:
                    log_utils.log("[tb7.py]  nie otrzymano wyników")
            
            if saved_to_cache:
                now3 = int(time.time())
                tt = now3 - now0
                log_utils.log(f"[tb7.py] Łączny czas operacji = {tt} sek.")
                cache.cache_insert('tb7_results_finished', repr({repr(titles): max(1, tt)}))
                cache.cache_insert('tb7_results-last_total_time', max(1, tt))  # może się przydać do analizy, jak długo czekać następnym razem
                cache.cache_insert('tb7_raw_results', repr({repr(titles): self.raw_results}))  # nie wiem, czy tu dopiero zapisać, czy cząstkowe też
            
            if dont_request:
                self.get_pages_content(None, year, '', episode)
                results = self.results

            return results

        except Exception:
            log_exception()
            return

    def movie(self, imdb, title, localtitle, aliases, year):
        # log_utils.log(f'[tb7.py] {title=!r} {localtitle=!r} {aliases=!r} {year=!r}')
        return self.search(title, localtitle, year)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return (tvshowtitle, localtvshowtitle), year

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # year = int(url[1])
        # self.year = year
        anime = source_utils.is_anime("show", "tvdb", tvdb)
        # self.anime = anime  # nie wiem do czego to tu
        if anime:
            epNo = source_utils.absoluteNumber(tvdb, episode, season)
        else:
            # jak wykryć czy jest więcej niż 99 odcinków na sezon ?
            epNo = f"s{season.zfill(2)}e{episode.zfill(2)}"
            #epNo = f"s{season.zfill(2)}e{episode.zfill(3)}"  # dla seriali co mają więcej niż 99 odcinków na sezon
        return self.search(url[0][0], url[0][1], episode=epNo)

    def sources(self, rows, hostDict, hostprDict):
        """Funkcja sprawdza przefiltrowane wstępnie wyniki
           i dodaje je do listy wyświetlanej użytkownikowi
        """
        self.login()

        # pobranie zawartości strony internetowej "historia zakupionych linków" 
        result = self.session.get("https://tb7.pl/mojekonto/pliki", headers=self.headers).text
        result = client.parseDOM(result, "table", attrs={"class": "list"})
        result = client.parseDOM(result, "input", ret="value")
        
        sources = []
        try:
            for row in rows:
                try:
                    nazwa = client.parseDOM(row, "label")[0]
                    if "<a " in nazwa.lower():  # moze byc jeszcze tag a
                        nazwa = client.parseDOM(nazwa, "a")[0]
                    """  # to jest sprawdzane wcześniej w innym miejscu
                    if not nazwa[-3:] in self.exts:  # rozszerzenie
                        # log_utils.log(f'[tb7.py] odrzucone z powodu rozszerzenia {nazwa=!r}')
                        continue
                    """
                    source = client.parseDOM(row, "td")[1]  # hosting
                    size = client.parseDOM(row, "td")[3]  # rozmiar
                    # unikanie zdublowań lub wymiana na lepiej opisane
                    #if any(size in s["info"] and source in s["source"] for s in sources):
                        # continue
                    reject = False
                    len_nazwa = len(unescape(unquote(nazwa)))
                    for i in reversed(range(len(sources))):
                        s = sources[i]
                        if size in s["info"] and source in s["source"]:
                            # porównuje długość nazw zakładając, że im dłuższa,
                            # tym więcej da się odczytać informacji
                            if len(unescape(unquote(s["filename"]))) < len_nazwa:
                                del sources[i]
                            else:
                                reject = True
                            break
                    if reject:
                        continue

                    link = client.parseDOM(row, "input", ret="value")[0]
                    quality = source_utils.check_sd_url(nazwa)
                    info = source_utils.get_lang_by_type(nazwa)
                    if not info[1]:
                        info1 = ""
                    else:
                        info1 = f" | {info[1]}"
                    
                    # sprawdzenie, czy wybrana pozycja może jest już na koncie (bibliotece "dobowej") użytkownika
                    on_account = False
                    for item in result:
                        item_org = item
                        item = unquote(item.rstrip("/").split("/")[-1])
                        item = "".join(character for character in item if character.isalnum())
                        url = unquote(link)
                        url = [character for character in url if character.isalnum()]
                        url = "".join(url)
                        if item in url:
                            link = item_org
                            on_account = True
                            break
                        elif unescape(unquote(nazwa)) in unescape(unquote(item_org)):
                            # dodatkowy warunek mogący pomóc, bo nie zawsze da się stwierdzić po url-u,
                            # gdyż np. linki do serwera "wplik" są zakodowane
                            # (choć drobne ryzyko pomyłki istnieje, bo nie jest sprawdzany rozmiar)
                            link = item_org
                            on_account = True
                            break

                    sources.append({"source": source, "quality": quality, "language": info[0], "url": link,
                                    "info": f"{info1} | {size}", "size": size,
                                    "direct": True, "debridonly": False, "filename": nazwa, 
                                    "on_account": on_account})
                except Exception:
                    continue
            
            # zapisanie informacji w cache
            src = {i['url']: i for i in sources}  # zrobienie z tablicy słownika, gdzie kluczem dla każdego źródła będzie jego link
            cache.cache_insert('tb7_src', repr(src))  # w bazie cache będzie key(tb7_src), value(słownik w formie stringa)
            
            return sources
        except Exception:
            log_exception()
            return sources

    def resolve(self, url):
        org_url = url
        
        # odczytanie informacji z cache
        sources = cache.cache_get('tb7_src')['value']
        sources = literal_eval(sources)  # przerobienie stringa na odpowiedni obiekt (w tym przypadku słownik)
        source = sources[url]  # wybranie informacji tylko o konkretnym źródle

        filename = source['filename']
        
        self.login()
        
        # pobranie zawartości strony internetowej "historia zakupionych linków" 
        result = self.session.get("https://tb7.pl/mojekonto/pliki", headers=self.headers).text
        result = client.parseDOM(result, "table", attrs={"class": "list"})
        result = client.parseDOM(result, "input", ret="value")
        # sprawdzenie, czy wybrana pozycja jest już na koncie (bibliotece "dobowej") użytkownika
        for item in result:
            link = item
            item = unquote(item.split("/")[-1])
            item = [character for character in item if character.isalnum()]
            item = "".join(item)
            url = unquote(url)
            url = [character for character in url if character.isalnum()]
            url = "".join(url)
            if item in url or unescape(unquote(filename)) in unescape(unquote(link)):  # jak jest, to odtwarzaj z biblioteki
                return str(link + "|User-Agent=vlc/3.0.0-git libvlc/3.0.0-git&verifypeer=false")

        autotb7 = control.setting("autotb7")  # automatyczne "kupowanie"
        if autotb7 == "false":
            limit = self.session.get(self.base_link, headers=self.headers).text
            limit = client.parseDOM(limit, "div", attrs={"class": "textPremium"})
            limit = str(client.parseDOM(limit, "b")[-1])
            limit = re.sub(r"\s*\w+\s*=\s*([\"']?).*?\1(?=[\s>]|$)\s*", "", limit)  # usunięcie atrybutów z tagów
            limit = re.sub("<[^>]+>", "", limit)  # usunięcie tagów html'owych

            if control.setting("sources.extrainfo") == "true":
                filename = unquote(filename)  # usunięcie takich kodów jak %nn (np. %21 to nawias)
                filename = unescape(filename)  # usunięcie ewentualnych encji html
                
                # przygotowanie nazwy do wyswietlenia
                # pozwoli zawijać tekst (aby mieścił się w okienku)
                filename = filename[:-4].replace(".", " ").replace("_", " ")+filename[-4:]
                
                # wywalenie ostatniego myślnika - zazwyczaj jest po nim nazwa "autora" pliku
                # (dodatkowo także dla takich przypadków jak "....480p.x264-mSD (2).mkv")
                filename = re.sub(r"-(?=\w+( \(\d\))?\.\w{2,4}$)", " ", filename, flags=re.I)
                
                # poniższe to przywrócenie niezbędnych kropek i kresek dla niektórych fraz
                filename = re.sub(r"(?<!\d)([57261]) ([10])\b", r"\1.\2", filename)  # ilość kanałów, np. 5.1 czy 2.0
                filename = re.sub(r"\b([hx]) (26[45])\b", r"\1.\2", filename, flags=re.I)  # h264 x264 x265 h265
                filename = re.sub(r"\b(DDP?) (EX)\b", r"\1-\2", filename, flags=re.I)  # np. DD-EX
                filename = re.sub(r"\b(DTS) (HD(?!-?(?:TS|cam|TV))|ES|EX|X(?![ .]26))\b", r"\1-\2", filename, flags=re.I)  # DTS
                filename = re.sub(r"\b(AAC) (LC)\b", r"\1-\2", filename, flags=re.I)  # dla kodeka AAC-LC
                filename = re.sub(r"\b(AC) (3)\b", r"\1-\2", filename, flags=re.I)  # dla kodeka AC-3
                filename = re.sub(r"\b(HE) (AAC)\b", r"\1-\2", filename, flags=re.I)  # dla kodeka HE-AAC
                filename = re.sub(r"\b(WEB|Blu|DVD|DCP|B[DR]|HD) (DL|Ray|RIP|Rip|Rip|TS)\b", r"\1-\2", filename, flags=re.I)
                
                # filename = filename.replace("-", "\u2011")  # dodanie myślnika niełamiącego (nie wszystkie czcionki to obsługują)
                # filename = filename.replace("-", "–")  # nie wiem, czy to jest myślnik nierozdzielający
                
                prem_identify = source_utils.getPremColor()
                if not prem_identify == "nocolor":
                    filename = f"[COLOR {prem_identify}]{filename}[/COLOR]"
                filename = f'[LIGHT]{filename}[/LIGHT]'                
            else:
                filename = ""  # rezygnacja z wyswietlania nazwy pliku

            if "size" in source:  # jak jest taka cecha w danych źródła
                size = source["size"]
            else:
                # pozyskanie rozmiaru z pola "info"
                # 
                # ---- 3 poniższe wersje zostawiam w celach edukacyjnych
                #
                # - wersja 1 -
                # size = [s.strip() for s in source["info"].split('|')
                #         if any(i in s.upper() for i in ["MB", "GB", "KB"])]
                # size = size[0] if size else ''
                #
                # - wersja 2 -
                # rx = re.compile(r"[GMK]B\b")
                # size = next((s.strip() for s in source["info"].split('|') if rx.search(s)), "")
                #
                # - wersja 3 -
                mch = re.search(r'(?:^|\|)\s*(\d+(?:[.,]\d+)?)\s*([GMK]B)\b\s*(?:\||$)', source['info'], flags=re.I)
                size = f'{mch[1]} {mch[2]}' if mch else ''
            
            size = size.replace(" ", "\u00A0")  # aby nie rodzielał cyfr od jednostek

            # wyświetlenie okienka z informacją i pytaniem
            ret = xbmcgui.Dialog().yesno("TB7", (f"Czy chcesz odtworzyć tę pozycję, za [B]{size}[/B]?\n"
                                                 f"[I]{filename}[/I]\n"
                                                 f"Aktualnie posiadasz: [B]{limit}[/B]"))
            if not ret:  # rezygnacja użytkownika
                return

        # przygotowanie linku filmu dla odtwarzacza
        data = {"step": "1", "content": org_url}
        # wysłanie "zakodowanego" linku filmu pod specjalny adres
        self.session.post("https://tb7.pl/mojekonto/sciagaj", data=data, headers=self.headers)

        data = {"0": "on", "step": "2"}
        # odebranie przygotowanych przez serwis tb7 informacji zawierających "odkodowany" linku do filmu
        content = self.session.post("https://tb7.pl/mojekonto/sciagaj", data=data, headers=self.headers).text

        # wydzielenie konkretnego fragmentu z odpowiedzi serwera
        result = client.parseDOM(content, "div", attrs={"class": "download"})
        link = client.parseDOM(result, "a", ret="href")[1]  # wyłapanie linku
        
        # zwrócenie konkretnego adresu
        return str(link + "|User-Agent=vlc/3.0.0-git libvlc/3.0.0-git&verifypeer=false")

"""
    FanFilm Add-on
    Copyright (C) 2022 :)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import math
import re
import requests
import xbmcgui
from ptw.libraries import cleantitle
from ptw.libraries import control, cache, log_utils
from ptw.libraries import source_utils
from urllib.parse import unquote
from html import unescape


class source:
    def __init__(self):
        self.authtoken = None
        self.year = None
        self.anime = None
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["twojlimit.pl"]
        self.login_url = "https://www.twojlimit.pl/api/rest/login"
        self.search_url = "https://www.twojlimit.pl/api/rest/search"
        self.check_url = "https://www.twojlimit.pl/api/rest/files/check"
        self.files_url = "https://www.twojlimit.pl/api/rest/files/get"
        self.download_url = "https://www.twojlimit.pl/api/rest/files/download"
        self.r = requests
        self.exts = ("avi", "mkv", "mp4", "mpg", ".ts")
        self.user_name = control.setting("twojlimit.username")
        self.user_pass = control.setting("twojlimit.password")
        self.trash = []

    # te 2 poniższe funkcje nigdzie nie są wykorzystywane
    def contains_word(self, str_to_check, word):
        if str(word).lower() in str(str_to_check).lower():
            return True
        return False

    def contains_all_words(self, str_to_check, words):
        for word in words:
            if not self.contains_word(str_to_check, word):
                return False
        return True

    def login(self):
        self.authtoken = ""
        get_auth = cache.cache_get("twojlimit_authtoken")
        if get_auth is not None:
            self.authtoken = get_auth["value"]

        if self.authtoken == "":
            if self.user_name and self.user_pass:
                req = self.r.post(self.login_url, data={"login": self.user_name, "password": self.user_pass}, )
                response = req.json()
                if "authtoken" in response:
                    self.authtoken = response["authtoken"]
                    cache.cache_insert("twojlimit_authtoken", self.authtoken)
                    return True
                elif "error" in response and response["message"] != "":
                    xbmcgui.Dialog().notification("Błąd", str(response["message"]))
                    return False

    def search(self, title, localtitle, year="", recurrency=None):
        cache.cache_clear_providers()
        
        title1 = title  # przechowanie zmiennej pod inną nazwą, bo może być potrzebna
        numbers = ('zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine')  # potrzebne do filtra do zamian cyfr na słowa i odwrotnie
        
        try:
            self.login()

            titles = [ cleantitle.normalize(cleantitle.getsearch(title)) ,
                       cleantitle.normalize(cleantitle.getsearch(localtitle)) ]
            """
            # opcjonalnie można dodać inny zapis numeru odcinka (s01.e01) - tylko nie wiem,
            # czy to zwiększa ryzyka zablokowania uzytkownika po stronie serwera
            # ze względu na zbyt dużą ilość zapytań w krótkim czasie
            if not year:  # episodes
                titles.append( cleantitle.normalize(cleantitle.getsearch( re.sub(r'(s)(\d\d)(e)(\d\d)', r'\1\2.\3\4', title) )) )
                titles.append( cleantitle.normalize(cleantitle.getsearch( re.sub(r'(s)(\d\d)(e)(\d\d)', r'\1\2.\3\4', localtitle) )) )
            """
            # usunięcie ewentualnych pustych pozycji
            # i pozbycie się duplikatów, z zachowaniem kolejności
            # (może być 1 http request mniej)
            titles = list(filter(None, titles))
            titles = list(dict.fromkeys(titles))
            
            if control.setting("sources.title_validation_filter") == "false":
                title_validation_filter = False
            else:
                title_validation_filter = True

            results = []
            for title in titles:
                # korekty przed wysłaniem
                title = title.replace("&", "and")  # na przypadek "Dungeons & Dragons: Złodziejski honor"
                log_utils.log(f"[twojlimit.py] WYSŁANIE zapytania: {(title+' '+year)!r}", )
                
                data = {"authtoken": self.authtoken, "keyword": f"{title} {year}", "display": 100, "video": True, "mode": "ff", }
                res = self.r.post(self.search_url, data=data)  # WYSŁANIE zapytania do serwera
                search = res.json()  # odpowiedź do JSON

                if "error" in search and search["message"] != "":
                    cache.cache_insert("twojlimit_authtoken", "")
                    return False

                if "search" in search:
                    search = search["search"]
                    # log_utils.log(f'[twojlimit.py] {search=!r}')
                    if "search_result" in search and len(search["search_result"]) > 0:
                        
                        if not year:  # TV series

                            epNo = title.split(" ")[-1]  # numer odcinka
                            # epNo_pat = re.sub(r's(\d{2})e(\d{2})', r's\1[ .-]?e\2', epNo)  # dla zapisu typu s01-e01

                            title0 = re.sub(fr'{epNo}', '', title).strip()  # tytuł z bazy filmów (np. TMDB)
                            title0 = title0.replace('.',' ').replace('  ',' ')  # pomogło dla "Mr. Robot"
                            title0 = title0.strip()
                            
                            title0_pat = re.escape(title0)
                            title0_pat = title0_pat.replace(r'\ ', '[ ._-]')  # pomogło dla "Obi-Wan Kenobi"                            
                            
                            for s in search["search_result"]:
                                # log_utils.log(f'[twojlimit.py] ---------- ')
                                size = s["filesize"]

                                # file_title = cleantitle.get_title(s["filename"]).rpartition(epNo)[0].strip()  # wycina dużo znaków, m.in. hashe i wówczas nie szuka tytułu "#BringBackAlice"
                                if not re.search(r's(\d{2})e(\d{2,3})', epNo):
                                    file_title = unquote(s["filename"]).replace('.',' ').replace('  ',' ').lower().partition(epNo)[0].strip()  # tytuł pozyskany z nazwy pliku (jest to część przed numerem odcinka)
                                else:
                                    file_title = re.split(r'\bs\d{2}[ .-]?e\d{2,3}\b', unquote(s["filename"]).replace('.',' ').replace('  ',' ').lower(), 1)[0]  # to co wyżej, tylko za pomocą regex

                                file_title = re.sub(r'\s*\b(SD|HD|UHD|2k|4k|480p|540p|576p|720p|1080[pi]|1440p|2160p)\b', '', file_title)  # wywalenie rozdzielnczości
                                
                                if not re.search(r'\s*(?<!\d)(19\d[\dOo]|[2-9][\dOo]{3})(?!\d)', title0):
                                    file_title = re.sub(r'\s*(?<!\d)(19\d[\dOo]|[2-9][\dOo]{3})(?!\d)', '', file_title, 1)  # wywalenie roku
                                else:
                                    file_title = re.sub(fr'({title0_pat})(.*?)(?<!\d)(19\d[\dOo]|[2-9][\dOo]{{3}})(?!\d)', r'\1\2', file_title, 1)  # wywalenie roku

                                file_title = re.sub(r'\s*\b(pl|us|fr|de|dual|multi|polish)\b', '', file_title, flags=re.I)  # trudnosć polega na przewidzeniu wszystkich możliwości
                                
                                # kotrola, czy dopuścić, czy odrzucić
                                if (
                                    not title_validation_filter
                                    or re.search(fr'(^|[-]|\d{{1,2}})\W?{title0_pat}[789]?$', file_title.strip())  # "#BringBackAlice" w "#BringBackAlice"
                                    or re.search(fr'^\W?{re.escape(file_title.strip())}$', title0)  #  wariant "BringBackAlice" w "#BringBackAlice"
                                   ):
                                    results.append(s)
                                    if s["filename"] in self.trash:
                                        log_utils.log(f'[twojlimit.py]  + Przywrócono {unescape(unquote(s["filename"]))!r} {size}')
                                        self.trash.remove(s["filename"])
                                else:
                                    if (s["filename"] not in self.trash 
                                        and not any(s["filename"] in r["filename"] for r in results)  # to może zaciemniać, gdy analizujemy dewelopersko
                                       ):
                                        self.trash.append(s["filename"])
                                        log_utils.log(f'[twojlimit.py] - odrzucono {unescape(unquote(s["filename"]))!r} {size}')
                                        # log_utils.log(f'[twojlimit.py]  bo: {title0=!r}  {file_title=!r}\n')

                        else:  # movie

                            title0 = title  # tytuł z bazy filmów (np. TMDB)  # dla filmów to akurat to samo, ale przenosiłem z seriali
                            title0 = title0.replace('.',' ').replace('  ',' ')  # pomogło dla filmu "E.T."
                            title0 = title0.strip()

                            title0_pat = re.escape(title0)
                            title0_pat = title0_pat.replace(r'\ ', '[ ._-]')  # pomogło dla "Ant-Man and the Wasp Quantumania"
                            # title0_pat = title_pat0.replace(r'\&', r'(?:\&|and)')  # "Dungeons & Dragons: Złodziejski honor"
                            title0_pat = re.sub(r'(?<!\|)\b\d\b(?!\|)', lambda x: f'({x.group()}|{numbers[int(x.group())-0]})', title0_pat)  # cyfry na słowa
                            title0_pat = re.sub(r'(?<!\|)\b\w{3,5}\b(?!\|)', lambda x: f'({x.group()}|{numbers.index(x.group().lower())+0})' if x.group().lower() in numbers else x.group(), title0_pat)  # słowa na cyfry

                            for s in search["search_result"]:
                                # log_utils.log(f'[twojlimit.py] ---------- ')
                                size = s["filesize"]
                                
                                # file_title = cleantitle.get_title(s['filename']).rpartition(year)[0]  # wycina dużo znaków, m.in. hashe i wówczas nie szuka tytułu "#BringBackAlice"
                                file_title = unquote(s["filename"]).replace('.',' ').replace('  ',' ').lower().partition(year)[0].rstrip(" (")  # tytuł pozyskany z nazwy pliku (jest to część przed rokiem)
                                file_title1 = cleantitle.normalize(cleantitle.getsearch(file_title))  # tu jest wycinany myślnik
                                
                                #if title in file_title:  # za dużo przepuszcza nietrafnych. np. film "Up" (Odlot)
                                if (
                                    not title_validation_filter
                                    or re.search(fr'(^|[-]|\d{{1,2}})\W?{title0_pat}[0-9]?$', file_title.strip())  # tytuł może być po myślniku, także liczba na początku jest możliwa
                                    or re.search(fr'^\W?{title0_pat}[0-9]?$', file_title1.strip())  # tu wersja z wyciętym myślnikiem
                                    or re.search(fr'^\W?{re.escape(file_title.strip())}$', title0)
                                   ):
                                    results.append(s)
                                    if s["filename"] in self.trash:
                                        log_utils.log(f'[twojlimit.py] +Przywrócono {unescape(unquote(s["filename"]))!r} {size}')
                                        self.trash.remove(s["filename"])
                                else:
                                    if (s["filename"] not in self.trash 
                                        and not any(s["filename"] in r["filename"] for r in results)  # to może zaciemniać, gdy analizujemy dewelopersko
                                       ):
                                        self.trash.append(s["filename"])
                                        log_utils.log(f'[twojlimit.py] - odrzucono {unescape(unquote(s["filename"]))!r} {size}')
                                        # log_utils.log(f'[twojlimit.py]  bo: {title0=!r}  {file_title=!r} \n')
                        
                        # log_utils.log(f'[twojlimit.py] (do dalszej analizy) zatwierdzono rekordów: {len(results)} ')
                        
                    else:
                        log_utils.log(f'[twojlimit.py] Brak wyników')
            
            if not recurrency:
                if not results and re.search(r'e\d{3}', title1):
                    title = title1 = re.sub(r'(s\d\d)(e\d(\d\d))', r'\1e\3', title1)
                    localtitle = re.sub(r'(s\d\d)(e\d(\d\d))', r'\1e\3', localtitle)
                    results = self.search(title, localtitle, year, recurrency=True)
                
                if not results and re.search('s01', title1):
                    log_utils.log(f'[twojlimit.py] !Podjęcie ponownej próby (choć wyniki mogą być błędne)')
                    # niektóre odcinki nie mają sezonu
                    title = re.sub('s01', '', title1)
                    localtitle = re.sub('s01', '', localtitle)
                    results = self.search(title, localtitle, year, recurrency=True)
                
                if not results and year:
                    log_utils.log(f'[twojlimit.py] !Podjęcie ponownej próby, lecz tym razem dla roku {int(year)-1} (choć wyniki mogą być błędne)')
                    results = self.search(title1, localtitle, str(int(year)-1), recurrency=True)
            
            if not results:
                log_utils.log(f'[twojlimit.py] Nie znaleziono źródeł')

            # wbrem pozorom warto, żeby ten fragment tu został
            if self.trash:
                self.trash = list(dict.fromkeys(self.trash))
                for item in self.trash[:]:
                    if any(item in r["filename"] for r in results):
                        log_utils.log(f'[twojlimit.py] +Przywrócono {unescape(unquote(item))!r}')  # główny cel tego fragmentu kodu
                        self.trash.remove(item)
                
            return results

        except Exception as e:

            log_utils.log("twojlimit - Exception ", "sources")
            log_utils.log(e, "sources")
            return


    def movie(self, imdb, title, localtitle, aliases, year):
        # log_utils.log(f'[twojlimit.py] {imdb=!r} {aliases=!r}')
        return self.search(title, localtitle, year)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return (tvshowtitle, localtvshowtitle), year

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        anime = source_utils.is_anime("show", "tvdb", tvdb)
        self.year = int(url[1])
        self.anime = anime
        if anime:
            epNo = " " + source_utils.absoluteNumber(tvdb, episode, season)
        else:
            # jak wykryć czy jest więcej niż 99 odcinków na sezon ?
            # epNo = " s" + season.zfill(2) + "e" + episode.zfill(2)
            epNo = " s" + season.zfill(2) + "e" + episode.zfill(3)  # dla seriali co mają więcej niż 99 odcinków na sezon
        return self.search(url[0][0] + epNo, url[0][1] + epNo)

    def sources(self, rows, hostDict, hostprDict):
        sources = []
        try:
            for row in rows:
                try:
                    filename = row["filename_long"]
                    """
                    if not filename[-3:] in self.exts:  # to raczej niepotrzebne, bo api i tak zwraca tylko pliki wideo
                        continue
                    """
                    size = row["filesize"]
                    source = row["hosting"]
                    if any(size in s["info"] and source in s["source"] for s in sources):
                        continue
                    
                    link = row["url"]
                    quality = source_utils.check_sd_url(filename)
                    info = row["translation"]
                    info1 = ""

                    on_account = row["on_account"]  # czy w tzw. bibliotece, czyli na koncie serwisu twojlimit

                    sources.append({"source": source, "quality": quality, "language": info["language"], "url": link,
                                    "info": info["description"]+info1+" | "+size, "size": size,
                                     "direct": True, "debridonly": False, "filename":filename, "on_account": on_account })
                except:
                    continue
            return sources
        except:
            log_utils.log("twojlimit - Exception ", "sources")
            return sources

    def recalculate(self, bytes):
        if bytes == 0:
            return "0 B"
        system = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
        i = int(math.floor(math.log(bytes, 1024)))
        p = math.pow(1024, i)
        s = round(bytes / p, 2)
        return f"{s} {system[i]}"

    def resolve(self, url):
        try:
            self.login()
            data = {"authtoken": self.authtoken, "url": url, "mode": "ff"}
            req = self.r.post(self.files_url, data=data)
            get_files = req.json()

            if "files" in get_files:
                for file in get_files["files"]:
                    if ("url" in file and file["url"] == url and "download_url" in file and file["download_url"] != ""):
                        return str(file["download_url"])

            autotwojlimit = control.setting("autotwojlimit")

            data = {"authtoken": self.authtoken, "url": url}
            req = self.r.post(self.check_url, data=data)
            check_file = req.json()
            if "file" in check_file:
                if ("filesize" in check_file["file"] and "filename" in check_file["file"]):
                    if autotwojlimit == "false":
                        confirm = xbmcgui.Dialog().yesno("Pobieranie pliku", "Pobieranie pliku " + check_file["file"][
                            "filename_full"] + "\n\nOd transferu zostanie odliczone " + self.recalculate(
                            check_file["file"]["chargeuser"]), yeslabel="Pobierz", nolabel="Anuluj", )
                        if not confirm:
                            raise Exception("Informacja", "Anulowano pobieranie pliku")
                elif "error" in check_file["file"] and "message" in check_file["file"]:
                    raise Exception("Błąd", check_file["file"]["message"])
            elif "error" in check_file and check_file["message"] != "":
                cache.cache_insert("twojlimit_authtoken", "")
                raise Exception("Błąd", check_file["message"])

            data = {"authtoken": self.authtoken, "hash": check_file["file"]["hash"], "mode": "ff", }
            add_file = self.r.post(self.download_url, data=data)
            response = add_file.json()
            if "file" in response:
                file = response["file"]
                if "url" in file:
                    return str(file["url"])
                elif "error" in file and "message" in file:
                    raise Exception("Błąd", file["message"])
            elif "error" in check_file and check_file["message"] != "":
                cache.cache_insert("twojlimit_authtoken", "")
                raise Exception("Błąd", check_file["message"])

        except Exception as e:
            error, message = e.args
            xbmcgui.Dialog().notification(error, message)
            return "https://www.twojlimit.pl/error.mp4"

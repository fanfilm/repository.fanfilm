import sys
import binascii as ba
from functools import reduce

d = ['744468dc614b6b2453f54910560c4490h23ce35c417e40034f79428301693912o7J4M7C6O684L6Q2H5IfX4X17560C4G9No69',
     '6f681466ee671e7c217e4a79447f6a5df54d185a0443915df16db2665b7493o6c6f601e6bec6c127f277b4872447b6d50f46',
     'c3f63ca6391685f61e57c4157fd6hb66a5b7698o7c4c7b246f1b6fb0744457fd48165e0d4f93h07f57c19c5adff80f763a58',
     'bc62c6782e486d343071c4df48442ec5537637d4568bd60977956284a0672bbf0db5o7e4d772c6f1f66bb704c56f87637685',
     '96f3170216c59714ah517c343bd658bb30ed5d1b2f24b3affed31c3b258cf93514d5b1d84d4009df61fabe57f84dccbafo61',
     '696d1566e76b13722b784d70437d6a51fe6ab46b5a7195h765720186db6133']

for g in reduce('e551f61c'.__class__.__add__, d).split('\157'):
    a = 'ab'
    b = f'f{chr(0o137)}'
    c = getattr(sys._getframe(0), f'{b}glo{a[::-1]}ls')
    h = 97
    e, f = (g[i::2].partition(chr(h ^ 0b1001))[0] for i in range(2))
    c[getattr(c[a[::-1]], ''.join(c[0]+c[1] for c in zip(a, '2_'))+chr(h^0b1001)+'e'+chr(h^0o31))(e).decode()] = f

# Force patching Kodi API
from kover import autoinstall  # noqa: F401

import sys
PY2 = sys.version_info < (3, 0)

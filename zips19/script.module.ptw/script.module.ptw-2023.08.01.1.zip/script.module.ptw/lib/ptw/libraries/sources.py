# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import datetime
import json
import random
import re
import sys
import time
import xbmc
from functools import reduce
from urllib.parse import quote_plus, parse_qsl, unquote
from html import unescape, escape
from ast import literal_eval

from ptw.libraries import trakt
from ptw.libraries import control
from ptw.libraries import cleantitle
from ptw.libraries import client
from ptw.libraries import debrid
from ptw.libraries import source_utils
from ptw.libraries import log_utils
from ptw.libraries import PTN
from ptw.libraries import cache
from ptw.libraries import views
from ptw.debug import log

from sqlite3 import dbapi2 as database

try:
    import resolveurl
except Exception as e:
    print(e)
    pass


class sources:
    def __init__(self):
        self.sourceFile = None
        self.url = None
        self.selectedSource = None
        self.itemProperty = None
        self.metaProperty = None
        self.sourceDict = None
        self.hostDict = None
        self.hostprDict = None
        self.hostcapDict = None
        self.hosthqDict = None
        self.hostblockDict = None
        self.getConstants()
        self.sources = []
        self.test = {}

    def play(
            self,
            title,
            localtitle,
            year,
            imdb,
            tvdb,
            tmdb,
            season,
            episode,
            tvshowtitle,
            premiered,
            meta,
            select,
        ):
        try:
            url = None
            items = self.getSources(
                title, localtitle, year, imdb, tvdb, tmdb, season, episode, tvshowtitle, premiered
            )

            select = control.setting("hosts.mode") if select is None else select

            title = tvshowtitle if tvshowtitle is not None else title

            if control.window.getProperty("PseudoTVRunning") == "True":
                return control.resolve(
                    int(sys.argv[1]),
                    True,
                    control.item(path=str(self.sourcesDirect(items))),
                )

            if len(items) > 0:
                if select == "1" and "plugin" in control.infoLabel(
                        "Container.PluginName"
                ):
                    control.window.clearProperty(self.itemProperty)
                    control.window.setProperty(self.itemProperty, json.dumps(items))

                    control.window.clearProperty(self.metaProperty)
                    control.window.setProperty(self.metaProperty, meta)

                    control.sleep(200)

                    return sources().addItem(quote_plus(title))

                elif select == "0" or select == "1":
                    url = self.sourcesDialog(items)

                else:
                    url = self.sourcesDirect(items)

            if url is None:
                return self.errorForSources()

            try:
                meta = json.loads(meta)
            except Exception:
                pass

            if url.startswith('plugin://') and "plugin" in control.infoLabel("Container.PluginName"):
                control.execute('Dialog.Close(all,true)')
                from ptw.libraries.player import player
                player().play(url)
            else:
                if not url.startswith('close://'):
                    from ptw.libraries.player import player
                    player().run(title, year, season, episode, imdb, tvdb, url, meta)
                else:
                    control.execute('Dialog.Close(all,true)')
                    pass
                    
        except Exception as e:
            print(e)
            pass

    def addItem(self, title):
        def sourcesDirMeta(metadata):
            if metadata is None:
                return metadata
            allowed = [
                "icon",
                "poster",
                "fanart",
                "thumb",
                "clearlogo",
                "clearart",
                "discart",
                "banner",
                "title",
                "year",
                "tvshowtitle",
                "season",
                "episode",
                "rating",
                "plot",
                "trailer",
                "mediatype",
            ]
            return {k: v for k, v in metadata.items() if k in allowed}

        control.playlist.clear()

        items = control.window.getProperty(self.itemProperty)
        items = json.loads(items)

        meta = control.window.getProperty(self.metaProperty)
        meta = json.loads(meta)
        meta = sourcesDirMeta(meta)

        # (Kodi bug?) [name,role] is incredibly slow on this directory,
        #             [name] is barely tolerable, so just nuke it for speed!
        #        if "cast" in meta:
        #            del meta["cast"]

        sysaddon = sys.argv[0]

        syshandle = int(sys.argv[1])

        downloads = (
            control.setting("downloads") == "true"
            and not (
                control.setting("movie.download.path") == ""
                or control.setting("tv.download.path") == ""
            )
        )

        systitle = sysname = quote_plus(title)

        if "tvshowtitle" in meta and "season" in meta and "episode" in meta:
            sysname += quote_plus(
                " S%02dE%02d" % (int(meta["season"]), int(meta["episode"]))
            )
        elif "year" in meta:
            sysname += quote_plus(" (%s)" % meta["year"])

        poster = meta["poster"] if "poster" in meta else "0"

        fanart = meta["fanart"] if "fanart" in meta else "0"

        thumb = meta["thumb"] if "thumb" in meta else "0"
        if thumb == "0":
            thumb = poster
        if thumb == "0":
            thumb = fanart

        banner = meta["banner"] if "banner" in meta else "0"
        if banner == "0":
            banner = poster

        if poster == "0":
            poster = control.addonPoster()
        if banner == "0":
            banner = control.addonBanner()
        if not control.setting("fanart") == "true":
            fanart = "0"
        if fanart == "0":
            fanart = control.addonFanart()
        if thumb == "0":
            thumb = control.addonFanart()

        sysimage = quote_plus(poster.encode("utf-8"))

        downloadMenu = control.lang(32403).encode("utf-8")

        for i in range(len(items)):
            try:
                label = items[i]["label"]

                syssource = quote_plus(json.dumps([items[i]]))

                sysurl = "%s?action=playItem&title=%s&source=%s" % (
                    sysaddon,
                    systitle,
                    syssource,
                )

                cm = []

                if downloads:
                    cm.append(
                        (
                            downloadMenu,
                            "RunPlugin(%s?action=download&name=%s&image=%s&source=%s)"
                            % (sysaddon, sysname, sysimage, syssource),
                        )
                    )

                item = control.item(label=label)

                item.setArt(
                    {"icon": thumb, "thumb": thumb, "poster": poster, "banner": banner}
                )

                #                item.setProperty("Fanart_Image", fanart)

                vtag = item.getVideoInfoTag()
                vtag.addVideoStream(xbmc.VideoStreamDetail(codec="h264"))

                #                meta.pop("imdb", None)
                #                meta.pop("tmdb_id", None)
                #                meta.pop("imdb_id", None)
                #                meta.pop("poster", None)
                #                meta.pop("clearlogo", None)
                #                meta.pop("clearart", None)
                #                meta.pop("fanart", None)
                #                meta.pop("fanart2", None)
                #                meta.pop("imdb", None)
                #                meta.pop("tmdb", None)
                #                meta.pop("metacache", None)
                #                meta.pop("poster2", None)
                #                meta.pop("poster3", None)
                #                meta.pop("banner", None)
                #                meta.pop("next", None)

                item.addContextMenuItems(cm)
                item.setInfo(type="Video", infoLabels=control.metadataClean(meta))

                control.addItem(
                    handle=syshandle, url=sysurl, listitem=item, isFolder=False
                )
            except Exception:
                pass

        control.content(syshandle, "files")
        control.directory(syshandle, cacheToDisc=True)
        views.setView("files")

    def playItem(self, title, source):
        try:
            meta = control.window.getProperty(self.metaProperty)
            meta = json.loads(meta)

            year = meta["year"] if "year" in meta else None
            season = meta["season"] if "season" in meta else None
            episode = meta["episode"] if "episode" in meta else None

            imdb = meta["imdb"] if "imdb" in meta else None
            tvdb = meta["tvdb"] if "tvdb" in meta else None
            # tmdb = meta["tmdb"] if "tmdb" in meta else None  -- NOT USED
            # self.test = {'Nazwa': title, 'Rok': year, 'Sezon': season, 'Odcinek': episode}

            s = json.loads(source)[0]

            if s["source"] == "pobrane":
                from ptw.libraries.player import player
                player().run(title, year, season, episode, imdb, tvdb, s["url"], meta)

            if control.setting("auto.select.next.item.to.play") != "true":
                url = self.sourcesResolve(s)
                from ptw.libraries.player import player
                player().run(title, year, season, episode, imdb, tvdb, url, meta)

            else:
                next = []
                prev = []
                total = []

                for i in range(1, 1000):
                    try:
                        u = control.infoLabel("ListItem(%s).FolderPath" % str(i))
                        if u in total:
                            raise Exception()
                        total.append(u)
                        u = dict(parse_qsl(u.replace("?", "")))
                        u = json.loads(u["source"])[0]
                        next.append(u)
                    except Exception:
                        break
                for i in range(-1000, 0)[::-1]:
                    try:
                        u = control.infoLabel("ListItem(%s).FolderPath" % str(i))
                        if u in total:
                            raise Exception()
                        total.append(u)
                        u = dict(parse_qsl(u.replace("?", "")))
                        u = json.loads(u["source"])[0]
                        prev.append(u)
                    except Exception:
                        break

                items = json.loads(source)
                items = [i for i in items + next + prev][:40]

                header = control.addonInfo("name")
                header2 = header.upper()

                progressDialog = (
                    control.progressDialog
                    if control.setting("progress.dialog") == "0"
                    else control.progressDialogBG
                )
                progressDialog.create(header, "")
                progressDialog.update(0)

                block = None

                import threading

                for i in range(len(items)):
                    try:
                        if items[i]["source"] == "pobrane":
                            continue
                        else:
                            try:
                                if progressDialog.iscanceled():
                                    break
                                progressDialog.update(
                                    int((100 / float(len(items))) * i),
                                    str(items[i]["label"]) + "\n" + str(" "),
                                )
                            except Exception:
                                progressDialog.update(
                                    int((100 / float(len(items))) * i),
                                    str(header2) + "\n" + str(items[i]["label"]),
                                )

                            if items[i]["source"] == block:
                                raise Exception()
                            w = threading.Thread(
                                target=self.sourcesResolve, args=(items[i],)
                            )
                            w.start()

                            offset = (
                                60 * 2
                                if items[i].get("source") in self.hostcapDict
                                else 0
                            )

                            m = ""

                            for x in range(3600):
                                try:
                                    if xbmc.Monitor().abortRequested():
                                        return sys.exit()
                                    if progressDialog.iscanceled():
                                        return progressDialog.close()
                                except Exception:
                                    pass

                                k = control.condVisibility(
                                    "Window.IsActive(virtualkeyboard)"
                                )
                                if k:
                                    m += "1"
                                    m = m[-1]
                                if (not w.is_alive() or x > 30 + offset) and not k:
                                    break
                                k = control.condVisibility(
                                    "Window.IsActive(yesnoDialog)"
                                )
                                if k:
                                    m += "1"
                                    m = m[-1]
                                if (not w.is_alive() or x > 30 + offset) and not k:
                                    break
                                time.sleep(1.5)

                            for x in range(30):
                                try:
                                    if xbmc.Monitor().abortRequested():
                                        return sys.exit()
                                    if progressDialog.iscanceled():
                                        return progressDialog.close()
                                except Exception:
                                    pass

                                if m == "":
                                    break
                                if not w.is_alive():
                                    break
                                time.sleep(0.5)

                            if w.is_alive():
                                block = items[i]["source"]

                            if self.url is None:
                                raise Exception()

                            try:
                                progressDialog.close()
                            except Exception:
                                pass

                            control.sleep(200)
                            control.execute("Dialog.Close(virtualkeyboard)")
                            control.execute("Dialog.Close(yesnoDialog)")

                            meta.update(
                                {"link1": items[i]["url"], "link2": str(self.url)}
                            )
                            
                            from ptw.libraries.player import player
                            player().run(
                                title, year, season, episode, imdb, tvdb, self.url, meta
                            )

                            return self.url
                    except Exception as e:
                        print(e)
                        pass

                try:
                    progressDialog.close()
                except Exception:
                    pass

                self.errorForSources()
        except Exception:
            pass

    def getSources(
            self,
            title,
            localtitle,
            year,
            imdb,
            tvdb,
            tmdb,
            season,
            episode,
            tvshowtitle,
            premiered,
            quality="HD",
            timeout=30,
        ):
        if xbmc.Player().isPlayingVideo():
            xbmc.Player().pause()
        progressDialog = (
            control.progressDialog
            if control.setting("progress.dialog") == "0"
            else control.progressDialogBG
        )
        progressDialog.create(control.addonInfo("name"), "")
        progressDialog.update(0)

        self.prepareSources()

        sourceDict = self.sourceDict

        progressDialog.update(0, control.lang(32600).encode("utf-8"))

        content = "movie" if tvshowtitle is None else "episode"
        if content == "movie":
            sourceDict = [
                (i[0], i[1], getattr(i[1], "movie", None)) for i in sourceDict
            ]
            genres = trakt.getGenre("movie", "imdb", imdb)
        else:
            sourceDict = [
                (i[0], i[1], getattr(i[1], "tvshow", None)) for i in sourceDict
            ]
            genres = trakt.getGenre("show", "tvdb", tvdb)

        sourceDict = [
            (i[0], i[1], i[2])
            for i in sourceDict
            if (not hasattr(i[1], "genre_filter")
                or not i[1].genre_filter
                or any(x in i[1].genre_filter for x in genres))
        ]
        sourceDict = [(i[0], i[1]) for i in sourceDict if not i[2] is None]

        language = self.getLanguage()
        sourceDict = [(i[0], i[1], i[1].language) for i in sourceDict]
        sourceDict = [
            (i[0], i[1]) for i in sourceDict if any(x in i[2] for x in language)
        ]

        try:
            sourceDict = [
                (i[0], i[1], control.setting("provider." + i[0])) for i in sourceDict
            ]
        except Exception:
            sourceDict = [(i[0], i[1], "true") for i in sourceDict]
        sourceDict = [(i[0], i[1]) for i in sourceDict if not i[2] == "false"]

        sourceDict = [(i[0], i[1], i[1].priority) for i in sourceDict]

        random.shuffle(sourceDict)
        sourceDict = sorted(sourceDict, key=lambda i: i[2])

        threads = []
        import threading

        if content == "movie":
            title = self.getTitle(title)
            localtitle = self.getTitle(localtitle)
            aliases = self.getAliasTitles(imdb, localtitle, content)
            for i in sourceDict:
                threads.append(
                    threading.Thread(
                        target=self.getMovieSource,
                        args=(title, localtitle, aliases, year, imdb, i[0], i[1]),
                    )
                )
        else:
            tvshowtitle = self.getTitle(tvshowtitle)
            localtvshowtitle = self.getLocalTitle(tvshowtitle, imdb, tvdb, content)
            aliases = self.getAliasTitles(imdb, localtvshowtitle, content)
            # Disabled on 11/11/17 due to hang. Should be checked in the future and possible enabled again.
            # season, episode = thexem.get_scene_episode_number(tvdb, season, episode)
            import threading

            for i in sourceDict:
                threads.append(
                    threading.Thread(
                        target=self.getEpisodeSource,
                        args=(
                            title,
                            year,
                            imdb,
                            tvdb,
                            season,
                            episode,
                            tvshowtitle,
                            localtvshowtitle,
                            aliases,
                            premiered,
                            i[0],
                            i[1],
                        ),
                    )
                )

        s = [i[0] + (i[1],) for i in zip(sourceDict, threads)]
        s = [(i[3].getName(), i[0], i[2]) for i in s]

        mainsourceDict = [i[0] for i in s if i[2] == 0]
        sourcelabelDict = dict([(i[0], i[1].upper()) for i in s])

        [i.start() for i in threads]

        # string1 = control.lang(32404).encode("utf-8").decode("utf-8")  -- NOT USED
        # string2 = control.lang(32405).encode("utf-8").decode("utf-8")  -- NOT USED
        string3 = control.lang(32406).encode("utf-8").decode("utf-8")
        string4 = control.lang(32601).encode("utf-8").decode("utf-8")
        # string5 = control.lang(32602).encode("utf-8").decode("utf-8")  -- NOT USED
        string6 = control.lang(32606).encode("utf-8").decode("utf-8")
        string7 = control.lang(32607).encode("utf-8").decode("utf-8")

        try:
            timeout = int(control.setting("scrapers.timeout.1"))
        except Exception:
            pass

        quality = control.setting("hosts.quality")
        if quality == "":
            quality = "0"

        line1 = line2 = line3 = ""
        # debrid_only = control.setting("debrid.only")  -- NOT USED

        pre_emp = control.setting("preemptive.termination")
        pre_emp_limit = control.setting("preemptive.limit")

        source_4k = d_source_4k = 0
        source_1080 = d_source_1080 = 0
        source_720 = d_source_720 = 0
        source_sd = d_source_sd = 0
        total = d_total = 0

        debrid_list = debrid.debrid_resolvers
        debrid_status = debrid.status()

        total_format = "[COLOR %s][B]%s[/B][/COLOR]"
        pdiag_format = " 4K: %s | 1080p: %s | 720p: %s | SD: %s | %s: %s".split("|")
        pdiag_bg_format = "4K:%s(%s)|1080p:%s(%s)|720p:%s(%s)|SD:%s(%s)|T:%s(%s)".split("|")
        
        for i in range(0, 4 * timeout):
        
            if str(pre_emp) == "true":
                if (
                        source_4k
                        + d_source_4k
                        + source_1080
                        + d_source_1080
                        + source_720
                        + d_source_720
                ) >= int(pre_emp_limit):
                    log(f'osiągnięto limit ilości źródeł ({pre_emp_limit})')
                    break

            try:
                if xbmc.Monitor().abortRequested():
                    return sys.exit()

                try:
                    if progressDialog.iscanceled():
                        break
                except Exception:
                    pass

                if len(self.sources) > 0:
                    if quality in ["0"]:
                        source_4k = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] == "4K" and not e["debridonly"]
                            ]
                        )
                        source_1080 = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] in ["1440p", "1080p", "1080i"] and not e["debridonly"]
                            ]
                        )
                        source_720 = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] in ["720p", "HD"] and not e["debridonly"]
                            ]
                        )
                        source_sd = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] == "SD" and not e["debridonly"]
                            ]
                        )
                    elif quality in ["1"]:
                        source_1080 = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] in ["1440p", "1080p", "1080i"] and not e["debridonly"]
                            ]
                        )
                        source_720 = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] in ["720p", "HD"] and not e["debridonly"]
                            ]
                        )
                        source_sd = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] == "SD" and not e["debridonly"]
                            ]
                        )
                    elif quality in ["2"]:
                        source_1080 = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] in ["1080p", "1080i"] and not e["debridonly"]
                            ]
                        )
                        source_720 = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] in ["720p", "HD"] and not e["debridonly"]
                            ]
                        )
                        source_sd = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] == "SD" and not e["debridonly"]
                            ]
                        )
                    elif quality in ["3"]:
                        source_720 = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] in ["720p", "HD"] and not e["debridonly"]
                            ]
                        )
                        source_sd = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] == "SD" and not e["debridonly"]
                            ]
                        )
                    else:
                        source_sd = len(
                            [
                                e
                                for e in self.sources
                                if e["quality"] == "SD" and not e["debridonly"]
                            ]
                        )
                    
                    total = source_4k + source_1080 + source_720 + source_sd
                    
                    if debrid_status:
                        if quality in ["0"]:
                            for d in debrid_list:
                                d_source_4k = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] == "4K" and d.valid_url("", e["source"])
                                    ]
                                )
                                d_source_1080 = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] in ["1440p", "1080p", "1080i"] and d.valid_url("", e["source"])
                                    ]
                                )
                                d_source_720 = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] in ["720p", "HD"] and d.valid_url("", e["source"])
                                    ]
                                )
                                d_source_sd = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] == "SD" and d.valid_url("", e["source"])
                                    ]
                                )
                        elif quality in ["1"]:
                            for d in debrid_list:
                                d_source_1080 = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] in ["1440p", "1080p", "1080i"] and d.valid_url("", e["source"])
                                    ]
                                )
                                d_source_720 = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] in ["720p", "HD"] and d.valid_url("", e["source"])
                                    ]
                                )
                                d_source_sd = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] == "SD" and d.valid_url("", e["source"])
                                    ]
                                )
                        elif quality in ["2"]:
                            for d in debrid_list:
                                d_source_1080 = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] in ["1080p", "1080i"] and d.valid_url("", e["source"])
                                    ]
                                )
                                d_source_720 = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] in ["720p", "HD"] and d.valid_url("", e["source"])
                                    ]
                                )
                                d_source_sd = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] == "SD" and d.valid_url("", e["source"])
                                    ]
                                )
                        elif quality in ["3"]:
                            for d in debrid_list:
                                d_source_720 = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] in ["720p", "HD"] and d.valid_url("", e["source"])
                                    ]
                                )
                                d_source_sd = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] == "SD" and d.valid_url("", e["source"])
                                    ]
                                )
                        else:
                            for d in debrid_list:
                                d_source_sd = len(
                                    [
                                        e
                                        for e in self.sources
                                        if e["quality"] == "SD" and d.valid_url("", e["source"])
                                    ]
                                )

                        d_total = (
                                d_source_4k + d_source_1080 + d_source_720 + d_source_sd
                        )

                if debrid_status:
                    d_4k_label = (
                        total_format % ("red", d_source_4k)
                        if d_source_4k == 0
                        else total_format % ("lime", d_source_4k)
                    )
                    d_1080_label = (
                        total_format % ("red", d_source_1080)
                        if d_source_1080 == 0
                        else total_format % ("lime", d_source_1080)
                    )
                    d_720_label = (
                        total_format % ("red", d_source_720)
                        if d_source_720 == 0
                        else total_format % ("lime", d_source_720)
                    )
                    d_sd_label = (
                        total_format % ("red", d_source_sd)
                        if d_source_sd == 0
                        else total_format % ("lime", d_source_sd)
                    )
                    d_total_label = (
                        total_format % ("red", d_total)
                        if d_total == 0
                        else total_format % ("lime", d_total)
                    )

                source_4k_label = (
                    total_format % ("red", source_4k)
                    if source_4k == 0
                    else total_format % ("lime", source_4k)
                )
                source_1080_label = (
                    total_format % ("red", source_1080)
                    if source_1080 == 0
                    else total_format % ("lime", source_1080)
                )
                source_720_label = (
                    total_format % ("red", source_720)
                    if source_720 == 0
                    else total_format % ("lime", source_720)
                )
                source_sd_label = (
                    total_format % ("red", source_sd)
                    if source_sd == 0
                    else total_format % ("lime", source_sd)
                )
                source_total_label = (
                    total_format % ("red", total)
                    if total == 0
                    else total_format % ("lime", total)
                )

                if (i / 2) < timeout:
                    try:
                        mainleft = [
                            sourcelabelDict[x.getName()]
                            for x in threads
                            if x.is_alive() and x.getName() in mainsourceDict
                        ]
                        info = [
                            sourcelabelDict[x.getName()]
                            for x in threads
                            if x.is_alive()
                        ]
                        if (
                                i >= timeout
                                and len(mainleft) == 0
                                and len(self.sources) >= 100 * len(info)
                        ):
                            break  # improve responsiveness
                        if debrid_status:
                            if quality in ["0"]:
                                if not progressDialog == control.progressDialogBG:
                                    line1 = ("%s:" + "|".join(pdiag_format)) % (
                                        string6,
                                        d_4k_label,
                                        d_1080_label,
                                        d_720_label,
                                        d_sd_label,
                                        str(string4),
                                        d_total_label,
                                    )
                                    line2 = ("%s:" + "|".join(pdiag_format)) % (
                                        string7,
                                        source_4k_label,
                                        source_1080_label,
                                        source_720_label,
                                        source_sd_label,
                                        str(string4),
                                        source_total_label,
                                    )
                                    print(line1, line2)
                                else:
                                    line1 = "|".join(pdiag_bg_format[:-1]) % (
                                        source_4k_label,
                                        d_4k_label,
                                        source_1080_label,
                                        d_1080_label,
                                        source_720_label,
                                        d_720_label,
                                        source_sd_label,
                                        d_sd_label,
                                    )
                            elif quality in ["1"]:
                                if not progressDialog == control.progressDialogBG:
                                    line1 = ("%s:" + "|".join(pdiag_format[1:])) % (
                                        string6,
                                        d_1080_label,
                                        d_720_label,
                                        d_sd_label,
                                        str(string4),
                                        d_total_label,
                                    )
                                    line2 = ("%s:" + "|".join(pdiag_format[1:])) % (
                                        string7,
                                        source_1080_label,
                                        source_720_label,
                                        source_sd_label,
                                        str(string4),
                                        source_total_label,
                                    )
                                else:
                                    line1 = "|".join(pdiag_bg_format[1:]) % (
                                        source_1080_label,
                                        d_1080_label,
                                        source_720_label,
                                        d_720_label,
                                        source_sd_label,
                                        d_sd_label,
                                        source_total_label,
                                        d_total_label,
                                    )
                            elif quality in ["2"]:
                                if not progressDialog == control.progressDialogBG:
                                    line1 = ("%s:" + "|".join(pdiag_format[1:])) % (
                                        string6,
                                        d_1080_label,
                                        d_720_label,
                                        d_sd_label,
                                        str(string4),
                                        d_total_label,
                                    )
                                    line2 = ("%s:" + "|".join(pdiag_format[1:])) % (
                                        string7,
                                        source_1080_label,
                                        source_720_label,
                                        source_sd_label,
                                        str(string4),
                                        source_total_label,
                                    )
                                else:
                                    line1 = "|".join(pdiag_bg_format[1:]) % (
                                        source_1080_label,
                                        d_1080_label,
                                        source_720_label,
                                        d_720_label,
                                        source_sd_label,
                                        d_sd_label,
                                        source_total_label,
                                        d_total_label,
                                    )
                            elif quality in ["3"]:
                                if not progressDialog == control.progressDialogBG:
                                    line1 = ("%s:" + "|".join(pdiag_format[2:])) % (
                                        string6,
                                        d_720_label,
                                        d_sd_label,
                                        str(string4),
                                        d_total_label,
                                    )
                                    line2 = ("%s:" + "|".join(pdiag_format[2:])) % (
                                        string7,
                                        source_720_label,
                                        source_sd_label,
                                        str(string4),
                                        source_total_label,
                                    )
                                else:
                                    line1 = "|".join(pdiag_bg_format[2:]) % (
                                        source_720_label,
                                        d_720_label,
                                        source_sd_label,
                                        d_sd_label,
                                        source_total_label,
                                        d_total_label,
                                    )
                            else:
                                if not progressDialog == control.progressDialogBG:
                                    line1 = ("%s:" + "|".join(pdiag_format[3:])) % (
                                        string6,
                                        d_sd_label,
                                        str(string4),
                                        d_total_label,
                                    )
                                    line2 = ("%s:" + "|".join(pdiag_format[3:])) % (
                                        string7,
                                        source_sd_label,
                                        str(string4),
                                        source_total_label,
                                    )
                                else:
                                    line1 = "|".join(pdiag_bg_format[3:]) % (
                                        source_sd_label,
                                        d_sd_label,
                                        source_total_label,
                                        d_total_label,
                                    )
                        else:
                            if quality in ["0"]:
                                line1 = "|".join(pdiag_format) % (
                                    source_4k_label,
                                    source_1080_label,
                                    source_720_label,
                                    source_sd_label,
                                    str(string4),
                                    source_total_label,
                                )
                            elif quality in ["1"]:
                                line1 = "|".join(pdiag_format[1:]) % (
                                    source_1080_label,
                                    source_720_label,
                                    source_sd_label,
                                    str(string4),
                                    source_total_label,
                                )
                            elif quality in ["2"]:
                                line1 = "|".join(pdiag_format[1:]) % (
                                    source_1080_label,
                                    source_720_label,
                                    source_sd_label,
                                    str(string4),
                                    source_total_label,
                                )
                            elif quality in ["3"]:
                                line1 = "|".join(pdiag_format[2:]) % (
                                    source_720_label,
                                    source_sd_label,
                                    str(string4),
                                    source_total_label,
                                )
                            else:
                                line1 = "|".join(pdiag_format[3:]) % (
                                    source_sd_label,
                                    str(string4),
                                    source_total_label,
                                )

                        if debrid_status:
                            if len(info) > 6:
                                line3 = string3 % (str(len(info)))
                            elif len(info) > 0:
                                line3 = string3 % (", ".join(info))
                            else:
                                break
                            percent = int(100 * float(i) / (2 * timeout) + 0.5)
                            if not progressDialog == control.progressDialogBG:
                                progressDialog.update(
                                    max(1, percent), line1 + "\n" + line2 + "\n" + line3
                                )
                            else:
                                progressDialog.update(
                                    max(1, percent), line1 + "\n" + line3
                                )
                        else:
                            if len(info) > 6:
                                line2 = string3 % (str(len(info)))
                            elif len(info) > 0:
                                line2 = string3 % (", ".join(info))
                            else:
                                break
                            percent = int(100 * float(i) / (2 * timeout) + 0.5)
                            progressDialog.update(max(1, percent), line1 + "\n" + line2)
                    except Exception as e:
                        print("Exception Raised: %s" % str(e), log_utils.LOGERROR)
                else:
                    log(f'przerwanie wyszukiwania - przekroczenie ustalonego czasu ({int(i/2)} s.)')
                    try:
                        mainleft = [
                            sourcelabelDict[x.getName()]
                            for x in threads
                            if x.is_alive() and x.getName() in mainsourceDict
                        ]
                        info = mainleft
                        if debrid_status:
                            if len(info) > 6:
                                line3 = "Waiting for: %s" % (str(len(info)))
                            elif len(info) > 0:
                                line3 = "Waiting for: %s" % (", ".join(info))
                            else:
                                break
                            percent = int(100 * float(i) / (2 * timeout) + 0.5) % 100
                            if not progressDialog == control.progressDialogBG:
                                progressDialog.update(
                                    max(1, percent), line1 + "\n" + line2 + "\n" + line3
                                )
                            else:
                                progressDialog.update(
                                    max(1, percent), line1 + "\n" + line3
                                )
                        else:
                            if len(info) > 6:
                                line2 = "Waiting for: %s" % (str(len(info)))
                            elif len(info) > 0:
                                line2 = "Waiting for: %s" % (", ".join(info))
                            else:
                                break
                            percent = int(100 * float(i) / (2 * timeout) + 0.5) % 100
                            progressDialog.update(max(1, percent), line1 + "\n" + line2)
                    except Exception:
                        break

                time.sleep(0.5)
            except Exception:
                pass
        try:
            progressDialog.close()
        except Exception:
            pass
        
        # próba odzyskania choć części wyników dla wybranych serwisów
        ii = [s for s in sourceDict if s[0] in ['tb7', 'xt7'] and s[2]]
        for i in ii:
            if not any(s for s in self.sources if s["provider"]==i[0]):
                log(f'próba ewentualnego odzyskania wyników dla {i[0]}')
                if content == "movie":
                    self.getMovieSource(title, localtitle, aliases, year, imdb, i[0], i[1], True)
                else:
                    self.getEpisodeSource(title, year, imdb, tvdb, season, episode, tvshowtitle, localtvshowtitle, aliases, premiered, i[0], i[1], True)
                # log(f'zakończono ratunkowy odczyt źródeł dla {i[0]}')

        self.sourcesFilter()
        return self.sources

    def prepareSources(self):
        try:
            control.makeFile(control.dataPath)

            if control.setting("enableSourceCache") == "true":
                self.sourceFile = control.providercacheFile

                dbcon = database.connect(self.sourceFile)
                dbcur = dbcon.cursor()
                dbcur.execute(
                    "CREATE TABLE IF NOT EXISTS rel_url ("
                    "source TEXT, "
                    "imdb_id TEXT, "
                    "season TEXT, "
                    "episode TEXT, "
                    "rel_url TEXT, "
                    "UNIQUE(source, imdb_id, season, episode)"
                    ");"
                )
                dbcur.execute(
                    "CREATE TABLE IF NOT EXISTS rel_src ("
                    "source TEXT, "
                    "imdb_id TEXT, "
                    "season TEXT, "
                    "episode TEXT, "
                    "hosts TEXT, "
                    "added TEXT, "
                    "UNIQUE(source, imdb_id, season, episode)"
                    ");"
                )

        except:
            pass

    def getMovieSource(self, title, localtitle, aliases, year, imdb, source, call, from_cache=False):
        #log(f' {source=!r} {call=!r} ')
        try:
            dbcon = database.connect(self.sourceFile)
            dbcur = dbcon.cursor()
        except Exception:
            pass

        """ Fix to stop items passed with a 0 IMDB id pulling old unrelated sources from the database. """
        if imdb == "0":
            try:
                dbcur.execute(
                    "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                    % (source, imdb, "", "")
                )
                dbcur.execute(
                    "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                    % (source, imdb, "", "")
                )
                dbcon.commit()
            except Exception:
                pass
        """ END """

        try:
            sources = []
            dbcur.execute(
                "SELECT * FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                % (source, imdb, "", "")
            )
            match = dbcur.fetchone()
            t1 = int(re.sub("[^0-9]", "", str(match[5])))
            t2 = int(datetime.datetime.now().strftime("%Y%m%d%H%M"))
            update = abs(t2 - t1) > 60
            if not update:
                sources = eval(match[4].encode("utf-8"))
                return self.sources.extend(sources)
        except Exception:
            pass

        try:
            url = None
            dbcur.execute(
                "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                % (source, imdb, "", "")
            )
            url = dbcur.fetchone()
            url = eval(url[4].encode("utf-8"))
        except Exception:
            pass

        try:
            if url is None and not from_cache:
                url = call.movie(imdb, title, localtitle, aliases, year)
            if url is None and from_cache:
                results_cache = cache.cache_get(f'{source}_results')
                if results_cache:  # może w ogóle nie być
                    results_cache = literal_eval(results_cache['value'])
                    if results_cache:  # może być pusty
                        url = [results_cache[k] for k in results_cache][0]
                        log(f'dla {source} odczytano z cache rekordów: {len(url)}')
            if url is None:
                raise Exception()
            dbcur.execute(
                "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                % (source, imdb, "", "")
            )
            dbcur.execute(
                "INSERT INTO rel_url Values (?, ?, ?, ?, ?)",
                (source, imdb, "", "", repr(url)),
            )
            dbcon.commit()
        except Exception:
            pass

        try:
            sources = call.sources(url, self.hostDict, self.hostprDict)
            if sources is None or sources == []:
                raise Exception()
            sources = [
                json.loads(t)
                for t in set(json.dumps(d, sort_keys=True) for d in sources)
            ]
            for i in sources:
                i.update({"provider": source})
            self.sources.extend(sources)
            dbcur.execute(
                "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                % (source, imdb, "", "")
            )
            dbcur.execute(
                "INSERT INTO rel_src Values (?, ?, ?, ?, ?, ?)",
                (
                    source,
                    imdb,
                    "",
                    "",
                    repr(sources),
                    datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                ),
            )
            dbcon.commit()
        except Exception:
            pass

    def getEpisodeSource(
            self,
            title,
            year,
            imdb,
            tvdb,
            season,
            episode,
            tvshowtitle,
            localtvshowtitle,
            aliases,
            premiered,
            source,
            call,
            from_cache=False
    ):
        try:
            dbcon = database.connect(self.sourceFile)
            dbcur = dbcon.cursor()
        except Exception:
            pass

        try:
            sources = []
            dbcur.execute(
                "SELECT * FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                % (source, imdb, season, episode)
            )
            match = dbcur.fetchone()
            t1 = int(re.sub("[^0-9]", "", str(match[5])))
            t2 = int(datetime.datetime.now().strftime("%Y%m%d%H%M"))
            update = abs(t2 - t1) > 60
            if not update:
                sources = eval(match[4].encode("utf-8"))
                return self.sources.extend(sources)
        except Exception:
            pass

        try:
            url = None
            dbcur.execute(
                "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                % (source, imdb, "", "")
            )
            url = dbcur.fetchone()
            url = eval(url[4].encode("utf-8"))
        except Exception:
            pass

        try:
            if url is None and not from_cache:
                url = call.tvshow(
                    imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year
                )
            if url is None and from_cache:
                results_cache = cache.cache_get(f'{source}_results')
                if results_cache:  # może w ogóle nie być
                    results_cache = literal_eval(results_cache['value'])
                    if results_cache:  # może być pusty
                        url = [results_cache[k] for k in results_cache][0]
                        log(f'dla {source} odczytano z cache rekordów: {len(url)}')
            if url is None:
                raise Exception()
            dbcur.execute(
                "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                % (source, imdb, "", "")
            )
            dbcur.execute(
                "INSERT INTO rel_url Values (?, ?, ?, ?, ?)",
                (source, imdb, "", "", repr(url)),
            )
            dbcon.commit()
        except Exception:
            pass

        try:
            ep_url = None
            dbcur.execute(
                "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                % (source, imdb, season, episode)
            )
            ep_url = dbcur.fetchone()
            ep_url = eval(ep_url[4].encode("utf-8"))
        except Exception:
            pass

        try:
            if url is None:
                raise Exception()
            if ep_url is None and not from_cache:
                ep_url = call.episode(
                    url, imdb, tvdb, title, premiered, season, episode
                )
            if url is None and from_cache:
                results_cache = cache.cache_get(f'{source}_results')
                if results_cache:  # może w ogóle nie być
                    results_cache = literal_eval(results_cache['value'])
                    if results_cache:  # może być pusty
                        url = [results_cache[k] for k in results_cache][0]
                        log(f'dla {source} odczytano z cache rekordów: {len(url)}')
            if ep_url is None:
                raise Exception()
            dbcur.execute(
                "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                % (source, imdb, season, episode)
            )
            dbcur.execute(
                "INSERT INTO rel_url Values (?, ?, ?, ?, ?)",
                (source, imdb, season, episode, repr(ep_url)),
            )
            dbcon.commit()
        except Exception:
            pass

        try:
            sources = []
            sources = call.sources(ep_url, self.hostDict, self.hostprDict)
            if sources is None or sources == []:
                raise Exception()
            sources = [
                json.loads(t)
                for t in set(json.dumps(d, sort_keys=True) for d in sources)
            ]
            for i in sources:
                i.update({"provider": source})
            self.sources.extend(sources)
            dbcur.execute(
                "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                % (source, imdb, season, episode)
            )
            dbcur.execute(
                "INSERT INTO rel_src Values (?, ?, ?, ?, ?, ?)",
                (
                    source,
                    imdb,
                    season,
                    episode,
                    repr(sources),
                    datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                ),
            )
            dbcon.commit()
        except Exception:
            pass

    def alterSources(self, url, meta):
        try:
            if control.setting("hosts.mode") == "2":
                url += "&select=1"
            else:
                url += "&select=2"
            control.execute("RunPlugin(%s)" % url)
        except Exception:
            pass

    def clearSources(self):
        try:
            #
            yes = control.yesnoDialog(control.lang(32407))
            if not yes:
                return

            control.makeFile(control.dataPath)
            dbcon = database.connect(control.providercacheFile)
            dbcur = dbcon.cursor()
            dbcur.execute("DROP TABLE IF EXISTS rel_src")
            dbcur.execute("DROP TABLE IF EXISTS rel_url")
            dbcur.execute("VACUUM")
            dbcon.commit()

            control.infoDialog(
                control.lang(32408).encode("utf-8"), sound=True, icon="INFO"
            )
        except Exception:
            pass

    def sourcesFilter(self):
        sort_source = "true"
        if control.setting("filter.duplicates") == "true":
            self.sources = self.filter_duplicates()

        debrid_only = control.setting("debrid.only")
        if debrid_only == "":
            debrid_only = "false"
        quality = control.setting("hosts.quality")
        if quality == "":
            quality = "0"

        captcha = control.setting("hosts.captcha")
        if captcha == "":
            captcha = "true"

        HEVC = control.setting("HEVC")

        random.shuffle(self.sources)

        for i in self.sources:
            if "checkquality" in i and i["checkquality"]:
                if not i["source"].lower() in self.hosthqDict and i["quality"] not in [
                    "SD",
                    "SCR",
                    "CAM",
                ]:
                    i.update({"quality": "SD"})

        local = [i for i in self.sources if "local" in i and i["local"]]
        for i in local:
            i.update({"language": self._getPrimaryLang() or "en"})
        self.sources = [i for i in self.sources if i not in local]

        filter = []
        filter += [i for i in self.sources if i["direct"]]
        filter += [i for i in self.sources if not i["direct"]]
        self.sources = filter

        filter = []

        for d in debrid.debrid_resolvers:
            valid_hoster = set([i["source"] for i in self.sources])
            valid_hoster = [i for i in valid_hoster if d.valid_url("", i)]
            filter += [
                dict(list(i.items()) + [("debrid", d.name)])
                for i in self.sources
                if i["source"] in valid_hoster
            ]
        if debrid_only == "false" or not debrid.status():
            filter += [
                i
                for i in self.sources
                if not i["source"].lower() in self.hostprDict and not i["debridonly"]
            ]

        self.sources = filter

        for i in range(len(self.sources)):
            q = self.sources[i]["quality"]
            if q == "HD":
                self.sources[i].update({"quality": "720p"})

        filter = []
        filter += local

        if quality in ["0"]:
            filter += [
                i for i in self.sources if i["quality"] == "4K" and "debrid" in i
            ]
        if quality in ["0"]:
            filter += [
                i
                for i in self.sources
                if i["quality"] == "4K" and "debrid" not in i and "memberonly" in i
            ]
        if quality in ["0"]:
            filter += [
                i
                for i in self.sources
                if i["quality"] == "4K" and "debrid" not in i and "memberonly" not in i
            ]

        if quality in ["0", "1"]:
            filter += [
                i for i in self.sources if i["quality"] == "1440p" and "debrid" in i
            ]
        if quality in ["0", "1"]:
            filter += [
                i
                for i in self.sources
                if i["quality"] == "1440p" and "debrid" not in i and "memberonly" in i
            ]
        if quality in ["0", "1"]:
            filter += [
                i
                for i in self.sources
                if i["quality"] == "1440p" and "debrid" not in i and "memberonly" not in i
            ]

        if quality in ["0", "1", "2"]:
            filter += [
                i for i in self.sources if (i["quality"] == "1080p" or i["quality"] == "1080i") and "debrid" in i
            ]
        if quality in ["0", "1", "2"]:
            filter += [
                i
                for i in self.sources
                if (i["quality"] == "1080p" or i["quality"] == "1080i") and "debrid" not in i and "memberonly" in i
            ]
        if quality in ["0", "1", "2"]:
            filter += [
                i
                for i in self.sources
                if (i["quality"] == "1080p" or i["quality"] == "1080i") and "debrid" not in i and "memberonly" not in i
            ]

        if quality in ["0", "1", "2", "3"]:
            filter += [
                i for i in self.sources if i["quality"] == "720p" and "debrid" in i
            ]
        if quality in ["0", "1", "2", "3"]:
            filter += [
                i
                for i in self.sources
                if i["quality"] == "720p" and "debrid" not in i and "memberonly" in i
            ]
        if quality in ["0", "1", "2", "3"]:
            filter += [
                i
                for i in self.sources
                if i["quality"] == "720p" and "debrid" not in i and "memberonly" not in i
            ]

        filter += [i for i in self.sources if i["quality"] in ["SD", "SCR", "CAM"]]

        self.sources = filter

        if not captcha == "true":
            filter = [
                i
                for i in self.sources
                if i["source"].lower() in self.hostcapDict and "debrid" not in i
            ]
            self.sources = [i for i in self.sources if i not in filter]

        filter = [
            i
            for i in self.sources
            if i["source"].lower() in self.hostblockDict and "debrid" not in i
        ]
        self.sources = [i for i in self.sources if i not in filter]

        multi = [i["language"] for i in self.sources]
        multi = [x for y, x in enumerate(multi) if x not in multi[:y]]
        multi = True if len(multi) > 1 else False

        if multi:
            self.sources = [i for i in self.sources if not i["language"] == "en"] + [
                i for i in self.sources if i["language"] == "en"
            ]

        self.sources = self.sources[:2000]
        extra_info = control.setting("sources.extrainfo")
        prem_identify = source_utils.getPremColor()
        # muszą być wszystkie pozycje, które zwraca source_utils.check_sd_url() i które zostały "zassane"
        # przez zmienną filter
        my_quality_order = ["4K", "1440p", "1080p", "1080i", "720p", "SD", "SCR", "CAM"]
        quality_order = {key: i for i, key in enumerate(my_quality_order)}
        my_language_order = ["pl", "mul", "multi", "en", "de", "fr", "it", "es", "pt", "ko", "ru", '-', '']  # muszą być wszystkie możliwości wypisane, jakie chcemy obsługiwać
        language_order = {key: i for i, key in enumerate(my_language_order)}
        my_provider_order = ["1", "2", "3", "4", "5", "cdapremium", "nopremium", "rapideo", "tb7", "twojlimit", "xt7", "0", ""]
        provider_order = {key: i for i, key in enumerate(my_provider_order)}

        sort_source = control.setting("hosts.sort")
        sort_source = str(sort_source)
        if sort_source == "0":
            log("Sortuję według dostawców")  # by providers
            self.sources = sorted(
                self.sources,
                key=lambda d: (
                    not d["provider"].startswith("pobrane"),
                    not d["provider"].startswith("library"),
                    not d["provider"].startswith("plex"),
                    not d["provider"].startswith("external"),
                    not d["on_account"] if "on_account" in d else 1,
                    #not d["provider"].startswith("cdapremium"),
                    #not d["provider"].startswith("nopremium"),
                    #not d["provider"].startswith("rapideo") if not control.setting("rapideo.sort.order") else True,
                    #not d["provider"].startswith("tb7") if not control.setting("tb7.sort.order") else True,
                    #not d["provider"].startswith("twojlimit"),
                    #not d["provider"].startswith("xt7"),
                    provider_order[(control.setting(d["provider"]+".sort.order") if control.setting(d["provider"]+".sort.order") and control.setting(d["provider"]+".sort.order") != "o" else d["provider"] if d["provider"] in my_provider_order else "")],
                    language_order[d["language"]],
                    quality_order[d["quality"]],
                    d["provider"],  # provider (serwis internetowy www)
                    source_utils.convert_size_to_bytes( d["size"] if "size" in d  else  d["info"].rsplit('|')[-1] if "info" in d and d["info"]  else '')*-1,
                ),
            )
        if sort_source == "1":
            log("Sortuję według źródeł (hostingów)")  # by sources (hosting, server)
            self.sources = sorted(
                self.sources,
                key=lambda d: (
                    not d["provider"].startswith("pobrane"),
                    not d["provider"].startswith("library"),
                    not d["provider"].startswith("plex"),
                    not d["provider"].startswith("external"),
                    not d["on_account"] if "on_account" in d else 1,
                    #not d["provider"].startswith("cdapremium"),
                    #not d["provider"].startswith("nopremium"),
                    #not d["provider"].startswith("rapideo"),
                    #not d["provider"].startswith("tb7"),
                    #not d["provider"].startswith("twojlimit"),
                    #not d["provider"].startswith("xt7"),
                    provider_order[(control.setting(d["provider"]+".sort.order") if control.setting(d["provider"]+".sort.order") and control.setting(d["provider"]+".sort.order") != "o" else d["provider"] if d["provider"] in my_provider_order else "")],
                    language_order[d["language"]],
                    quality_order[d["quality"]],
                    d["source"],  # source (serwer, hosting)
                    source_utils.convert_size_to_bytes( d["size"] if "size" in d  else  d["info"].rsplit('|')[-1] if "info" in d and d["info"]  else '')*-1,
                ),
            )
        if sort_source == "2":
            log("Sortuję według rozmiaru")  # by size
            self.sources = sorted(
                self.sources,
                key=lambda d: (
                    not d["provider"].startswith("pobrane"),
                    not d["provider"].startswith("library"),
                    not d["provider"].startswith("plex"),
                    not d["provider"].startswith("external"),
                    not d["on_account"] if "on_account" in d else 1,
                    provider_order[(control.setting(d["provider"]+".sort.order") if control.setting(d["provider"]+".sort.order") and control.setting(d["provider"]+".sort.order") != "o" else d["provider"] if d["provider"] in my_provider_order else "")],
                    # language_order[d["language"]],
                    # quality_order[d["quality"]],
                    # d["provider"],  # provider (serwis internetowy www)
                    # d["source"],  # source (serwer, hosting)
                    source_utils.convert_size_to_bytes( d["size"] if "size" in d  else  d["info"].rsplit('|')[-1] if "info" in d and d["info"]  else '')*-1,
                ),
            )
                
        for i in range(len(self.sources)):
            if extra_info == "true":
                try:
                    url2 = self.sources[i]["url"].rstrip("/").split("/")[-1]
                    url2 = url2.rstrip("\\").split("\\")[-1]  # dla plików z własnej biblioteki na dysku lokalnym
                    # log(f' {[i]} {url2=!r}')
                    url2 = re.sub(r"(\.(html?|php))+$", "", url2, flags=re.I)  # na przypadki typu "filmik.mkv.htm"
                    exts = ("avi", "mkv", "mp4", ".ts", "mpg")  # dozwolone rozszerzenia filmów
                    if url2.lower()[-3:] not in exts:


                        if "filename" in self.sources[i] and self.sources[i]["filename"]:
                            url2 = self.sources[i]["filename"]
                        else:
                            # próba pozyskanie nazwy z 2-giej linijki lub opisu
                            if "info2" in self.sources[i] and self.sources[i]["info2"] and self.sources[i]["info2"].lower()[-3:] in exts:
                                url2 = self.sources[i]["info2"]
                            else:
                                """
                                # to raczej nie będzie już wykorzystywane, bo okazało się, że info może mieć juz swoje oznaczenia, więc mogą się dublować
                                url2 = self.sources[i]["info"] if self.sources[i]["info"] else ''
                                # próba odfiltrowania nazwy
                                url2 = url2.split("|")[-1].strip().lstrip("(").rstrip(")")
                                """
                                url2 = ""

                    url2 = unquote(url2)  # zamiana takich tworów jak %nn (np. %21 to nawias)
                    url2 = unescape(url2)  # pozbycie się encji html-owych

                    t = PTN.parse(url2)  # proces rozpoznawania

                    t3d = t["3d"] if "3d" in t else ''  # zapamiętanie informacji pod inną zmienną czy wersja 3D
                    textended = t["extended"] if "extended" in t else ''  # informacja o wersji rozszerzonej
                    tremastered = t["remastered"] if "remastered" in t else ''  # informacja o wersji zremasterowanej

                    # poniżej korekty wizualne
                    if "audio" in t:
                        t["audio"] = re.sub(r"(?<!\d)([57]\.[124](?:\.[24])?)\.(ATMOS)\b", r"\1 \2", t["audio"],
                                            flags=re.I)
                        t["audio"] = re.sub(r"(?<=[DSPXAC3M])[.-]?([57261]\.[102])\b", r" \1", t["audio"], flags=re.I)
                        # rstrip ze względu na możliwośc powstania nadmiarowej spacji
                        t["audio"] = re.sub(r"\b(DTS)[.-]?(HD|ES|EX|X(?!26))[. ]?(MA)?", r"\1-\2 \3", t["audio"],
                                            flags=re.I).rstrip()
                        t["audio"] = re.sub(r"(TRUEHD|DDP)\.(ATMOS)\b", r"\1 \2", t["audio"], flags=re.I)
                        t["audio"] = re.sub(r"(custom|dual)\.(audio)", r"\1 \2", t["audio"], flags=re.I)
                        t["audio"] = re.sub("ddp(?!l)", "DD+", t["audio"], flags=re.I)
                    if "codec" in t:
                        t["codec"] = re.sub(r"(\d{2,3})(fps)", r"\1 \2", t["codec"], flags=re.I)
                        t["codec"] = re.sub("plus", "+", t["codec"], flags=re.I)  # z myślą o HDR10Plus -> HDR10+
                        t["codec"] = re.sub(r"\bDoVi\b", "DV", t["codec"], flags=re.I)
                        if "DolbyVision".lower() in t["codec"].lower():  # DolbyVision -> DV
                            if "DV".lower() in t["codec"].lower():
                                t["codec"] = re.sub(r"\s*/\s*DolbyVision", "", t["codec"], flags=re.I)
                            else:
                                t["codec"] = re.sub("DolbyVision", "DV", t["codec"], flags=re.I)
                    if "quality" in t:
                        t["quality"] = re.sub(r"\b(\w+)\.(\w+)\b", r"\1-\2", t["quality"], flags=re.I)

                    t = [t[j] for j in t if "quality" in j or "codec" in j or "audio" in j]
                    t = " | ".join(t)

                    if not t:
                        t = source_utils.getFileType(url2)  # taki fallback dla PTN.parse()
                        t = t.strip()

                    """
                    # pozbycie się tych samych oznaczeń ze zmiennej info
                    if t:
                        self.sources[i]["info"] = re.sub(fr'(\b|[ ._|/]+)({"|".join(t.split(" / "))})\b', '', self.sources[i]["info"], flags=re.I)
                    """
                    
                    # dodanie dodatkowych informacji (moim zdaniem ważnych)
                    if t3d:
                        t = f"[3D] | {t}"  # informacja o wersji 3d

                    # dodatkowe oznaczenie pliku z wieloma sciezkami audio
                    if ( re.search(r"\bMULTI\b", url2, re.I)  # szukam w adresie, który powinien zawierać nazwę pliku
                         and "mul" not in self.sources[i]["language"].lower()
                         # and "PL" not in self.sources[i]["language"].upper()  # założenie, że jak wykryto język PL, to nie ma potrzeby o dodatkowym ozaczeniu
                         and "multi" not in self.sources[i]["info"].lower()  # sprawdzenie, czy przypadkiem już nie zostało przekazane przez plik źródła
                         and "multi" not in t.lower()  # sprawdzenie, czy nie ma tej frazy już w opisie
                       ):
                        t += " | MULTI"
                    if ("multi" in t.lower() or "multi" in self.sources[i]["info"].lower()) and self.sources[i]["language"] != "pl":
                        self.sources[i]["language"] = "multi"  # wymiana języka
                        t = re.sub(r'[/| ]*multi\b', '' , t, flags=re.I)  # wywalenie z opisu, aby nie było dubli
                        self.sources[i]["info"] = re.sub(r'[/| ]*multi\b', '' , self.sources[i]["info"], flags=re.I)  # wywalenie z opisu, aby nie było dubli

                    if textended:
                        if textended is True:
                            t += " | EXTENDED"
                        else:
                            textended = re.sub("(directors|alternat(?:iv)?e).(cut)", r"\1 \2", textended, flags=re.I)
                            t += f" | {textended}"

                    # długi napis i czy aż tak istotny?
                    if tremastered:
                        if tremastered is True:
                            t += " | REMASTERED"
                        else:
                            if "rekonstrukcja" not in t.lower():
                                tremastered = re.sub("(Rekonstrukcja).(cyfrowa)", r"\1 \2", tremastered, flags=re.I)
                                t += f" | {tremastered}"

                    if "imax" in url2.lower() and "imax" not in t.lower():  # sprawdzenie czy dodać info IMAX
                        t += " | [IMAX]"

                    if "avi" in url2.lower()[-3:] and "avi" not in t.lower():  # aby nie bylo zdublowań
                        t += " | AVI"  # oznaczenie tego typu pliku, bo nie zawsze dobrze odtwarza sie "w locie"

                    t = t.lstrip(" | ")  # przydaje się, jak ani PTN.parse() ani getFileType() nic nie znalazły
                    t += " "

                except Exception:
                    t = None
            else:
                t = None

            # u = self.sources[i]["url"]  -- NOT USED

            p = self.sources[i]["provider"]  # serwis, strona www
            lng = self.sources[i]["language"]
            s = self.sources[i]["source"]  # serwer
            q = self.sources[i]["quality"]  # rozdzielczość

            s = s.rsplit(".", 1)[0]  # wyrzucenie ostatniego człona domeny (np. ".pl", ".com")

            if p.lower() == "library":
                if control.setting("api.language") == "Polish":
                    p = "biblioteka"

            try:  # f to info (tu może być też rozmiar pliku na końcu)
                f = " | ".join(
                    [
                        "[I]%s [/I]" % info.strip()
                        for info in self.sources[i]["info"].split("|")
                    ]
                )
            except Exception:
                f = ""

            try:
                d = self.sources[i]["debrid"]
            except Exception:
                d = self.sources[i]["debrid"] = ""

            if d.lower() == "real-debrid":
                d = "RD"

            if not d == "":
                label = "%02d | [B]%s | %s[/B] | " % (int(i + 1), d, p)
            else:
                label = "%02d | [LIGHT][B]%s[/B][/LIGHT] | " % (int(i + 1), p)

            # oznaczenie, czy źródło jest w tzw. bibliotece danego serwisu
            if "on_account" in self.sources[i] and self.sources[i]["on_account"]:
                label += "[I]konto[/I]  | "
            
            # oznaczenie języka
            if lng:
                if (
                    multi and lng != "en"  # nie rozumiem, kiedy ten warunek zachodzi
                    or not multi and lng != "en"  # dałem ten warunek
                   ):
                    label += "[B]%s[/B] | " % lng
                """
                else:
                    if "mul" in lng or re.search(r"\bMULTI\b", t, re.I):
                        label += "[B]multi[/B] | "
                        # usunięcie z opisu, aby nie było zdublowań
                        if re.search(r"\bMULTI\b", t, re.I):
                            t = re.sub(r"\s*\bMULTI\b(\s[/|])?", "", t, flags=re.I)
                            t = re.sub(r"(\s[/|])(?=\s*$)", "", t, flags=re.I)
                """                

            if t:  # extra_info
                if q in ["4K", "1440p", "1080p", "1080i", "720p"]:
                    label += "%s | [B][I]%s [/I][/B] | [I]%s[/I] | %s" % (s, q, t, f)
                elif q == "SD":
                    # label += "%s | %s | [I]%s[/I]" % (s, f, t)
                    # moja propozycja (wielkość pliku na końcu - dla spójności)
                    label += "%s | [I]%s[/I] | %s" % (s, t, f)
                else:
                    # label += "%s | %s | [I]%s [/I] | [I]%s[/I]" % (s, f, q, t)
                    # moja propozycja (wielkość pliku na końcu - dla spójności)
                    # label += "[LIGHT]%s | [B][I]%s [/I][/B] | [I]%s[/I] | %s[/LIGHT]" % (s, q, t, f)
                    label += "[LIGHT]%s | [I]%s[/I] | %s[/LIGHT]" % (s, t, f)
            else:
                if q in ["4K", "1440p", "1080p", "1080i", "720p"]:
                    label += "%s | [B][I]%s [/I][/B] | %s" % (s, q, f)
                elif q == "SD":
                    label += "%s | %s" % (s, f)
                else:
                    # label += "%s | %s | [I]%s [/I]" % (s, f, q)
                    # moja propozycja (wielkość pliku na końcu - dla spójności)
                    # label += "[LIGHT]%s | [B][I]%s [/I][/B] | %s[/LIGHT]" % (s, q, f)
                    label += "[LIGHT]%s | %s[/LIGHT]" % (s, f)

            # korekty wizualne
            label = label.replace("| 0 |", "|").replace(" | [I]0 [/I]", "")
            label = re.sub(r"\[I\]\s+\[/I\]", " ", label)
            label = re.sub(r"\|\s+\|", "|", label)
            label = re.sub(r"\|\s+\|", "|", label)  # w pewnych okolicznościach ponowne wykonanie takiej samej linijki kodu jak wyżej pomaga
            label = re.sub(r"\|(?:\s+|)$", "", label)
            label = re.sub(r"(\d+(?:[.,]\d+)?\s*[GMK]B)", r"[B]\1[/B]", label, flags=re.I)  # wyróżnienie rozmiaru pliku
            label = re.sub(r"(?<=\d)\s+(?=[GMK]B\b)", "\u00A0", label, flags=re.I)  # aby nie rodzielal cyfr od jednostek
            # aby np. 1080i było bardziej widoczne
            # label = re.sub(r"\s?((\[\w\])*(?:1080|720|1440)[pi])\s?", r"[LOWERCASE]\1[/LOWERCASE]", label,flags=re.I)
            label = re.sub("((?:1080|720|1440)[pi])", r"[LOWERCASE]\1[/LOWERCASE]", label, flags=re.I)

            # prem coloring
            # if ((d or p.lower() == "tb7") or (d or p.lower() == "xt7") or (d or p.lower() == "pobrane")
            #         or (d or p.lower() == "external")):
            if (
                    (d or p.lower() == "pobrane")
                    or (d or p.lower() == "external")
                    or (d or p.lower() == "plex")
                    or (d or p.lower() == "rapideo")
                    or (d or p.lower() == "twojlimit")
                    or (d or p.lower() == "nopremium")
                    or (d or p.lower() == "tb7")
                    or (d or p.lower() == "xt7")
                    or (d or p.lower() == "cdapremium")
                    # or (d or p.lower() == "library")  # czy nie powinno być tu też?
            ):
                
                clib = control.setting(f"{p.lower()}.library.color.identify")
                clib = int(clib) if clib else 10
                if clib < 10 and "on_account" in self.sources[i] and self.sources[i]["on_account"]:
                    color = source_utils.getPremColor(str(clib))
                    self.sources[i]["label"] = f'[COLOR {color}]{label.upper()}[/COLOR]'
                else:
                    cp = control.setting(f"{p.lower()}.color.identify")
                    cp = int(cp) if cp else 10
                    if cp < 10:
                        color = source_utils.getPremColor(str(cp))
                        self.sources[i]["label"] = f'[COLOR {color}]{label.upper()}[/COLOR]'
                    elif not prem_identify == "nocolor":
                        self.sources[i]["label"] = (
                                ("[COLOR %s]" % prem_identify) + label.upper() + "[/COLOR]"
                        )
                    else:
                        self.sources[i]["label"] = label.upper()
            else:
                self.sources[i]["label"] = label.upper()

            if control.setting("sources.filename_in_2nd_line") == "true" and "info2" not in self.sources[i]:
                if 'url2' in locals() and url2.lower()[-3:] in exts:  # zmienna 'exts' jest definiowana po 'url2'
                    self.sources[i]["info2"] = url2
                if "filename" in self.sources[i] and self.sources[i]["filename"]:
                    self.sources[i]["info2"] = self.sources[i]["filename"]
            
            if "info2" in self.sources[i] and self.sources[i]["info2"]:
                self.sources[i]["info2"] = unescape(unquote(self.sources[i]["info2"]))  # mam nadzieję, kolejność odkodowywania nie ma znaczenia
                self.sources[i]["label"] += '[LIGHT][CR]  ' + self.sources[i]["info2"] + '[/LIGHT]'

        try:
            if not HEVC == "true":
                self.sources = [
                    i
                    for i in self.sources
                    if "HEVC" not in i["label"] or "265" not in i["label"]
                ]
        except Exception:
            pass

        self.sources = [i for i in self.sources if "label" in i]
        return self.sources

    def filter_duplicates(self):
        filter = []
        append = filter.append
        remove = filter.remove
        for i in self.sources:
            larger = False
            a = i["url"].lower()
            for sublist in filter:
                try:
                    if i["source"] == "cloud":
                        break
                    b = sublist["url"].lower()
                    if "magnet:" in a:
                        if i["hash"].lower() in b:
                            if len(sublist["name"]) > len(
                                    i["name"]
                            ):  # keep matching hash with longer name, possible more file info.
                                larger = True
                                break
                            remove(sublist)
                            break
                    elif a == b:
                        remove(sublist)
                        break
                except Exception:
                    pass
            if not larger:  # sublist['name'] len() was larger so do not append
                append(i)

        log_utils.log(
            "Removed %s duplicate sources from list"
            % (len(self.sources) - len(filter)),
            "module",
        )
        return filter

    def sourcesResolve(self, item, info=False):
        try:
            self.url = None

            u = url = item["url"]

            d = item["debrid"]
            direct = item["direct"]
            local = item.get("local", False)

            provider = item["provider"]
            call = [i[1] for i in self.sourceDict if i[0] == provider][0]
            u = url = call.resolve(url)

            if url is None or (not "://" in str(url) and not local):
                # if provider == 'netflix':
                #    return url
                # if provider == 'external':
                #    return url

                raise Exception()

            if not local:
                url = url[8:] if url.startswith("stack:") else url

                urls = []
                for part in url.split(" , "):
                    u = part
                    if not d == "":
                        part = debrid.resolver(part, d)

                    elif not direct:
                        hmf = resolveurl.HostedMediaFile(
                            url=u, include_disabled=True, include_universal=False
                        )
                        if hmf.valid_url():
                            part = hmf.resolve()
                    urls.append(part)

                url = "stack://" + " , ".join(urls) if len(urls) > 1 else urls[0]

            if not url:
                raise Exception()

            ext = (
                url.split("?")[0]
                .split("&")[0]
                .split("|")[0]
                .rsplit(".")[-1]
                .replace("/", "")
                .lower()
            )
            if ext == "rar":
                raise Exception()

            try:
                headers = url.rsplit("|", 1)[1]
            except Exception:
                headers = ""
            headers = (
                quote_plus(headers).replace("%3D", "=")
                if " " in headers
                else headers
            )
            headers = dict(parse_qsl(headers))

            if url.startswith("http") and ".m3u8" in url:
                result = client.request(
                    url.split("|")[0], headers=headers, output="geturl", timeout="20"
                )
                if result is None:
                    raise Exception()

            elif url.startswith("http"):
                self.url = url
                return url

            self.url = url
            return url
        except Exception as e:
            print(e)
            if info:
                self.errorForSources()
            return

    def sourcesDialog(self, items):
        try:
            labels = [i["label"] for i in items]

            select = control.selectDialog(labels)
            if select == -1:
                return "close://"

            next = [y for x, y in enumerate(items) if x >= select]
            prev = [y for x, y in enumerate(items) if x < select][::-1]

            items = [items[select]]
            items = [i for i in items + next + prev][:40]

            header = control.addonInfo("name")
            header2 = header.upper()

            progressDialog = (
                control.progressDialog
                if control.setting("progress.dialog") == "0"
                else control.progressDialogBG
            )
            progressDialog.create(header, "")
            progressDialog.update(0)

            block = None
            import threading

            for i in range(len(items)):
                try:
                    if items[i]["source"] == block:
                        raise Exception()

                    w = threading.Thread(target=self.sourcesResolve, args=(items[i],))
                    w.start()

                    try:
                        if progressDialog.iscanceled():
                            break
                        progressDialog.update(
                            int((100 / float(len(items))) * i),
                            str(items[i]["label"]) + "\n" + str(" "),
                        )
                    except Exception:
                        progressDialog.update(
                            int((100 / float(len(items))) * i),
                            str(header2) + "\n" + str(items[i]["label"]),
                        )

                    m = ""

                    for x in range(3600):
                        try:
                            if xbmc.Monitor().abortRequested():
                                return sys.exit()
                            if progressDialog.iscanceled():
                                return progressDialog.close()
                        except Exception:
                            pass

                        k = control.condVisibility("Window.IsActive(virtualkeyboard)")
                        if k:
                            m += "1"
                            m = m[-1]
                        if (not w.is_alive() or x > 30) and not k:
                            break
                        k = control.condVisibility("Window.IsActive(yesnoDialog)")
                        if k:
                            m += "1"
                            m = m[-1]
                        if (not w.is_alive() or x > 30) and not k:
                            break
                        time.sleep(0.5)

                    for x in range(30):
                        try:
                            if xbmc.Monitor().abortRequested():
                                return sys.exit()
                            if progressDialog.iscanceled():
                                return progressDialog.close()
                        except Exception:
                            pass

                        if m == "":
                            break
                        if not w.is_alive():
                            break
                        time.sleep(0.5)

                    if w.is_alive():
                        block = items[i]["source"]

                    if self.url is None:
                        raise Exception()

                    self.selectedSource = items[i]["label"]

                    try:
                        progressDialog.close()
                    except Exception:
                        pass

                    control.execute("Dialog.Close(virtualkeyboard)")
                    control.execute("Dialog.Close(yesnoDialog)")
                    return self.url
                except Exception:
                    pass

            try:
                progressDialog.close()
            except Exception:
                pass

        except Exception as e:
            try:
                progressDialog.close()
            except Exception:
                pass
            print("Error %s" % str(e), log_utils.LOGINFO)

    def sourcesDirect(self, items):
        filter = [
            i
            for i in items
            if i["source"].lower() in self.hostcapDict and i["debrid"] == ""
        ]
        items = [i for i in items if i not in filter]

        filter = [
            i
            for i in items
            if i["source"].lower() in self.hostblockDict and i["debrid"] == ""
        ]
        items = [i for i in items if i not in filter]

        items = [
            i
            for i in items
            if ("autoplay" in i and i["autoplay"]) or "autoplay" not in i
        ]

        if control.setting("autoplay.sd") == "true":
            items = [
                i for i in items if not i["quality"] in ["4K", "1440p", "1080p", "1080i", "HD"]
            ]

        u = None

        header = control.addonInfo("name")
        header2 = header.upper()

        try:
            control.sleep(1000)

            progressDialog = (
                control.progressDialog
                if control.setting("progress.dialog") == "0"
                else control.progressDialogBG
            )
            progressDialog.create(header, "")
            progressDialog.update(0)
        except Exception:
            pass

        for i in range(len(items)):
            try:
                if progressDialog.iscanceled():
                    break
                progressDialog.update(
                    int((100 / float(len(items))) * i),
                    str(items[i]["label"]) + "\n" + str(" "),
                )
            except Exception:
                progressDialog.update(
                    int((100 / float(len(items))) * i),
                    str(header2) + "\n" + str(items[i]["label"]),
                )

            try:
                if xbmc.Monitor().abortRequested():
                    return sys.exit()

                url = self.sourcesResolve(items[i])
                if u is None:
                    u = url
                else:
                    break
            except Exception:
                pass

        try:
            progressDialog.close()
        except Exception:
            pass

        return u

    def errorForSources(self):
        control.infoDialog(
            control.lang(32401).encode("utf-8"), sound=False, icon="INFO"
        )

    def getLanguage(self):
        langDict = {
            "English": ["en"],
            "German": ["de"],
            "German+English": ["de", "en"],
            "French": ["fr"],
            "French+English": ["fr", "en"],
            "Portuguese": ["pt"],
            "Portuguese+English": ["pt", "en"],
            "Polish": ["pl"],
            "Polish+English": ["pl", "en"],
            "Korean": ["ko"],
            "Korean+English": ["ko", "en"],
            "Russian": ["ru"],
            "Russian+English": ["ru", "en"],
            "Spanish": ["es"],
            "Spanish+English": ["es", "en"],
            "Greek": ["gr"],
            "Italian": ["it"],
            "Italian+English": ["it", "en"],
            "Greek+English": ["gr", "en"],
        }
        name = control.setting("providers.lang")
        return langDict.get(name, ["pl"])

    def getLocalTitle(self, title, imdb, tvdb, content):
        lang = self._getPrimaryLang()
        if not lang:
            return title

        if content == "movie":
            t = trakt.getMovieTranslation(imdb, lang)
        else:
            t = trakt.getTVShowTranslation(imdb, lang)

        return t or title

    def getAliasTitles(self, imdb, localtitle, content):
        lang = self._getPrimaryLang()

        try:
            t = (
                trakt.getMovieAliases(imdb)
                if content == "movie"
                else trakt.getTVShowAliases(imdb)
            )
            t = [
                i
                for i in t
                if (i.get("country", "").lower() in [lang, "", "us"]
                    and i.get("title", "").lower() != localtitle.lower())
            ]
            return t
        except Exception:
            return []

    def _getPrimaryLang(self):
        langDict = {
            "English": "en",
            "German": "de",
            "German+English": "de",
            "French": "fr",
            "French+English": "fr",
            "Portuguese": "pt",
            "Portuguese+English": "pt",
            "Polish": "pl",
            "Polish+English": "pl",
            "Korean": "ko",
            "Korean+English": "ko",
            "Russian": "ru",
            "Russian+English": "ru",
            "Spanish": "es",
            "Spanish+English": "es",
            "Italian": "it",
            "Italian+English": "it",
            "Greek": "gr",
            "Greek+English": "gr",
        }
        name = control.setting("providers.lang")
        lang = langDict.get(name)
        return lang

    def getTitle(self, title):
        title = cleantitle.normalize(title)
        return title

    def getConstants(self):
        self.itemProperty = "plugin.video.fanfilm.container.items"

        self.metaProperty = "plugin.video.fanfilm.container.meta"

        from resources.lib.sources import sources

        self.sourceDict = sources()

        try:
            self.hostDict = resolveurl.relevant_resolvers(order_matters=True)
            self.hostDict = [i.domains for i in self.hostDict if "*" not in i.domains]
            self.hostDict = [
                i.lower() for i in reduce(lambda x, y: x + y, self.hostDict)
            ]
            self.hostDict = [
                x for y, x in enumerate(self.hostDict) if x not in self.hostDict[:y]
            ]
        except Exception:
            self.hostDict = []

        self.hostprDict = [
            "1fichier.com",
            "oboom.com",
            "rapidgator.net",
            "rg.to",
            "uploaded.net",
            "uploaded.to",
            "ul.to",
            "filefactory.com",
            "nitroflare.com",
            "turbobit.net",
            "uploadrocket.net",
        ]

        self.hostcapDict = [
            "hugefiles.net",
            "kingfiles.net",
            "openload",
            "openload.io",
            "openload.co",
            "oload.tv",
            "thevideo.me",
            "vidup.me",
            "streamin.to",
            "torba.se",
            "flashx",
            "flashx.tv",
        ]

        self.hosthqDict = [
            "gvideo",
            "google.com",
            "openload.io",
            "openload.co",
            "oload.tv",
            "thevideo.me",
            "rapidvideo.com",
            "raptu.com",
            "filez.tv",
            "uptobox.com",
            "uptobox.com",
            "uptostream.com",
            "xvidstage.com",
            "streamango.com",
        ]

        self.hostblockDict = []

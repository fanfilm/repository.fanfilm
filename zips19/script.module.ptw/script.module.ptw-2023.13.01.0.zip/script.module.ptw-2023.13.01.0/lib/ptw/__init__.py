# Force patching Kodi API
from kover import autoinstall  # noqa: F401
# Basic logging.
from .libraries.log_utils import log  # noqa: F401

import sys
PY2 = sys.version_info < (3, 0)

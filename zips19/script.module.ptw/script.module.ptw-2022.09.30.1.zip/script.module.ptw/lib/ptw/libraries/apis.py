import base64, codecs
magic = 'dG1kYl9BUEkgPSAnNDQ4YzFiYjQzNTkwNmM0MDJjM2MxZTAzZjkyMzE5OTInCnR2ZGJfQVBJID0gJ0pNQ084TFFISVhYNzZDR04nCmZhbmFydHR2X0FQ'
love = 'FI9eMKxtCFNaBJL4AQMyA2IwZJIuBGEzLJD1MQuuAQZkMQSxZwMvAQZaPzMuozSlqUE2K2AfnJIhqS9eMKxtCFNaL2LjMJWwLmWzA2V4ZwEvMQN0L2Lm'
god = 'YTMxOGYxNWMxN2QnCnRyYWt0X0FQSSA9ICdjY2I0ZmJmMDQ0N2Q4NmVkZjMwZjcxY2FmOGY2YThjMjY4ZThkNDAxNGY4NGU1MzY3NDZiNjk3NTI0MDdi'
destiny = 'MzD1Wjc0pzSeqS9mMJAlMKDtCFNaMJD3L2MzAzVjLmL4Awp4BJLkZQSwBGSuAGpmZ2D1LwAyAGRlZzWuMzDkZmV4MwZkMTWxAQDjMQMzLwIzATAvMvp='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))
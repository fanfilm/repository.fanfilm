import base64, codecs
magic = 'dG1kYl9BUEkgPSAnOTY2MDY5NzQ2MDFiMjU2MTgwMDc5MTdiYjAxYTBmNWYnDQp0dmRiX0FQSSA9ICdKTUNPOExRSElYWDc2Q0dOJw0KZmFuYXJ0dHZfQV'
love = 'OWK2gyrFN9VPp5Mwt0AzH3MJZkMJR5ATMuMQIxBTR0ZmSxZJDlAzV0ZlpAPzMuozSlqUE2K2AfnJIhqS9eMKxtCFNaL2LjMJWwLmWzA2V4ZwEvMQN0L2Lm'
god = 'YTMxOGYxNWMxN2QnDQp0cmFrdF9BUEkgPSAnY2NiNGZiZjA0NDdkODZlZGYzMGY3MWNhZjhmNmE4YzI2OGU4ZDQwMTRmODRlNTM2NzQ2YjY5NzUyNDA3Ym'
destiny = 'MxAFpAPaElLJg0K3AyL3WyqPN9VPqyMQqwMzL2LwOwAwt2Amt5MwRjZJZ5ZJR1AmZmMQIvZ2H1ZGVlLzSzMQRmZwuzZmSxLzD0AQOxAzMvAJL0L2WzWj0X'
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))
#!/usr/bin/env python
# -*- coding: utf-8 -*-

patterns = [
    (
        "season",
        "[\. ]((?:Complete.)?s[0-9]{2}-s[0-9]{2}|"
        "s([0-9]{1,2})(?:e[0-9]{2})?|"
        "([0-9]{1,2})x[0-9]{2})(?:[\. ]|$)",
    ),
    
    ("episode", "((?:[ex]|ep)([0-9]{2})(?:[^0-9]|$))"),
    ("year", "([\[\(]?((?:19[0-9]|20[0-9])[0-9])[\]\)]?)"),
    ("resolution", "([0-9]{3,4}p|1280x720)"),
    
    (
        "quality",
        (
            "((?:PPV\.)?[HP]DTV|(?:HD)?CAM|B[DR]-?Rip|(?<!D)(?:HD-?)?TS|tsrip|"
            "(?:PPV )?WEB-?DL(?: DVDRip)?|HDRip|HDTVRip|DVDRip|DVD-RIP|DCP-?Rip|"
            "CamRip|W[EB]BRip|Blu-?Ray|DvDScr|hdtv|telesync|telecine|screener|scr|R5)"
        ),
    ),
    
    ("codec", "(xvid|[hx]\.?26[45]|hevc|hdr10plus|hdr10|hdr|dv(?!d))" ),

    ("audio",
        "(?:DDP?(?:[-\.]?EX)?|DTS(?:[-\.]?(?:HD|ES|EX|X)(?:[\. ]MA)?)?|E?-?AC-?3|TRUEHD|atmos)(?:[\. -]?[57264]\.[10])?"
        "|MD|MP3|AAC(?:[ \.-]LC)?|Dual[\- ]Audio|LiNE|(?:custom|dual)[\. ]audio"
    ),
    
    ("group", "(- ?([^-]+(?:-={[^-]+-?$)?))$"),
    ("region", "R[0-9]"),
    ("extended", "(EXTENDED(:?.CUT)?)"),
    ("hardcoded", "HC"),
    ("proper", "PROPER"),
    ("repack", "REPACK"),
    ("container", "(MKV|MP4|AVI)"),
    ("widescreen", "WS"),
    ("website", "^(\[ ?([^\]]+?) ?\])"),
    ("language", "(rus\.eng|ita\.eng|nordic)"),
    ("subtitles", "(DKsubs)"),
    ("sbs", "(?:Half-)?SBS"),
    ("unrated", "UNRATED"),
    ("size", "(\d+(?:\.\d+)?(?:GB|MB))"),
    ("3d", "3D"),
    ("imax", "IMAX"), 
]

types = {
    "season": "integer",
    "episode": "integer",
    "year": "integer",
    "extended": "boolean",
    "hardcoded": "boolean",
    "proper": "boolean",
    "repack": "boolean",
    "widescreen": "boolean",
    "unrated": "boolean",
    "3d": "boolean",
    "imax": "boolean",
}

bt_sites = ["eztv", "ettv", "rarbg", "rartv", "ETRG"]

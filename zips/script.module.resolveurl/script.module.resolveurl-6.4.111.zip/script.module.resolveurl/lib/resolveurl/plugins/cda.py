"""
    resolveurl XBMC Addon
    Copyright (C) 2015 tknorris

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import re
import js2py
import requests
import json
from urllib import unquote

from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError

from lib import helpers


class CdaResolver(ResolveUrl):
    name = "cda"
    domains = ['m.cda.pl', 'cda.pl', 'www.cda.pl', 'ebd.cda.pl']
    pattern = r'(?:\/\/|\.)(cda\.pl)\/(?:.\d+x\d+|video)\/(.*)'

    def __init__(self):
        self.net = common.Net()

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        headers = {'Referer': web_url, 'User-Agent': common.RAND_UA}

        html = self.net.http_GET(web_url, headers=headers).content
        sources = re.findall('data-quality.+?href="(?P<url>[^"]+).+?>(?P<label>[^<]+)', html)
        match = re.search(r"player_data='([^']+)", html)
        if sources:
            sources = [(source[1], source[0]) for source in sources]
            return self.cda_decode2(helpers.pick_source(helpers.sort_sources_list(sources)))
            html = self.net.http_GET(helpers.pick_source(helpers.sort_sources_list(sources)), headers=headers).content
            match = re.search(r"player_data='([^']+)", html)
            if match:
                js_data = json.loads(match.group(1))
                return self.cda_decode(js_data.get('video').get('file')) + helpers.append_headers(headers)
        if match:
            return self.cda_decode2(web_url)
            js_data = json.loads(match.group(1))
            return self.cda_decode(js_data.get('video').get('file')) + helpers.append_headers(headers)

        raise ResolverError('Video Link Not Found')

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://ebd.cda.pl/647x500/{media_id}/vfilm')

    def cda_decode2(self, url):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0',
            'Accept': 'text/css,*/*;q=0.1',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
        }
        page_source = requests.get(url, headers=headers).text
        file = re.findall("\"file\":\"(.*?)\"", page_source)[0]
        javascript_link = "https://cda.pl" + re.findall(r"(/js/player.js.*?)\">", page_source)[0]
        javascript_content = requests.get(javascript_link, headers=headers).text
        vars = re.findall(r"(var .*?;)", javascript_content)[0]
        functions = re.findall(r"(da=function.*uggcf:\/\/.*?;)", javascript_content, flags=re.DOTALL)[0]
        js_code = vars + "\n" + functions
        js_code += """var file = "%s"
        M(file)
        """ % file
        js2py.disable_pyimport()
        context = js2py.EvalJs()
        result = context.eval(js_code)
        return result

    def cda_decode(self, url):
        url = url.replace("_XDDD", "")
        url = unquote(url)
        strurl = ''
        for char in url:
            strurl += chr(33 + (ord(char) + 14) % 94) if 32 < ord(char) < 127 else char
        return self.da(strurl)

    def da(self, a):
        a = a.replace(".cda.mp4", "")
        a = a.replace(".2cda.pl", ".cda.pl")
        a = a.replace(".3cda.pl", ".cda.pl")
        return "https://" + a + ".mp4"
